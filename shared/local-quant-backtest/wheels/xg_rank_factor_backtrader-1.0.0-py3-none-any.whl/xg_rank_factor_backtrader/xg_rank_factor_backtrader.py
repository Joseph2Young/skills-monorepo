'''
作者小果
微信:xg_quant
'''
"""
小果排序多因子回测系统
选择符合的买入因子，利用排序因子，对于bool值，True，False的因子类型，排序因子默认都是1
利用排序因子的权重，相关性计算，排序因子总权重，得到交易股票池，利用持股限制，买入数量
选择买入的股票池，对于持股没有在买入股票池的标的卖出，买入股票池里面的标的没有在持股买入

作者: xg_quant

因子值说明:
==========
- Bool类型因子 (金叉/死叉、价格在均线上等): 0=符合条件(True), 1=不符合条件(False)
- 数值类型因子 (连续上涨天数、连续下跌天数、价格等): 正常数值比较

策略逻辑:
==========
第一步: 根据买入条件选择符合条件的股票池 (and/or/not逻辑)初步形成交易股票池
第二步: 对选出的股票按排序因子进行排序，对因子采用正相关，负相关，权重得到全部排序因子的值，在排序
第三步: 根据因子加权排序得到的股票池作为交易股票池，安买入排名选择前排名的股票池
第四步: 先卖出后买入，卖出，持股的标的不在排序股票池卖出，排序股票池不在持股里面的标的买入，保持买入排名数量不变

因子条件说明:
==========
选择类型: and (全部满足) / or (至少满足一个) / not (不满足)
选择方向: 等于 / 大于 / 小于
值: 比较的目标值 (支持数值和Bool值0/1)
"""
###############################################
'''
数据必须包含的字段
字段名	说明	是否必须
date	日期	✅ 必须
close	收盘价	✅ 必须
open	开盘价	✅ 必须
high	最高价	✅ 必须
low	最低价	✅ 必须
volume	成交量	✅ 必须
####################################
推荐包含的字段（用于复权计算和涨跌停过滤）
字段名	说明	是否必须
preClose	前收盘价	⚠️ 推荐（用于复权和涨跌停过滤）
zdf	涨跌幅	⚠️ 推荐（如不存在会自动计算）
amount	成交金额	⚠️ 可选
证券代码	股票代码	⚠️ 可选（会自动添加）
证券名称	股票名称	⚠️ 可选
'''
import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta
import json
import math
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
import io
warnings.filterwarnings('ignore')
from xg_tdx_func.xg_tdx_func import *


class xg_rank_factor_backtrader:
    '''
    小果排序多因子量化回测系统
    第一步: 根据买入条件选择符合条件的股票池 (and/or/not逻辑)初步形成交易股票池
    第二步: 对选出的股票按排序因子进行排序，对因子采用正相关，负相关，权重得到全部排序因子的值，在排序
    第三步: 根据因子加权排序得到的股票池作为交易股票池，安买入排名选择前排名的股票池
    第四步: 先卖出后买入，卖出，持股的标的不在排序股票池卖出，排序股票池不在持股里面的标的买入，保持买入排名数量不变
    因子条件说明:
    ==========
    选择类型: and (全部满足) / or (至少满足一个) / not (不满足)
    选择方向: 等于 / 大于 / 小于
    值: 比较的目标值 (支持数值和Bool)
    重点需要处理一些排序因子，对于排序因子值是True，flase需要把因子值全部改成1好加权计算，因为0*其他数都是0
    重点注意返回的是boll，True，和False,在做因子买卖选择的时候
    True,其他值也是一样的意思表示真比如'T','true',字符串的'TRUE',
    False 其他值也是应该意思表示假字符串的'F','false','FALSE'
    '''

    def __init__(
        self,
        # 开始时间
        start_date: str = '20250101',
        # 结束时间
        end_date: str = '20261201',
        # 股票池
        stock_list: list = ['159915.SZ', '513100.SH', '518880.SH'],
        # 指数
        index_stock: str = '000300.SH',
        # 开始资金
        cash: float = 100000,
        # 手续费
        comm: float = 0.0001,
        min_commission: float = 0,
        # 交易类型
        trader_type: str = '百分比',
        # 交易值
        trader_value: float = 0.5,
        # 是否开始自定义因子计算
        is_open_user_factor=True,
        # 选择需要计算的自定义基础因子
        user_factor_list=['close', 'high', 'low', 'open', 'amount', 'volume', 'zdf'],
        # 自定义因子计算
        # user_factor_cacal={"因子名称":"因子计算公式"}
        # 因子计算的数据表是df,自定义因子计算好了合并到因子表里面，
        # 自定义的因子名称不要和默认因子表名称一样,对于boll值的因子，0代表True，1代码flase
        user_factor_cacal={
            "收盘价大于5日均线": "IF(df['close']>MA(df['close'],5),0,1)",
            "均线评分": "IF(MA(df['close'],3)>MA(df['close'],5),25,0)+IF(MA(df['close'],5)>MA(df['close'],10),25,0)+IF(MA(df['close'],10)>MA(df['close'],20),25,0)+IF(MA(df['close'],20)>MA(df['close'],30),25,0)"
        },
        # 选择买入的因子条件
        # 释放开启买入因子选择，不开启买入因子选择的话就纯安因子加权排名轮动
        is_open_buy_condi: bool = True,
        buy_condi_factor: dict = {
            "25日回归动量": {
                "选择类型": "and",
                "选择方向": "大于",
                "值": 0
            },
            "25日回归动量": {
                "选择类型": "and",
                "选择方向": "小于",
                "值": 5
            },
        },
        # 排序因子,正相关：因子值越大得分越高；负相关：因子值越大得分越低
        # 排序因子设置
        rank_factor: dict = {
            "25日回归动量": {"相关性": "正相关", "权重": 1},
        },
        # 排序加权的总因子,综合排序=升序/降序/无，无就是默认的因子加权出来的股票池不排序
        total_factor_rank='降序',  # 大到小
        # 持股限制，也是因子排名前10意思
        hold_stock_limit: int = 2,
        # 止盈类型: 'none'=不使用止盈, '涨幅'=按涨幅止盈
        sell_type: str = '金额',
        # 触发止盈涨跌幅，0.03是3%意思
        sell_zdf: float = 0.03,
        # 卖出的值
        # sell_type='金额'，sell_value=1000 表示卖出1000元
        # sell_type='数量'，sell_value=1000 表示卖出1000股
        # sell_type='百分比'，sell_value=0.1 表示卖出仓位的10%
        sell_value: float = 1000,
        max_workers: int = 4,
        interval: int = 1,
        min_hold_days: int = 1,
        risk_free_rate: float = 0.02,
        slippage: float = 0,
        enable_limit_up_down_filter: bool = True,
        max_single_position_ratio: float = 1.0,
        # ===== 新增：数据源模式开关 =====
        use_custom_data: bool = False,  # 是否使用自定义数据
    ):
        """
        初始化回测系统
        
        Args:
            start_date: 回测开始日期，格式'20250101'
            end_date: 回测结束日期，格式'20261201'
            stock_list: 回测标的列表
            index_stock: 基准指数代码
            cash: 初始资金
            comm: 手续费率，默认万1 (0.0001)
            min_commission: 最小佣金，默认0元
            trader_type: 交易类型，'金额'/'数量'/'百分比'
            trader_value: 交易值
            hold_stock_limit: 最大持股数量
            is_open_user_factor: 是否开启自定义因子计算
            user_factor_list: 自定义基础因子列表
            user_factor_cacal: 自定义因子计算公式
            is_open_buy_condi: 是否开启买入条件筛选 (True=开启, False=关闭，直接全市场排序)
            buy_condi_factor: 买入条件因子配置 
            rank_factor: 排序因子配置
            sell_type: 止盈卖出类型，'none'/'金额'/'数量'/'百分比'
            sell_zdf: 止盈涨幅阈值
            sell_value: 止盈卖出值
            max_workers: 多线程数
            interval: 调仓间隔(天)
            min_hold_days: 最小持有天数
            risk_free_rate: 无风险利率，默认2%
            slippage: 滑点比例，默认0%
            enable_limit_up_down_filter: 是否启用涨跌停过滤
            max_single_position_ratio: 单只标的最大仓位上限(占总资产比例)
            use_custom_data: 是否使用自定义数据（True时使用add_stock_data添加的数据）
            
        """
        """
        简单的例子理解
        user_factor_cacal={
            "收盘价大于5日均线":"IF(df['close']>MA(df['close'],5),0,1)",
            "均线评分":"IF(MA(df['close'],3)>MA(df['close'],5),25,0)+IF(MA(df['close'],5)>MA(df['close'],10),25,0)+IF(MA(df['close'],10)>MA(df['close'],20),25,0)+IF(MA(df['close'],20)>MA(df['close'],30),25,0)"
        },
        #选择买入的因子条件
        buy_condi_factor: dict = {
            "价格在5均线上": {
                "选择类型": "and",
                "选择方向": "等于",
                "值": True
            },
            "5均线在10均线上": {
                "选择类型": "and",
                "选择方向": "等于",
                "值": True
            },
            "连续上涨天数": {
                "选择类型": "and",
                "选择方向": "大于",
                "值": 2
            },
        },
        #排序因子,正相关：因子值越大得分越高；负相关：因子值越大得分越低
        #排序因子设置
        rank_factor: dict = {
            "连续上涨天数":{"相关性":"正相关","权重":1},
            "价格在5均线上": {"相关性":"正相关","权重":1},
        },
        #排序加权的总因子,综合排序=升序/降序/无，无就是默认的因子加权出来的股票池不排序
        total_factor_rank='降序', #大到小
        #持股限制，也是因子排名前10意思
        hold_stock_limit: int = 10,
        
        第一步先在基础因子的基础上计算自定义的因子,user_factor_cacal,得到全部的因子数据
        第二步选择符合条件的买入因子buy_condi_factor，重点注意重点注意返回的是bool，True，和False,在做因子买卖选择的时候
        True,其他值也是一样的意思表示真比如'T','true',字符串的'TRUE',
        False 其他值也是应该意思表示假字符串的'F','false','FALSE'
        比如这个意思是选择类型: and (全部满足) / or (至少满足一个) / not (不满足)
        选择方向: 等于 / 大于 / 小于
        值: 比较的目标值 (支持数值和Bool)
        "价格在5均线上": {
                "选择类型": "and",
                "选择方向": "等于",
                "值": True
            },
            "5均线在10均线上": {
                "选择类型": "and",
                "选择方向": "等于",
                "值": True
            },
            "连续上涨天数": {
                "选择类型": "and",
                "选择方向": "大于",
                "值": 2
            },
        这个意思是价格在5均线上的值等于True而且5均线在10均线上值等于True
        连续上涨天数的值大于2，得到交易的初步股票池
        #排序因子
         rank_factor: dict = {
            "连续上涨天数":{"相关性":"正相关","权重":1},
            "价格在5均线上": {"相关性":"正相关","权重":1},
            "5日标准差":{"相关性":"负相关","权重":1},

        },
        怎么样计算总排序因子的值，正相关计算值是1，负相关是-1
        比如连续上涨天数的值是2,正相关,权重是1，得到连续上涨天数权重值是2*正相关*权重=2*1*1=2
        比如价格在5均线上,这个是bool值的，因子的值全部是1，这样计算采用意义,正相关,权重是1，得到连续上涨天数权重值是1*正相关*权重=1*1*1=1
        比如5日标准差2,负相关,权重是1，得到5日标准差权重值是2*负相关*权重=2*-1*1=-2
        得到各自的因子值，计算加权总因子的值，全部因子的值加起来连续上涨天数2+价格在5均线上1+5日标准差-2=1
        #排序加权的总因子,综合排序=升序/降序/无，无就是默认的因子加权出来的股票池不排序
        total_factor_rank='降序', #大到小
        #持股限制，也是因子排名前10意思
        第三步利用加权总因子的排序得到交易股票池,持股现在hold_stock_limit=10
        选择全部排序的数据前10个形成最终的股票池
        hold_stock_limit: int = 10,
        
        第四步
        先卖出，在买入，先更新账户数据
        卖出，比如持股标的不在，最终排序因子的股票池，比如不在因子排序的持股限制前10里面的
        标的卖出
        买入，检查最终排序股票池里面的标的，不在持股里面的买入，最终的结果就是持股数据和最终买入排序股票池前10的标的一样
        
        """
        self.start_date = start_date
        self.end_date = end_date
        self.stock_list = stock_list if stock_list is not None else ['159915.SZ', '513100.SH', '518880.SH']
        self.index_stock = index_stock
        self.cash = cash
        self.comm = comm
        self.min_commission = min_commission
        self.verbose = True
        self.risk_free_rate = risk_free_rate
        self.slippage = slippage
        self.enable_limit_up_down_filter = enable_limit_up_down_filter
        self.max_single_position_ratio = max_single_position_ratio
        self.verbose=True
        self.trader_type = trader_type
        self.trader_value = trader_value
        self.hold_stock_limit = hold_stock_limit

        # 自定义因子相关属性
        self.is_open_user_factor = is_open_user_factor
        self.user_factor_list = user_factor_list if user_factor_list else ['close', 'high', 'low', 'open', 'amount', 'volume', 'zdf']
        self.user_factor_cacal = user_factor_cacal if user_factor_cacal else {}
        self._user_factor_names = []  # 存储自定义因子名称

        # 买入条件开关
        self.is_open_buy_condi = is_open_buy_condi
        self.buy_condi_factor = buy_condi_factor
        self.rank_factor = rank_factor
        self.total_factor_rank = total_factor_rank

        # 止盈参数
        self.sell_type = sell_type
        self.sell_zdf = sell_zdf
        self.sell_value = sell_value

        self.interval = interval
        self.min_hold_days = min_hold_days
        self.max_workers = max_workers
        self.adj_type = 'none'

        self.min_shares = 100
        self.share_multiple = 100

        self.path = os.path.dirname(os.path.abspath(__file__))

        # ===== 新增：自定义数据存储 =====
        self.use_custom_data = use_custom_data
        self._custom_data_cache = {}  # 存储自定义数据 {stock_code: DataFrame}

        # 缓存变量，用于避免重复回测
        self._backtest_result = None
        self._cache_valid = False

        self.daily_positions = None
        self.trade_log = None
        self.portfolio_history = None
        self.performance_metrics = None
        self.equity_curve_data = None
        self.annual_performance = None
        self.trade_data = None
        self.position_data = None
        self.account_data = None
        self.stock_data_dict = {}
        self.stock_results = {}

        # 因子缺失日志
        self.missing_factor_log = []
        self.nan_rank_log = []

        # 因子名称映射（处理名称不一致问题）
        self._factor_name_mapping = {}

        # 存储指数数据
        self._index_data = None

        # 存储持有不动净值和指数净值
        self._buy_hold_net_values = []
        self._index_net_values = []

        self._validate_factor_config()
        self._validate_params()

        if self.verbose:
            self._print_config()

    def _validate_factor_config(self):
        """验证因子配置的有效性"""
        # 只有开启买入条件时才验证买入因子
        if self.is_open_buy_condi:
            for factor_name, config in self.buy_condi_factor.items():
                if '选择类型' not in config:
                    raise ValueError(f"买入因子 '{factor_name}' 缺少'选择类型'配置")
                if '选择方向' not in config:
                    raise ValueError(f"买入因子 '{factor_name}' 缺少'选择方向'配置")
                if '值' not in config:
                    raise ValueError(f"买入因子 '{factor_name}' 缺少'值'配置")

        for factor_name, config in self.rank_factor.items():
            if '相关性' not in config:
                raise ValueError(f"排序因子 '{factor_name}' 缺少'相关性'配置")
            if config['相关性'] not in ['正相关', '负相关']:
                raise ValueError(f"排序因子 '{factor_name}' 相关性必须是'正相关'或'负相关'")
            if '权重' not in config:
                raise ValueError(f"排序因子 '{factor_name}' 缺少'权重'配置")
            if not isinstance(config['权重'], (int, float)) or config['权重'] <= 0:
                raise ValueError(f"排序因子 '{factor_name}' 权重必须为正数")

        if self.total_factor_rank not in ['升序', '降序', '无']:
            raise ValueError(f"total_factor_rank 必须是'升序'、'降序'或'无'")

    def _validate_params(self):
        """验证策略参数边界"""
        if self.hold_stock_limit <= 0:
            raise ValueError(f"hold_stock_limit 必须大于0，当前值: {self.hold_stock_limit}")
        if self.interval < 0:
            raise ValueError(f"interval 必须大于等于0，当前值: {self.interval}")
        if self.comm < 0:
            raise ValueError(f"comm 必须大于等于0，当前值: {self.comm}")
        if self.min_commission < 0:
            raise ValueError(f"min_commission 必须大于等于0，当前值: {self.min_commission}")
        if self.slippage < 0:
            raise ValueError(f"slippage 必须大于等于0，当前值: {self.slippage}")

        start_dt = self._parse_date(self.start_date)
        end_dt = self._parse_date(self.end_date)
        if start_dt >= end_dt:
            raise ValueError(f"start_date ({self.start_date}) 必须早于 end_date ({self.end_date})")

        if self.trader_value <= 0:
            raise ValueError(f"trader_value 必须大于0，当前值: {self.trader_value}")
        if self.max_single_position_ratio <= 0 or self.max_single_position_ratio > 1:
            raise ValueError(f"max_single_position_ratio 必须在(0,1]范围内，当前值: {self.max_single_position_ratio}")

    def _print_config(self):
        """打印配置信息"""
        print("\n" + "=" * 60)
        print("小果排序多因子量化回测系统")
        print("=" * 60)
        print(f"回测区间: {self.start_date} ~ {self.end_date}")
        print(f"标的数量: {len(self.stock_list)}")
        print(f"初始资金: {self.cash:,.2f}")
        print(f"手续费率: {self.comm * 10000:.1f} 万, 最小佣金: {self.min_commission:.2f}元")
        print(f"滑点: {self.slippage * 100:.2f}%")
        print(f"持股限制: {self.hold_stock_limit}")
        print(f"单只最大仓位: {self.max_single_position_ratio * 100:.0f}%")
        print(f"调仓间隔: {self.interval} 天")
        print(f"最小持有: {self.min_hold_days} 天")
        print(f"交易模式: {self.trader_type} (值: {self.trader_value})")
        print(f"止盈类型: {self.sell_type}, 阈值: {self.sell_zdf * 100:.1f}%, 止盈值: {self.sell_value}")
        print(f"涨跌停过滤: {'启用' if self.enable_limit_up_down_filter else '禁用'}")
        print(f"自定义因子: {'启用' if self.is_open_user_factor else '禁用'}")
        if self.is_open_user_factor:
            print(f"自定义基础因子: {self.user_factor_list}")
            print(f"自定义因子公式: {list(self.user_factor_cacal.keys())}")
        print(f"自定义数据源: {'启用' if self.use_custom_data else '禁用'}")
        if self.use_custom_data and self._custom_data_cache:
            print(f"已加载自定义数据: {list(self._custom_data_cache.keys())}")
        print("-" * 60)
        print(f"买入条件筛选: {'✅ 开启' if self.is_open_buy_condi else '❌ 关闭 (全市场排序)'}")
        if self.is_open_buy_condi:
            print("买入条件 (True/False 或 数值比较):")
            for k, v in self.buy_condi_factor.items():
                print(f"  {k}: {v}")
        else:
            print("  跳过买入条件筛选，直接全市场排序")
        print("-" * 60)
        print("排序因子 (相关性/权重):")
        for k, v in self.rank_factor.items():
            print(f"  {k}: {v}")
        print("-" * 60)
        print(f"总排序方式: {self.total_factor_rank}")
        print("=" * 60 + "\n")

    def _convert_to_serializable(self, obj):
        """转换对象为可序列化格式"""
        if isinstance(obj, dict):
            return {k: self._convert_to_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_to_serializable(item) for item in obj]
        elif isinstance(obj, pd.Timestamp):
            return obj.strftime('%Y-%m-%d')
        elif isinstance(obj, datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, (np.integer, np.int64)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.float64)):
            return float(obj) if not np.isnan(obj) else None
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, pd.DataFrame):
            return obj.to_dict('records')
        elif isinstance(obj, pd.Series):
            return obj.tolist()
        elif isinstance(obj, (np.bool_, bool)):
            return bool(obj)
        elif pd.isna(obj):
            return None
        else:
            return obj

    def _parse_date(self, date_str):
        """灵活的日期解析函数"""
        if isinstance(date_str, pd.Timestamp):
            return date_str
        if isinstance(date_str, datetime):
            return date_str
        if isinstance(date_str, (int, float)):
            return pd.to_datetime(str(int(date_str)), format='%Y%m%d')

        date_str = str(date_str).strip()
        formats = ['%Y%m%d', '%Y-%m-%d', '%Y/%m/%d', '%Y-%m-%d %H:%M:%S', '%Y%m%d %H:%M:%S']
        for fmt in formats:
            try:
                return pd.to_datetime(date_str, format=fmt)
            except:
                continue
        try:
            return pd.to_datetime(date_str)
        except:
            raise ValueError(f"无法解析日期: {date_str}")

    def _normalize_factor_name(self, factor_name, df_columns):
        """
        规范化因子名称，处理名称不一致问题
        例如: '连续上涨天数' 可能对应 '连续上涨 天数' 或 '连续上涨_天数'
        """
        # 直接匹配
        if factor_name in df_columns:
            return factor_name

        # 去除空格匹配
        clean_name = factor_name.replace(' ', '').replace('_', '').replace('-', '')
        for col in df_columns:
            clean_col = col.replace(' ', '').replace('_', '').replace('-', '')
            if clean_col == clean_name:
                return col

        # 包含匹配
        for col in df_columns:
            if factor_name in col or col in factor_name:
                return col

        return None

    def _is_bool_string(self, value):
        """
        判断字符串是否为Bool字符串
        识别: 'T', 't', 'true', 'TRUE', 'F', 'f', 'false', 'FALSE'
        注意: '1' 和 '0' 不作为Bool字符串
        """
        if not isinstance(value, str):
            return False
        value_lower = value.lower().strip()
        return value_lower in ['true', 'false', 't', 'f']

    def _is_bool_like(self, value):
        """
        判断值是否为Bool类型
        识别:
        - Python布尔: True, False
        - 字符串: 'T', 't', 'true', 'TRUE', 'F', 'f', 'false', 'FALSE'
        注意: 1 和 0 不作为Bool值，而是作为数值处理
        """
        if isinstance(value, bool):
            return True
        if isinstance(value, str):
            return self._is_bool_string(value)
        return False

    def _convert_to_bool(self, value):
        """
        将各种形式的True/False转换为布尔值
        转换:
        - Python布尔: True -> True, False -> False
        - 字符串: 'T', 't', 'true', 'TRUE' -> True, 'F', 'f', 'false', 'FALSE' -> False
        注意: '1' 和 '0' 不被转换，返回原值
        """
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            value_lower = value.lower().strip()
            if value_lower in ['true', 't']:
                return True
            if value_lower in ['false', 'f']:
                return False
        return value

    def _convert_factor_value_for_rank(self, value):
        """
        将因子值转换为用于排序的数值
        Bool类型: True -> 1, False -> 0
        数值类型: 保持原值
        注意: 这是排序因子专用的转换，用于加权计算
        """
        if self._is_bool_like(value):
            return 1 if self._convert_to_bool(value) else 0
        try:
            return float(value) if not pd.isna(value) else 0
        except (ValueError, TypeError):
            return 0

    def _check_factor_condition_single(self, value, target, direction):
        """检查单个因子条件"""
        is_value_bool = self._is_bool_like(value)
        is_target_bool = self._is_bool_like(target)

        if is_value_bool or is_target_bool:
            value_bool = self._convert_to_bool(value)
            target_bool = self._convert_to_bool(target)

            if isinstance(value_bool, bool) and isinstance(target_bool, bool):
                if direction == '等于':
                    return value_bool == target_bool
                elif direction == '大于':
                    return value_bool > target_bool
                elif direction == '小于':
                    return value_bool < target_bool
                else:
                    return False

        try:
            value_num = float(value) if not pd.isna(value) else np.nan
            target_num = float(target) if not pd.isna(target) else np.nan

            if pd.isna(value_num) or pd.isna(target_num):
                return False

            if direction == '等于':
                return value_num == target_num
            elif direction == '大于':
                return value_num > target_num
            elif direction == '小于':
                return value_num < target_num
            else:
                return False
        except (ValueError, TypeError):
            if direction == '等于':
                return str(value) == str(target)
            elif direction == '大于':
                return str(value) > str(target)
            elif direction == '小于':
                return str(value) < str(target)
            else:
                return False

    def check_factor_condition(self, df, factor_name, config):
        """检查单个因子条件"""
        normalized_name = self._normalize_factor_name(factor_name, df.columns)
        if normalized_name is None:
            self.missing_factor_log.append({
                'factor': factor_name,
                'date': df.index[0] if len(df) > 0 else None
            })
            return pd.Series([False] * len(df), index=df.index)

        value = df[normalized_name]
        target = config['值']
        direction = config['选择方向']

        try:
            result = value.apply(
                lambda x: self._check_factor_condition_single(x, target, direction)
            )
            return result
        except Exception as e:
            if self.verbose:
                print(f"  ⚠️ 因子比较出错 {factor_name} (列名: {normalized_name}): {e}")
            return pd.Series([False] * len(df), index=df.index)

    # ============================================================
    # 新增：数据添加接口（可直接调用）
    # ============================================================

    def add_stock_data_from_dataframe(self, stock_code: str, df: pd.DataFrame) -> bool:
        """
        从DataFrame添加股票数据
        
        Args:
            stock_code: 股票代码
            df: pandas DataFrame，必须包含'date'列
        
        Returns:
            bool: 是否添加成功
        """
        try:
            normalized_df = self._normalize_dataframe(df, stock_code)
            if normalized_df is not None and not normalized_df.empty:
                self._custom_data_cache[stock_code] = normalized_df
                self.use_custom_data = True
                if self.verbose:
                    print(f"  ✅ 添加DataFrame数据: {stock_code} ({len(normalized_df)} 行)")
                return True
            return False
        except Exception as e:
            if self.verbose:
                print(f"  ❌ 添加DataFrame数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_excel(self, stock_code: str, file_path: str, sheet_name: int = 0, **kwargs) -> bool:
        """
        从Excel文件添加股票数据
        
        Args:
            stock_code: 股票代码
            file_path: Excel文件路径
            sheet_name: 工作表名称或索引
            **kwargs: 传递给pd.read_excel的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not os.path.exists(file_path):
                if self.verbose:
                    print(f"  ❌ Excel文件不存在: {file_path}")
                return False
            
            df = pd.read_excel(file_path, sheet_name=sheet_name, **kwargs)
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            if self.verbose:
                print(f"  ❌ 添加Excel数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_csv(self, stock_code: str, file_path: str, **kwargs) -> bool:
        """
        从CSV文件添加股票数据
        
        Args:
            stock_code: 股票代码
            file_path: CSV文件路径
            **kwargs: 传递给pd.read_csv的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not os.path.exists(file_path):
                if self.verbose:
                    print(f"  ❌ CSV文件不存在: {file_path}")
                return False
            
            # 尝试不同编码
            encodings = ['utf-8', 'gbk', 'gb2312', 'utf-8-sig', 'latin-1']
            df = None
            for encoding in encodings:
                try:
                    df = pd.read_csv(file_path, encoding=encoding, **kwargs)
                    break
                except UnicodeDecodeError:
                    continue
            
            if df is None:
                if self.verbose:
                    print(f"  ❌ 无法读取CSV文件: {file_path}")
                return False
            
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            if self.verbose:
                print(f"  ❌ 添加CSV数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_json(self, stock_code: str, file_path: str, orient: str = 'records', **kwargs) -> bool:
        """
        从JSON文件添加股票数据
        
        Args:
            stock_code: 股票代码
            file_path: JSON文件路径
            orient: JSON格式方向
            **kwargs: 传递给pd.read_json的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not os.path.exists(file_path):
                if self.verbose:
                    print(f"  ❌ JSON文件不存在: {file_path}")
                return False
            
            df = pd.read_json(file_path, orient=orient, **kwargs)
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            if self.verbose:
                print(f"  ❌ 添加JSON数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_dict(self, stock_code: str, data: dict) -> bool:
        """
        从字典添加股票数据
        
        Args:
            stock_code: 股票代码
            data: 字典数据，格式为 {'date': [...], 'close': [...], ...}
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not data:
                return False
            df = pd.DataFrame(data)
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            if self.verbose:
                print(f"  ❌ 添加Dict数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_parquet(self, stock_code: str, file_path: str, columns: list = None, **kwargs) -> bool:
        """
        从Parquet文件添加股票数据
        
        Args:
            stock_code: 股票代码
            file_path: Parquet文件路径
            columns: 需要读取的列列表
            **kwargs: 传递给pd.read_parquet的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not os.path.exists(file_path):
                if self.verbose:
                    print(f"  ❌ Parquet文件不存在: {file_path}")
                return False
            
            df = pd.read_parquet(file_path, **kwargs)
            if columns:
                existing_cols = [col for col in columns if col in df.columns]
                if existing_cols:
                    df = df[existing_cols]
            
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            if self.verbose:
                print(f"  ❌ 添加Parquet数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_bytes(self, stock_code: str, file_bytes: bytes, file_type: str = 'csv', **kwargs) -> bool:
        """
        从字节数据添加股票数据（适用于上传文件等场景）
        
        Args:
            stock_code: 股票代码
            file_bytes: 文件字节数据
            file_type: 文件类型 ('csv', 'excel', 'json')
            **kwargs: 传递给相应读取函数的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if file_type.lower() == 'csv':
                encodings = ['utf-8', 'gbk', 'gb2312', 'utf-8-sig', 'latin-1']
                df = None
                for encoding in encodings:
                    try:
                        df = pd.read_csv(io.BytesIO(file_bytes), encoding=encoding, **kwargs)
                        break
                    except UnicodeDecodeError:
                        continue
                if df is None:
                    if self.verbose:
                        print(f"  ❌ 无法解码CSV字节数据")
                    return False
            
            elif file_type.lower() in ['excel', 'xlsx', 'xls']:
                df = pd.read_excel(io.BytesIO(file_bytes), **kwargs)
            
            elif file_type.lower() == 'json':
                df = pd.read_json(io.BytesIO(file_bytes), **kwargs)
            
            else:
                if self.verbose:
                    print(f"  ❌ 不支持的文件类型: {file_type}")
                return False
            
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            if self.verbose:
                print(f"  ❌ 添加字节数据失败 {stock_code}: {e}")
            return False

    def clear_custom_data(self):
        """清空所有自定义数据"""
        self._custom_data_cache.clear()
        self.use_custom_data = False
        if self.verbose:
            print("  ✅ 已清空所有自定义数据")

    def remove_stock_data(self, stock_code: str) -> bool:
        """
        移除指定股票的自定义数据
        
        Args:
            stock_code: 股票代码
        
        Returns:
            bool: 是否移除成功
        """
        if stock_code in self._custom_data_cache:
            del self._custom_data_cache[stock_code]
            if not self._custom_data_cache:
                self.use_custom_data = False
            if self.verbose:
                print(f"  ✅ 已移除股票数据: {stock_code}")
            return True
        return False

    def get_custom_data_keys(self) -> list:
        """获取所有已加载的自定义数据股票代码列表"""
        return list(self._custom_data_cache.keys())

    def has_custom_data(self, stock_code: str) -> bool:
        """检查是否有指定股票的自定义数据"""
        return stock_code in self._custom_data_cache

    # ============================================================
    # 内部数据标准化方法
    # ============================================================

    def _normalize_dataframe(self, df: pd.DataFrame, stock_code: str = None) -> pd.DataFrame:
        """
        标准化DataFrame数据
        
        Args:
            df: pandas DataFrame
            stock_code: 股票代码
        
        Returns:
            DataFrame: 标准化后的数据
        """
        if df is None or df.empty:
            return pd.DataFrame()
        
        df = df.copy()
        
        # 标准化日期列
        if 'date' not in df.columns:
            # 尝试查找日期列
            date_cols = [col for col in df.columns if 'date' in col.lower() or '日期' in col]
            if date_cols:
                df = df.rename(columns={date_cols[0]: 'date'})
            else:
                # 尝试使用索引作为日期
                if isinstance(df.index, pd.DatetimeIndex):
                    df = df.reset_index()
                    df = df.rename(columns={df.columns[0]: 'date'})
                else:
                    raise ValueError("DataFrame必须包含'date'列或日期索引")
        
        # 确保日期列是datetime类型
        df['date'] = pd.to_datetime(df['date'])
        df = df.sort_values('date').reset_index(drop=True)
        
        # 确保必要的列存在
        required_cols = ['close', 'high', 'low', 'open', 'volume']
        for col in required_cols:
            if col not in df.columns:
                # 尝试查找对应的列名
                for existing_col in df.columns:
                    if col in existing_col.lower():
                        df = df.rename(columns={existing_col: col})
                        break
                else:
                    # 如果列不存在，创建空列
                    df[col] = np.nan
        
        # 添加证券代码
        if stock_code:
            df['证券代码'] = stock_code
        elif '证券代码' not in df.columns and 'code' not in df.columns:
            df['证券代码'] = 'CUSTOM'
        
        # 计算涨跌幅（如果不存在）
        if 'zdf' not in df.columns and 'close' in df.columns:
            df['zdf'] = df['close'].pct_change().fillna(0)
        
        # 计算复权因子（如果不存在）
        if 'preClose' in df.columns and 'adj_factor' not in df.columns:
            df['return'] = df['close'] / df['preClose']
            df['return'] = df['return'].fillna(1.0)
            df['return'] = df['return'].replace([np.inf, -np.inf], 1.0)
            df['adj_factor'] = df['return'].cumprod()
            if len(df) > 0:
                df.loc[df.index[0], 'adj_factor'] = 1.0
        
        return df

    # ============================================================
    # 原有方法（修改get_stock_data以支持自定义数据）
    # ============================================================

    def get_stock_data(self, stock_code):
        """读取单个股票数据，支持自定义因子计算和自定义数据源"""
        try:
            # ===== 第一步：尝试从自定义数据源读取 =====
            if self.use_custom_data and stock_code in self._custom_data_cache:
                df = self._custom_data_cache[stock_code].copy()
                
                if 'date' not in df.columns:
                    return pd.DataFrame()
                
                df['date'] = pd.to_datetime(df['date'])
                start_dt = pd.to_datetime(self.start_date, format='%Y%m%d')
                end_dt = pd.to_datetime(self.end_date, format='%Y%m%d')
                df = df[(df['date'] >= start_dt) & (df['date'] <= end_dt)]
                df = df.sort_values('date').reset_index(drop=True)
                df = df[df['close'] > 0]
                df = df[df['open'] > 0]
                
                if self.enable_limit_up_down_filter and 'preClose' in df.columns and 'close' in df.columns:
                    df['pct_change'] = (df['close'] - df['preClose']) / df['preClose']
                    df = df[df['pct_change'].between(-0.095, 0.095) | df['pct_change'].isna()]
                
                df = self.adjust_price(df)
                
                if 'close' in df.columns and 'zdf' not in df.columns:
                    df['zdf'] = df['close'].pct_change().fillna(0)
                
                # 计算自定义因子
                if self.is_open_user_factor and self.user_factor_cacal:
                    try:
                        import sys
                        current_module = sys.modules[__name__]
                        func_env = {'df': df}
                        for name in dir(current_module):
                            if not name.startswith('_'):
                                attr = getattr(current_module, name)
                                if callable(attr):
                                    func_env[name] = attr
                        
                        for factor_name, formula in self.user_factor_cacal.items():
                            try:
                                result = eval(formula, func_env)
                                if isinstance(result, pd.Series):
                                    if len(result) == len(df):
                                        df[factor_name] = result
                                        if factor_name not in self._user_factor_names:
                                            self._user_factor_names.append(factor_name)
                                elif isinstance(result, (int, float)):
                                    df[factor_name] = result
                                    if factor_name not in self._user_factor_names:
                                        self._user_factor_names.append(factor_name)
                                else:
                                    try:
                                        df[factor_name] = pd.Series(result, index=df.index)
                                        if factor_name not in self._user_factor_names:
                                            self._user_factor_names.append(factor_name)
                                    except:
                                        pass
                            except:
                                pass
                    except:
                        pass
                
                # 构建因子名称映射
                base_columns = ['date', 'close', 'high', 'low', 'open', 'amount', 'volume', 'zdf', '证券名称', '证券代码']
                for col in df.columns:
                    if col not in base_columns and col not in ['pct_change']:
                        self._factor_name_mapping[col] = col
                        clean_col = col.replace(' ', '').replace('_', '').replace('-', '')
                        if clean_col != col:
                            self._factor_name_mapping[clean_col] = col
                
                return df

            # ===== 第二步：从本地文件读取 =====
            base_columns = ['date', 'close', 'high', 'low', 'open', 'amount', 'volume', 'zdf', '证券名称', '证券代码']

            factor_names = set()

            # 只有开启买入条件时才读取买入因子
            if self.is_open_buy_condi:
                for factor_name in self.buy_condi_factor.keys():
                    factor_names.add(factor_name)
                    factor_names.add(factor_name.replace(' ', ''))

            for factor_name in self.rank_factor.keys():
                factor_names.add(factor_name)
                factor_names.add(factor_name.replace(' ', ''))

            if self.is_open_user_factor:
                user_base_factors = self.user_factor_list if self.user_factor_list else []
                for factor in user_base_factors:
                    factor_names.add(factor)
                    factor_names.add(factor.replace(' ', ''))

            all_columns = set(base_columns) | factor_names

            file_path = os.path.join(self.path, 'data', '全部因子数据', f'{stock_code}.parquet')
            if not os.path.exists(file_path):
                file_path = os.path.join(self.path, 'data', '历史数据', f'{stock_code}.parquet')
                if not os.path.exists(file_path):
                    if self.verbose:
                        print(f"⚠️ 数据文件不存在: {file_path}")
                    return pd.DataFrame()

            try:
                df = pd.read_parquet(file_path, engine='pyarrow', columns=list(all_columns), use_threads=True)
            except Exception:
                df = pd.read_parquet(file_path, engine='pyarrow')
                existing_cols = [col for col in all_columns if col in df.columns]
                if existing_cols:
                    df = df[existing_cols]
                else:
                    return pd.DataFrame()

            if df.empty:
                return pd.DataFrame()

            if 'date' in df.columns:
                df['date'] = df['date'].apply(self._parse_date)
            elif '日期' in df.columns:
                df['date'] = df['日期'].apply(self._parse_date)
                df = df.rename(columns={'日期': 'date'})
            else:
                return pd.DataFrame()

            start_dt = self._parse_date(self.start_date)
            end_dt = self._parse_date(self.end_date)
            df = df[(df['date'] >= start_dt) & (df['date'] <= end_dt)]
            df = df.sort_values('date').reset_index(drop=True)

            if 'close' in df.columns:
                df = df[df['close'] > 0]

                if self.enable_limit_up_down_filter and 'preClose' in df.columns and 'close' in df.columns:
                    df['pct_change'] = (df['close'] - df['preClose']) / df['preClose']
                    df = df[df['pct_change'].between(-0.095, 0.095) | df['pct_change'].isna()]

            if 'open' in df.columns:
                df = df[df['open'] > 0]

            df = self.adjust_price(df)

            if 'close' in df.columns and 'zdf' not in df.columns:
                df['zdf'] = df['close'].pct_change()

            if self.is_open_user_factor and self.user_factor_cacal:
                try:
                    import sys
                    current_module = sys.modules[__name__]

                    func_env = {'df': df}
                    for name in dir(current_module):
                        if not name.startswith('_'):
                            attr = getattr(current_module, name)
                            if callable(attr):
                                func_env[name] = attr

                    for factor_name, formula in self.user_factor_cacal.items():
                        try:
                            result = eval(formula, func_env)

                            if isinstance(result, pd.Series):
                                if len(result) == len(df):
                                    df[factor_name] = result
                                    if factor_name not in self._user_factor_names:
                                        self._user_factor_names.append(factor_name)
                            elif isinstance(result, (int, float)):
                                df[factor_name] = result
                                if factor_name not in self._user_factor_names:
                                    self._user_factor_names.append(factor_name)
                            else:
                                try:
                                    df[factor_name] = pd.Series(result, index=df.index)
                                    if factor_name not in self._user_factor_names:
                                        self._user_factor_names.append(factor_name)
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass

            for col in df.columns:
                if col not in base_columns and col not in ['pct_change']:
                    self._factor_name_mapping[col] = col
                    clean_col = col.replace(' ', '').replace('_', '').replace('-', '')
                    if clean_col != col:
                        self._factor_name_mapping[clean_col] = col

            return df

        except Exception as e:
            if self.verbose:
                print(f"❌ 加载股票数据出错 {stock_code}: {e}")
            return pd.DataFrame()

    def _load_single_stock(self, stock):
        """单个股票加载函数（用于多线程）"""
        try:
            df = self.get_stock_data(stock)
            if not df.empty:
                if self.is_open_user_factor and self._user_factor_names:
                    factor_info = f", 自定义因子: {self._user_factor_names}"
                else:
                    factor_info = ""
                return (stock, df, True, f"数据加载成功: {len(df)} 行{factor_info}")
            else:
                return (stock, None, False, "数据加载失败或为空")
        except Exception as e:
            return (stock, None, False, f"加载异常: {e}")

    def adjust_price(self, df):
        """价格复权处理"""
        if self.adj_type == 'none':
            return df

        if 'preClose' not in df.columns:
            return df

        try:
            df['adj_factor'] = 1.0
            df['return'] = df['close'] / df['preClose']
            df['return'] = df['return'].fillna(1.0)
            df['return'] = df['return'].replace([np.inf, -np.inf], 1.0)
            df['adj_factor'] = df['return'].cumprod()

            if len(df) > 0:
                df.loc[df.index[0], 'adj_factor'] = 1.0

            if self.adj_type in ['front', 'front_ratio']:
                last_factor = df['adj_factor'].iloc[-1] if len(df) > 0 else 1.0
                if last_factor > 0:
                    df['adj_factor'] = df['adj_factor'] / last_factor

            price_cols = ['open', 'high', 'low', 'close']
            for col in price_cols:
                if col in df.columns:
                    df[col] = df[col] * df['adj_factor']
            df = df.drop(columns=['adj_factor', 'return'])
        except Exception as e:
            if self.verbose:
                print(f"复权计算警告: {e}")
        return df

    def get_all_stock_data(self):
        """多线程读取所有股票历史数据"""
        all_data = {}
        if self.verbose:
            print(f"\n开始多线程加载股票数据 (线程数: {self.max_workers})...")
            if self.use_custom_data:
                print(f"使用自定义数据源: {list(self._custom_data_cache.keys())}")
            if self.is_open_user_factor:
                print(f"自定义因子已启用，基础因子: {self.user_factor_list}")
                print(f"自定义因子公式: {list(self.user_factor_cacal.keys())}")

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_stock = {
                executor.submit(self._load_single_stock, stock): stock
                for stock in self.stock_list
            }

            for future in as_completed(future_to_stock):
                stock = future_to_stock[future]
                try:
                    stock_code, df, success, message = future.result()
                    if success and df is not None and not df.empty:
                        all_data[stock_code] = df
                        if self.verbose:
                            print(f"  ✅ {stock_code}: {message}")
                            print(f"     数据范围: {df['date'].min()} 至 {df['date'].max()}")
                            if 'close' in df.columns:
                                print(f"     价格范围: {df['close'].min():.4f} 至 {df['close'].max():.4f}")
                            if self.is_open_user_factor and self._user_factor_names:
                                existing_factors = [f for f in self._user_factor_names if f in df.columns]
                                if existing_factors:
                                    print(f"     自定义因子: {existing_factors}")
                    else:
                        if self.verbose:
                            print(f"  ❌ {stock_code}: {message}")
                except Exception as e:
                    if self.verbose:
                        print(f"  ❌ {stock}: 线程执行异常: {e}")

        if self.verbose:
            print(f"\n加载完成，成功加载 {len(all_data)}/{len(self.stock_list)} 只标的")
            if self.is_open_user_factor and self._user_factor_names:
                print(f"已计算自定义因子: {self._user_factor_names}")

        self.stock_data_dict = all_data
        return all_data

    def get_index_data(self):
        """读取指数数据"""
        if self._index_data is not None:
            return self._index_data

        try:
            file_path = os.path.join(self.path, 'data', '指数数据', f'{self.index_stock}.parquet')
            if not os.path.exists(file_path):
                if self.verbose:
                    print(f"指数文件不存在: {file_path}")
                self._index_data = pd.DataFrame()
                return self._index_data

            df = pd.read_parquet(file_path, engine='pyarrow', use_threads=True)

            if df.empty:
                self._index_data = pd.DataFrame()
                return self._index_data

            if 'date' in df.columns:
                df['date'] = df['date'].apply(self._parse_date)

            start_dt = self._parse_date(self.start_date)
            end_dt = self._parse_date(self.end_date)
            df = df[(df['date'] >= start_dt) & (df['date'] <= end_dt)]
            df = df.sort_values('date').reset_index(drop=True)

            if 'close' in df.columns:
                df = df[df['close'] > 0]
            if 'open' in df.columns:
                df = df[df['open'] > 0]

            if self.verbose:
                print(f"指数数据加载成功: {len(df)} 行")
                print(f"指数数据范围: {df['date'].min()} 至 {df['date'].max()}")

            self._index_data = df
            return df
        except Exception as e:
            if self.verbose:
                print(f"加载指数数据出错: {e}")
            self._index_data = pd.DataFrame()
            return self._index_data

    def _calculate_buy_hold_net_value(self, stock_data):
        """计算持有不动策略净值"""
        if not stock_data:
            return [], []

        all_dates = set()
        for stock, df in stock_data.items():
            all_dates.update(df['date'].tolist())
        all_dates = sorted(list(all_dates))

        if not all_dates:
            return [], []

        price_dicts = {}
        valid_stocks = []
        first_date = all_dates[0]

        for stock, df in stock_data.items():
            price_dict = dict(zip(df['date'], df['close']))
            if first_date in price_dict and price_dict[first_date] > 0:
                price_dicts[stock] = price_dict
                valid_stocks.append(stock)

        if not valid_stocks:
            return [1.0] * len(all_dates), all_dates

        first_prices = {}
        for stock in valid_stocks:
            first_prices[stock] = price_dicts[stock][first_date]

        buy_hold_net_values = []
        for date in all_dates:
            total_value = 0
            weight = 1.0 / len(valid_stocks)

            for stock in valid_stocks:
                if date in price_dicts[stock]:
                    price = price_dicts[stock][date]
                    if price > 0:
                        shares = weight / first_prices[stock]
                        total_value += shares * price
                    else:
                        total_value += weight
                else:
                    total_value += weight

            buy_hold_net_values.append(total_value)

        if buy_hold_net_values and buy_hold_net_values[0] > 0:
            buy_hold_net_values = [v / buy_hold_net_values[0] for v in buy_hold_net_values]
        else:
            buy_hold_net_values = [1.0] * len(all_dates)

        return buy_hold_net_values, all_dates

    def _calculate_index_net_value(self, index_data):
        """计算指数净值"""
        if index_data is None or index_data.empty:
            return [], []

        dates = index_data['date'].tolist()
        index_prices = index_data['close'].tolist()

        if not index_prices or index_prices[0] <= 0:
            return [1.0] * len(index_prices), dates

        index_net_values = [p / index_prices[0] for p in index_prices]
        return index_net_values, dates

    def filter_by_buy_conditions(self, df_date):
        """
        根据买入条件筛选股票
        如果 is_open_buy_condi 为 False，直接返回所有股票
        """
        # 如果不开启买入条件筛选，返回所有股票
        if not self.is_open_buy_condi:
            return df_date.index.tolist()

        if df_date.empty:
            return []

        and_factors = {}
        or_factors = {}
        not_factors = {}

        for factor_name, config in self.buy_condi_factor.items():
            cond_type = config.get('选择类型', 'and')
            if cond_type == 'and':
                and_factors[factor_name] = config
            elif cond_type == 'or':
                or_factors[factor_name] = config
            elif cond_type == 'not':
                not_factors[factor_name] = config

        result_mask = pd.Series([True] * len(df_date), index=df_date.index)

        for factor_name, config in and_factors.items():
            cond_mask = self.check_factor_condition(df_date, factor_name, config)
            result_mask = result_mask & cond_mask

        if or_factors:
            or_mask = pd.Series([False] * len(df_date), index=df_date.index)
            for factor_name, config in or_factors.items():
                cond_mask = self.check_factor_condition(df_date, factor_name, config)
                or_mask = or_mask | cond_mask
            result_mask = result_mask & or_mask

        for factor_name, config in not_factors.items():
            cond_mask = self.check_factor_condition(df_date, factor_name, config)
            result_mask = result_mask & (~cond_mask)

        return df_date[result_mask].index.tolist()

    def calculate_rank_score(self, df_date, stock_list):
        """
        计算排序因子的加权总得分
        
        排序因子计算规则:
        1. 获取每个因子的值
        2. Bool类型因子: True -> 1, False -> 0 (因为0*其他数都是0，所以Bool值统一转为1)
        3. 数值类型因子: 保持原值
        4. 计算加权得分: 因子值 * 相关性系数 * 权重
        5. 汇总所有因子的得分得到总得分
        
        Args:
            df_date: 当前日期的因子数据
            stock_list: 股票列表
            
        Returns:
            Series: 每个股票的加权总得分
        """
        if not stock_list:
            return pd.Series(dtype=float)

        df_rank = df_date.loc[stock_list].copy()
        total_score = pd.Series(0.0, index=df_rank.index)

        for factor_name, config in self.rank_factor.items():
            normalized_name = self._normalize_factor_name(factor_name, df_rank.columns)
            if normalized_name is None:
                self.missing_factor_log.append({
                    'factor': factor_name,
                    'date': df_date.index[0] if len(df_date) > 0 else None
                })
                continue

            # 获取因子值
            factor_values = df_rank[normalized_name]

            # 将因子值转换为数值（Bool类型转换为0/1）
            numeric_values = factor_values.apply(self._convert_factor_value_for_rank)

            # 处理NaN值
            numeric_values = numeric_values.fillna(0)

            # 获取相关性和权重
            correlation = config['相关性']
            weight = config['权重']

            # 相关性系数: 正相关=1, 负相关=-1
            corr_coef = 1 if correlation == '正相关' else -1

            # 计算加权得分
            weighted_score = numeric_values * corr_coef * weight

            # 累加到总得分
            total_score = total_score + weighted_score

            if self.verbose:
                print(f"  📊 排序因子 '{factor_name}': 相关性={correlation}({corr_coef}), 权重={weight}")

        return total_score

    def get_trading_stocks(self, df_date):
        """
        获取交易日期的交易股票池
        
        流程:
        1. 根据买入条件筛选初步股票池 (如果 is_open_buy_condi 为 True)
        2. 计算排序因子加权总得分
        3. 根据总得分排序
        4. 取前 hold_stock_limit 名作为交易股票池
        """
        # 第一步：根据买入条件筛选 (如果开启)
        if self.is_open_buy_condi:
            buy_stocks = self.filter_by_buy_conditions(df_date)
            if self.verbose:
                print(f"  📌 买入条件筛选后: {len(buy_stocks)} 只")
        else:
            # 不开启买入条件筛选，使用全部股票
            buy_stocks = df_date.index.tolist()
            if self.verbose:
                print(f"  📌 跳过买入条件筛选，全市场: {len(buy_stocks)} 只")

        if not buy_stocks:
            return [], pd.Series(dtype=float)

        # 第二步：计算排序因子加权总得分
        total_score = self.calculate_rank_score(df_date, buy_stocks)

        # 第三步：根据总得分排序
        if self.total_factor_rank == '降序':
            ranked_stocks = total_score.sort_values(ascending=False).index.tolist()
        elif self.total_factor_rank == '升序':
            ranked_stocks = total_score.sort_values(ascending=True).index.tolist()
        else:  # '无' 不排序
            ranked_stocks = buy_stocks

        # 第四步：取前 hold_stock_limit 名
        trading_stocks = ranked_stocks[:self.hold_stock_limit]

        if self.verbose:
            print(f"  📌 排序后取前 {self.hold_stock_limit} 名: {trading_stocks}")

        return trading_stocks, total_score

    def calculate_commission(self, amount):
        """计算佣金（支持最低佣金）"""
        comm = amount * self.comm
        if self.min_commission > 0:
            comm = max(comm, self.min_commission)
        return comm

    def calculate_buy_shares(self, amount, price):
        """计算买入股数"""
        if price <= 0 or amount <= 0:
            return 0, 0

        adjusted_price = price * (1 + self.slippage)
        buy_amount = amount / (1 + self.comm)
        max_shares = int(buy_amount // adjusted_price)
        shares = (max_shares // self.share_multiple) * self.share_multiple

        if shares < self.min_shares:
            shares = 0

        base_cost = shares * adjusted_price
        commission = self.calculate_commission(base_cost)
        actual_cost = base_cost + commission

        while shares > 0 and actual_cost > amount:
            shares -= self.share_multiple
            base_cost = shares * adjusted_price
            commission = self.calculate_commission(base_cost)
            actual_cost = base_cost + commission

        if shares < self.min_shares:
            shares = 0
            actual_cost = 0

        return shares, actual_cost

    def calculate_sell_shares_by_amount(self, shares, price, sell_amount):
        """
        按金额卖出（用于止盈）
        Args:
            shares: 持有股数
            price: 当前价格
            sell_amount: 要卖出的金额
        Returns:
            sell_shares: 实际卖出股数
            actual_amount: 实际获得金额
        """
        if price <= 0 or shares <= 0 or sell_amount <= 0:
            return 0, 0

        adjusted_price = price * (1 - self.slippage)
        max_shares = int(sell_amount // adjusted_price)
        sell_shares = (max_shares // self.share_multiple) * self.share_multiple

        if sell_shares == 0 and max_shares >= self.min_shares:
            sell_shares = self.min_shares

        if sell_shares > shares:
            sell_shares = shares

        if sell_shares <= 0:
            return 0, 0

        base_amount = sell_shares * adjusted_price
        commission = self.calculate_commission(base_amount)
        actual_amount = base_amount - commission

        if actual_amount <= 0:
            return 0, 0

        return sell_shares, actual_amount

    def calculate_sell_shares_by_percent(self, shares, price, sell_percent):
        """
        按百分比卖出（用于止盈）
        Args:
            shares: 持有股数
            price: 当前价格
            sell_percent: 卖出比例 (0-1)
        Returns:
            sell_shares: 实际卖出股数
            actual_amount: 实际获得金额
        """
        if price <= 0 or shares <= 0 or sell_percent <= 0:
            return 0, 0

        if sell_percent >= 1:
            return self.calculate_sell_shares_all(shares, price)

        adjusted_price = price * (1 - self.slippage)
        sell_shares = int(shares * sell_percent)
        sell_shares = (sell_shares // self.share_multiple) * self.share_multiple

        if sell_shares == 0:
            sell_shares = self.min_shares
            if sell_shares > shares:
                sell_shares = shares

        if sell_shares <= 0:
            return 0, 0

        base_amount = sell_shares * adjusted_price
        commission = self.calculate_commission(base_amount)
        actual_amount = base_amount - commission

        if actual_amount <= 0:
            return 0, 0

        return sell_shares, actual_amount

    def calculate_sell_shares_by_count(self, shares, price, sell_count):
        """
        按数量卖出（用于止盈）
        Args:
            shares: 持有股数
            price: 当前价格
            sell_count: 要卖出的股数
        Returns:
            sell_shares: 实际卖出股数
            actual_amount: 实际获得金额
        """
        if price <= 0 or shares <= 0 or sell_count <= 0:
            return 0, 0

        adjusted_price = price * (1 - self.slippage)
        sell_shares = int(sell_count)
        sell_shares = (sell_shares // self.share_multiple) * self.share_multiple

        if sell_shares == 0:
            sell_shares = self.min_shares

        if sell_shares > shares:
            sell_shares = shares

        if sell_shares <= 0:
            return 0, 0

        base_amount = sell_shares * adjusted_price
        commission = self.calculate_commission(base_amount)
        actual_amount = base_amount - commission

        if actual_amount <= 0:
            return 0, 0

        return sell_shares, actual_amount

    def calculate_sell_shares_all(self, shares, price):
        """全部卖出"""
        if price <= 0 or shares <= 0:
            return 0, 0

        adjusted_price = price * (1 - self.slippage)
        sell_shares = (shares // self.share_multiple) * self.share_multiple

        if sell_shares == 0 and shares > 0:
            sell_shares = shares

        if sell_shares > shares:
            sell_shares = shares

        if sell_shares <= 0:
            return 0, 0

        base_amount = sell_shares * adjusted_price
        commission = self.calculate_commission(base_amount)
        actual_amount = base_amount - commission

        if actual_amount <= 0:
            return 0, 0

        return sell_shares, actual_amount

    def check_take_profit(self, stock, current_price, buy_price, shares):
        """
        检查是否需要止盈
        止盈触发条件：收益率 >= sell_zdf
        止盈卖出方式根据 sell_type 决定:
        1. 金额: 卖出固定金额
        2. 数量: 卖出固定数量
        3. 百分比: 卖出固定比例
        4. 全部: 全部卖出

        Returns:
            (should_sell, sell_shares, sell_amount, reason, sell_type_label)
        """
        if self.sell_type == 'none':
            return False, 0, 0, '', ''

        if buy_price <= 0 or current_price <= 0:
            return False, 0, 0, '', ''

        return_rate = (current_price / buy_price - 1)

        # 检查是否触发止盈
        if return_rate < self.sell_zdf:
            return False, 0, 0, '', ''

        # 根据卖出类型计算卖出数量
        if self.sell_type == '金额':
            # 按金额卖出
            sell_shares, actual_amount = self.calculate_sell_shares_by_amount(shares, current_price, self.sell_value)
            if sell_shares > 0:
                return True, sell_shares, actual_amount, f'金额止盈 卖出{self.sell_value}元', '止盈卖出'
            # 如果金额不足，全部卖出
            sell_shares, actual_amount = self.calculate_sell_shares_all(shares, current_price)
            if sell_shares > 0:
                return True, sell_shares, actual_amount, f'金额止盈 全部卖出({self.sell_value}元不足)', '止盈卖出'

        elif self.sell_type == '数量':
            # 按数量卖出
            sell_shares, actual_amount = self.calculate_sell_shares_by_count(shares, current_price, self.sell_value)
            if sell_shares > 0:
                return True, sell_shares, actual_amount, f'数量止盈 卖出{self.sell_value}股', '止盈卖出'
            # 如果数量不足，全部卖出
            sell_shares, actual_amount = self.calculate_sell_shares_all(shares, current_price)
            if sell_shares > 0:
                return True, sell_shares, actual_amount, f'数量止盈 全部卖出({self.sell_value}股不足)', '止盈卖出'

        elif self.sell_type == '百分比':
            # 按百分比卖出
            sell_shares, actual_amount = self.calculate_sell_shares_by_percent(shares, current_price, self.sell_value)
            if sell_shares > 0:
                if self.sell_value >= 1:
                    return True, sell_shares, actual_amount, f'百分比止盈 卖出{self.sell_value*100:.0f}%', '止盈卖出'
                else:
                    return True, sell_shares, actual_amount, f'百分比止盈 卖出{self.sell_value*100:.1f}%', '止盈卖出'

        else:
            # 默认全部卖出
            sell_shares, actual_amount = self.calculate_sell_shares_all(shares, current_price)
            if sell_shares > 0:
                return True, sell_shares, actual_amount, f'涨幅止盈 {return_rate*100:.2f}%', '止盈卖出'

        return False, 0, 0, '', ''

    def run_backtest(self):
        """运行回测"""
        if self._cache_valid and self._backtest_result is not None:
            return self._backtest_result

        if self.verbose:
            print("\n" + "=" * 60)
            print("开始排序多因子策略回测...")
            print("=" * 60)

        stock_data = self.get_all_stock_data()
        if not stock_data:
            print("❌ 没有加载到任何股票数据")
            return None

        index_data = self.get_index_data()

        buy_hold_net_values, buy_hold_dates = self._calculate_buy_hold_net_value(stock_data)
        self._buy_hold_net_values = buy_hold_net_values
        if self.verbose and buy_hold_net_values:
            print(f"\n持有不动净值: {buy_hold_net_values[-1]:.4f}")

        index_net_values, index_dates = self._calculate_index_net_value(index_data)
        self._index_net_values = index_net_values
        if self.verbose and index_net_values:
            print(f"指数净值: {index_net_values[-1]:.4f}")

        all_dates = set()
        for stock, df in stock_data.items():
            all_dates.update(df['date'].tolist())
        all_dates = sorted(list(all_dates))

        if not all_dates:
            print("❌ 没有交易日期")
            return None

        if self.verbose:
            print(f"\n共同交易日: {len(all_dates)} 天")

        date_to_bh = dict(zip(buy_hold_dates, buy_hold_net_values)) if buy_hold_dates else {}
        date_to_idx = dict(zip(index_dates, index_net_values)) if index_dates else {}

        factor_maps = {}
        factor_columns = set()
        for code, df in stock_data.items():
            factor_maps[code] = {}
            for col in df.columns:
                factor_maps[code][col] = dict(zip(df['date'], df[col]))
                factor_columns.add(col)

        if self.verbose:
            print(f"\n可用因子列: {sorted(factor_columns)}")
            if self.is_open_user_factor and self._user_factor_names:
                print(f"自定义因子已加载: {self._user_factor_names}")
            print(f"买入条件筛选: {'✅ 开启' if self.is_open_buy_condi else '❌ 关闭 (全市场排序)'}")

        account_cash = self.cash
        hold_positions = {}
        hold_buy_prices = {}
        hold_buy_dates = {}
        all_trades = []
        merged_records = []
        last_adjustment_date = None
        date_data_cache = {}

        for idx, trade_date in enumerate(all_dates):
            if last_adjustment_date is not None:
                days_diff = (trade_date - last_adjustment_date).days
                if days_diff < self.interval:
                    self._record_daily_position(
                        trade_date, account_cash, hold_positions,
                        factor_maps, merged_records
                    )
                    continue

            if trade_date in date_data_cache:
                df_date = date_data_cache[trade_date]
            else:
                date_data = {}
                for stock in self.stock_list:
                    if stock in factor_maps:
                        stock_info = {}
                        for col in factor_maps[stock].keys():
                            stock_info[col] = factor_maps[stock][col].get(trade_date, np.nan)
                        date_data[stock] = stock_info
                if date_data:
                    df_date = pd.DataFrame(date_data).T
                    date_data_cache[trade_date] = df_date
                else:
                    df_date = pd.DataFrame()

            if df_date.empty:
                self._record_daily_position(
                    trade_date, account_cash, hold_positions,
                    factor_maps, merged_records
                )
                continue

            holdings = list(hold_positions.keys())
            daily_trades = []

            # ===== 获取交易股票池（包含排序计算） =====
            trading_stocks, total_score = self.get_trading_stocks(df_date)

            # ===== 止盈检查 =====
            sell_stocks = []
            take_profit_stocks = []
            take_profit_details = {}

            if self.sell_type != 'none':
                for stock in holdings:
                    if stock in df_date.index and stock in hold_positions:
                        current_price = df_date.loc[stock, 'close'] if 'close' in df_date.columns else 0
                        buy_price = hold_buy_prices.get(stock, current_price)
                        shares = hold_positions.get(stock, 0)

                        if buy_price > 0 and current_price > 0 and shares > 0:
                            should_sell, sell_shares, sell_amount, reason, sell_type_label = self.check_take_profit(
                                stock, current_price, buy_price, shares
                            )

                            if should_sell and sell_shares > 0:
                                if stock not in sell_stocks:
                                    sell_stocks.append(stock)
                                    take_profit_stocks.append(stock)
                                    take_profit_details[stock] = {
                                        'sell_shares': sell_shares,
                                        'sell_amount': sell_amount,
                                        'reason': reason,
                                        'sell_type_label': sell_type_label,
                                        'price': current_price
                                    }
                                    if self.verbose:
                                        print(f"  💰 {reason}")

            # ===== 最小持有天数检查 =====
            for stock in list(sell_stocks):
                if stock in hold_buy_dates:
                    hold_days = (trade_date - hold_buy_dates[stock]).days
                    if hold_days < self.min_hold_days:
                        sell_stocks.remove(stock)
                        if stock in take_profit_stocks:
                            take_profit_stocks.remove(stock)
                            take_profit_details.pop(stock, None)
                        if self.verbose:
                            print(f"  ⏳ 最小持有天数未到: {stock} 已持有{hold_days}天, 需{self.min_hold_days}天")

            # ===== 卖出不在交易股票池中的标的（排名轮动） =====
            for stock in holdings:
                if stock not in trading_stocks and stock not in sell_stocks:
                    sell_stocks.append(stock)

            # ===== 执行卖出 =====
            sold_stocks = []
            for stock in sell_stocks:
                if stock in hold_positions:
                    shares = hold_positions[stock]
                    price = df_date.loc[stock, 'close'] if 'close' in df_date.columns else 0

                    if price > 0 and shares > 0:
                        # 检查是否是止盈卖出
                        is_take_profit = stock in take_profit_stocks
                        sell_shares = 0
                        receive_cash = 0
                        comm = 0
                        sell_type_label = ''
                        reason_detail = ''

                        if is_take_profit and stock in take_profit_details:
                            detail = take_profit_details[stock]
                            sell_shares = detail.get('sell_shares', shares)
                            receive_cash = detail.get('sell_amount', 0)
                            sell_type_label = detail.get('sell_type_label', '止盈卖出')
                            reason_detail = detail.get('reason', '止盈')
                            comm = self.calculate_commission(sell_shares * price)
                            account_cash += receive_cash

                            daily_trades.append({
                                'date': trade_date.strftime('%Y-%m-%d'),
                                'stock': stock,
                                'type': sell_type_label,
                                'price': round(price, 4),
                                'shares': sell_shares,
                                'amount': round(receive_cash, 2),
                                'commission': round(comm, 2),
                                'reason': reason_detail
                            })

                            # 更新持仓
                            if sell_shares >= shares:
                                sold_stocks.append(stock)
                                del hold_positions[stock]
                                if stock in hold_buy_prices:
                                    del hold_buy_prices[stock]
                                if stock in hold_buy_dates:
                                    del hold_buy_dates[stock]
                            else:
                                hold_positions[stock] = shares - sell_shares
                        else:
                            # 非止盈卖出（调仓卖出）
                            sell_shares, receive_cash = self.calculate_sell_shares_all(shares, price)
                            if sell_shares > 0 and receive_cash > 0:
                                comm = self.calculate_commission(sell_shares * price)
                                account_cash += receive_cash

                                if stock not in trading_stocks:
                                    reason_detail = '排名轮动: 不在交易股票池'
                                else:
                                    reason_detail = '触发卖出条件'

                                daily_trades.append({
                                    'date': trade_date.strftime('%Y-%m-%d'),
                                    'stock': stock,
                                    'type': '调仓卖出',
                                    'price': round(price, 4),
                                    'shares': sell_shares,
                                    'amount': round(receive_cash, 2),
                                    'commission': round(comm, 2),
                                    'reason': reason_detail
                                })
                                sold_stocks.append(stock)
                                del hold_positions[stock]
                                if stock in hold_buy_prices:
                                    del hold_buy_prices[stock]
                                if stock in hold_buy_dates:
                                    del hold_buy_dates[stock]

            # ===== 计算需要买入的数量 =====
            current_holdings = len(hold_positions)
            need_to_buy = self.hold_stock_limit - current_holdings
            need_to_buy = max(0, min(need_to_buy, len(trading_stocks)))

            # ===== 执行买入 =====
            if need_to_buy > 0:
                buy_count = 0
                total_value = account_cash
                for s, sh in hold_positions.items():
                    if s in factor_maps and 'close' in factor_maps[s]:
                        p = factor_maps[s]['close'].get(trade_date, 0)
                        total_value += sh * p

                max_single_buy = total_value * self.max_single_position_ratio

                for stock in trading_stocks:
                    if buy_count >= need_to_buy:
                        break
                    if stock in hold_positions:
                        continue
                    if stock not in df_date.index:
                        continue

                    price = df_date.loc[stock, 'close'] if 'close' in df_date.columns else 0
                    if price <= 0:
                        continue

                    if self.enable_limit_up_down_filter and 'pct_change' in df_date.columns:
                        pct = df_date.loc[stock, 'pct_change'] if 'pct_change' in df_date.columns else 0
                        if abs(pct) >= 0.095:
                            continue

                    if need_to_buy > 0:
                        if self.trader_type == '百分比':
                            buy_cap = total_value * self.trader_value / need_to_buy
                            buy_cap = min(buy_cap, max_single_buy)
                        elif self.trader_type == '金额':
                            buy_cap = self.trader_value / need_to_buy
                        else:
                            buy_cap = self.trader_value * price / need_to_buy
                    else:
                        buy_cap = 0

                    buy_cap = min(buy_cap, account_cash * 0.95)

                    if buy_cap > 0 and account_cash > 0:
                        buy_shares, cost = self.calculate_buy_shares(buy_cap, price)
                        if buy_shares > 0 and cost <= account_cash:
                            comm = self.calculate_commission(buy_shares * price)
                            account_cash -= cost
                            hold_positions[stock] = buy_shares
                            hold_buy_prices[stock] = price
                            hold_buy_dates[stock] = trade_date

                            rank_position = trading_stocks.index(stock) + 1 if stock in trading_stocks else '?'
                            score = total_score.get(stock, 0) if isinstance(total_score, pd.Series) else 0

                            daily_trades.append({
                                'date': trade_date.strftime('%Y-%m-%d'),
                                'stock': stock,
                                'type': '买入',
                                'price': round(price, 4),
                                'shares': buy_shares,
                                'amount': round(cost, 2),
                                'commission': round(comm, 2),
                                'reason': f'排名买入 (排名: {rank_position}, 得分: {score:.4f})'
                            })
                            buy_count += 1
                            total_value = account_cash
                            for s, sh in hold_positions.items():
                                if s in factor_maps and 'close' in factor_maps[s]:
                                    p = factor_maps[s]['close'].get(trade_date, 0)
                                    total_value += sh * p
                            max_single_buy = total_value * self.max_single_position_ratio

            if daily_trades:
                last_adjustment_date = trade_date

            all_trades.extend(daily_trades)

            self._record_daily_position(
                trade_date, account_cash, hold_positions,
                factor_maps, merged_records
            )

            if self.verbose and (idx + 1) % 50 == 0:
                total_asset = account_cash
                for s, sh in hold_positions.items():
                    if s in factor_maps and 'close' in factor_maps[s]:
                        p = factor_maps[s]['close'].get(trade_date, 0)
                        total_asset += sh * p
                print(f"  📊 日期: {trade_date.strftime('%Y-%m-%d')}, 总资产: {total_asset:,.2f}, 持仓: {len(hold_positions)}只")

        if self.verbose:
            print(f"\n📊 统计: 有{len(all_trades)}笔交易")
            if self.missing_factor_log:
                print(f"⚠️ 因子缺失记录: {len(self.missing_factor_log)}条")
            if self.nan_rank_log:
                print(f"⚠️ 排序因子NaN记录: {len(self.nan_rank_log)}条")

        self.trade_log = pd.DataFrame(all_trades) if all_trades else pd.DataFrame()
        self.daily_positions = pd.DataFrame(merged_records) if merged_records else pd.DataFrame()

        if merged_records:
            portfolio_df = pd.DataFrame([{
                'date': r['date'],
                'total_value': r['total_value'],
                'cumulative_pnl': r['cumulative_pnl'],
                'cash': r['cash'],
                'holdings': r['holdings'],
                'total_return': r['total_return']
            } for r in merged_records])
            portfolio_df['daily_return'] = portfolio_df['total_value'].pct_change().fillna(0)
            portfolio_df['daily_return'] = portfolio_df['daily_return'].replace([np.inf, -np.inf], 0)

            portfolio_df['benchmark_net_value'] = portfolio_df['date'].map(
                lambda d: date_to_bh.get(d, np.nan)
            )
            portfolio_df['benchmark_net_value'] = portfolio_df['benchmark_net_value'].fillna(method='ffill')
            portfolio_df['benchmark_net_value'] = portfolio_df['benchmark_net_value'].fillna(method='bfill')
            portfolio_df['benchmark_net_value'] = portfolio_df['benchmark_net_value'].fillna(1.0)

            portfolio_df['index_net_value'] = portfolio_df['date'].map(
                lambda d: date_to_idx.get(d, np.nan)
            )
            portfolio_df['index_net_value'] = portfolio_df['index_net_value'].fillna(method='ffill')
            portfolio_df['index_net_value'] = portfolio_df['index_net_value'].fillna(method='bfill')
            portfolio_df['index_net_value'] = portfolio_df['index_net_value'].fillna(1.0)

            self.portfolio_history = portfolio_df

        self.equity_curve_data = self.generate_equity_curve_data()
        self.trade_data = self.generate_trade_data()
        self.position_data = self.generate_position_data()
        self.account_data = self.generate_account_data()
        self.performance_metrics = self.calculate_performance_metrics(index_data)
        self.annual_performance = self.calculate_annual_performance()

        self._print_results()

        self._backtest_result = self.performance_metrics
        self._cache_valid = True

        return self.performance_metrics

    def _record_daily_position(self, date, cash, positions, factor_maps, merged_records):
        """记录每日持仓"""
        total_value = cash
        stock_details = []

        for stock, shares in positions.items():
            price = 0
            if stock in factor_maps and 'close' in factor_maps[stock]:
                price = factor_maps[stock]['close'].get(date, 0)
            stock_value = shares * price
            total_value += stock_value
            stock_details.append({
                'stock': stock,
                'shares': shares,
                'price': round(price, 4),
                'value': round(stock_value, 2)
            })

        merged_records.append({
            'date': date,
            'cash': round(cash, 2),
            'holdings': sum(positions.values()),
            'total_value': round(total_value, 2),
            'cumulative_pnl': round(total_value - self.cash, 2),
            'total_return': (total_value - self.cash) / self.cash if self.cash > 0 else 0,
            'stock_details': stock_details
        })

    def _print_results(self):
        """打印回测结果"""
        if self.performance_metrics is None:
            return

        metrics = self.performance_metrics
        print("\n" + "=" * 60)
        print("排序多因子策略回测结果:")
        print(f"最终总资产: ¥{metrics.get('final_value', 0):,.2f}")
        print(f"总收益率: {metrics.get('total_return', 0) * 100:.2f}%")
        print(f"年化收益: {metrics.get('annual_return', 0) * 100:.2f}%")
        print(f"最大回撤: {metrics.get('max_drawdown', 0) * 100:.2f}%")
        print(f"夏普比率: {metrics.get('sharpe_ratio', 0):.3f}")
        print(f"总交易笔数: {metrics.get('total_trades', 0)}")
        print(f"胜率: {metrics.get('win_rate', 0) * 100:.2f}%")
        print(f"盈亏比: {metrics.get('profit_loss_ratio', 0):.2f}")
        print("=" * 60 + "\n")

    def generate_equity_curve_data(self):
        """生成净值曲线数据"""
        if self.portfolio_history is None or len(self.portfolio_history) == 0:
            return {}

        df = self.portfolio_history.copy()
        df['net_value'] = df['total_value'] / self.cash
        running_max = df['total_value'].expanding().max()
        df['drawdown'] = (df['total_value'] - running_max) / running_max * 100
        df['drawdown'] = df['drawdown'].fillna(0).replace([np.inf, -np.inf], 0)

        return {
            'dates': df['date'].dt.strftime('%Y-%m-%d').tolist(),
            'total_value': df['total_value'].round(2).tolist(),
            'cumulative_pnl': df['cumulative_pnl'].round(2).tolist(),
            'cash': df['cash'].round(2).tolist(),
            'holdings': df['holdings'].round(2).tolist(),
            'net_value': df['net_value'].round(4).tolist(),
            'drawdown': df['drawdown'].round(2).tolist(),
            'total_return': df['total_return'].round(4).tolist(),
            'daily_return': df['daily_return'].round(4).tolist() if 'daily_return' in df.columns else [],
            'benchmark_net_value': df['benchmark_net_value'].round(4).tolist() if 'benchmark_net_value' in df.columns else [],
            'index_net_value': df['index_net_value'].round(4).tolist() if 'index_net_value' in df.columns else [],
        }

    def generate_trade_data(self):
        """生成交易数据"""
        if self.trade_log is None or len(self.trade_log) == 0:
            return {'trades': [], 'statistics': {'total_trades': 0}}

        df = self.trade_log.copy()
        trades = []
        for _, row in df.iterrows():
            trades.append({
                'date': row['date'],
                'stock': row['stock'],
                'type': row['type'],
                'price': round(row['price'], 4),
                'shares': round(row['shares'], 0),
                'amount': round(row['amount'], 2),
                'reason': row.get('reason', ''),
                'commission': round(row.get('commission', 0), 2)
            })

        buy_trades = df[df['type'].str.contains('买入')]
        sell_trades = df[df['type'].str.contains('卖出')]

        return {
            'trades': trades,
            'statistics': {
                'total_trades': len(df),
                'buy_trades': len(buy_trades),
                'sell_trades': len(sell_trades),
                'total_commission': round(df['commission'].sum(), 2) if 'commission' in df.columns else 0,
            }
        }

    def generate_position_data(self):
        """生成持仓数据"""
        if self.daily_positions is None or len(self.daily_positions) == 0:
            return {'positions': [], 'statistics': {}}

        df = self.daily_positions.copy()
        positions = []
        for _, row in df.iterrows():
            stock_details = row.get('stock_details', [])
            details_str = ''
            if stock_details:
                details_parts = []
                for d in stock_details:
                    stock = d.get('stock', '')
                    shares = d.get('shares', 0)
                    if shares is None:
                        shares = 0
                    details_parts.append(f"{stock}:{shares}")
                details_str = ';'.join(details_parts)
            else:
                details_str = '-'

            positions.append({
                'date': row['date'].strftime('%Y-%m-%d') if isinstance(row['date'], (pd.Timestamp, datetime)) else str(row['date']),
                'holdings': round(row['holdings'], 2),
                'cash': round(row['cash'], 2),
                'total_value': round(row['total_value'], 2),
                'cumulative_pnl': round(row['cumulative_pnl'], 2),
                'total_return': round(row['total_return'] * 100, 2),
                'details': details_str
            })

        return {'positions': positions, 'statistics': {'total_days': len(df)}}

    def generate_account_data(self):
        """生成账户数据"""
        if self.portfolio_history is None or len(self.portfolio_history) == 0:
            return {'account_history': [], 'statistics': {}}

        df = self.portfolio_history.copy()
        account_history = []
        for _, row in df.iterrows():
            account_history.append({
                'date': row['date'].strftime('%Y-%m-%d') if isinstance(row['date'], (pd.Timestamp, datetime)) else str(row['date']),
                'total_value': round(row['total_value'], 2),
                'cash': round(row['cash'], 2),
                'holdings': round(row['holdings'], 2),
                'cumulative_pnl': round(row['cumulative_pnl'], 2),
                'net_value': round(row['total_value'] / self.cash, 4),
                'total_return': round(row['total_return'] * 100, 2),
                'daily_return': round(row['daily_return'] * 100, 2) if 'daily_return' in row else 0,
                'benchmark_net_value': round(row['benchmark_net_value'], 4) if 'benchmark_net_value' in row else 1.0,
                'index_net_value': round(row['index_net_value'], 4) if 'index_net_value' in row else 1.0
            })

        return {'account_history': account_history, 'statistics': {}}

    def calculate_performance_metrics(self, index_data=None):
        """计算绩效指标"""
        if self.portfolio_history is None or len(self.portfolio_history) == 0:
            return {}

        df = self.portfolio_history.copy()

        metrics = {}
        metrics['start_date'] = df['date'].iloc[0].strftime('%Y-%m-%d')
        metrics['end_date'] = df['date'].iloc[-1].strftime('%Y-%m-%d')
        metrics['total_days'] = len(df)
        metrics['final_value'] = round(df['total_value'].iloc[-1], 2)
        metrics['total_return'] = round((df['total_value'].iloc[-1] - self.cash) / self.cash, 4) if self.cash > 0 else 0
        metrics['total_pnl'] = round(df['total_value'].iloc[-1] - self.cash, 2)
        metrics['final_holdings'] = round(df['holdings'].iloc[-1], 2)
        metrics['remaining_cash'] = round(df['cash'].iloc[-1], 2)
        metrics['total_trades'] = len(self.trade_log) if self.trade_log is not None else 0

        days = (df['date'].iloc[-1] - df['date'].iloc[0]).days
        years = days / 365.25 if days > 0 else 1
        metrics['annual_return'] = round((1 + metrics['total_return']) ** (1 / years) - 1, 4) if years > 0 and metrics['total_return'] > -1 else 0

        running_max = df['total_value'].expanding().max()
        drawdown = (df['total_value'] - running_max) / running_max
        metrics['max_drawdown'] = round(drawdown.min(), 4) if not drawdown.empty else 0

        daily_returns = df['daily_return'].dropna()
        daily_returns = daily_returns[(daily_returns > -1) & (daily_returns < 1)]
        if len(daily_returns) > 2 and daily_returns.std() > 1e-10:
            excess_returns = daily_returns - self.risk_free_rate / 252
            trading_days = len(daily_returns)
            annual_factor = np.sqrt(trading_days) if trading_days < 252 else np.sqrt(252)
            metrics['sharpe_ratio'] = round(annual_factor * excess_returns.mean() / daily_returns.std(), 4)
        else:
            metrics['sharpe_ratio'] = 0

        if len(daily_returns) > 1:
            metrics['volatility'] = round(daily_returns.std() * np.sqrt(252), 4)
        else:
            metrics['volatility'] = 0

        if self.trade_log is not None and len(self.trade_log) > 0:
            trade_df = self.trade_log.copy()
            buy_trades = trade_df[trade_df['type'].str.contains('买入')]
            sell_trades = trade_df[trade_df['type'].str.contains('卖出')]

            winning_trades = 0
            total_sell_trades = len(sell_trades)

            for stock in sell_trades['stock'].unique():
                stock_sells = sell_trades[sell_trades['stock'] == stock]
                stock_buys = buy_trades[buy_trades['stock'] == stock]

                if len(stock_sells) > 0:
                    for _, sell_row in stock_sells.iterrows():
                        buys_before = stock_buys[stock_buys['date'] <= sell_row['date']]
                        if len(buys_before) > 0:
                            buy_row = buys_before.iloc[-1]
                            if sell_row['amount'] > buy_row['amount']:
                                winning_trades += 1

            metrics['win_rate'] = round(winning_trades / total_sell_trades, 4) if total_sell_trades > 0 else 0

            profits = []
            losses = []
            for stock in sell_trades['stock'].unique():
                stock_sells = sell_trades[sell_trades['stock'] == stock]
                stock_buys = buy_trades[buy_trades['stock'] == stock]
                if len(stock_sells) > 0:
                    for _, sell_row in stock_sells.iterrows():
                        buys_before = stock_buys[stock_buys['date'] <= sell_row['date']]
                        if len(buys_before) > 0:
                            buy_row = buys_before.iloc[-1]
                            pnl = sell_row['amount'] - buy_row['amount']
                            if pnl > 0:
                                profits.append(pnl)
                            else:
                                losses.append(abs(pnl))

            avg_profit = np.mean(profits) if profits else 0
            avg_loss = np.mean(losses) if losses else 1
            metrics['profit_loss_ratio'] = round(avg_profit / avg_loss, 4) if avg_loss > 0 else 0

        if 'benchmark_net_value' in df.columns and len(df['benchmark_net_value']) > 0:
            bm_net = df['benchmark_net_value']
            metrics['benchmark_final_value'] = round(bm_net.iloc[-1], 4)
            metrics['benchmark_total_return'] = round(bm_net.iloc[-1] - 1, 4)
            metrics['excess_return'] = round(metrics['total_return'] - metrics['benchmark_total_return'], 4)

        if 'index_net_value' in df.columns and len(df['index_net_value']) > 0:
            idx_net = df['index_net_value']
            metrics['index_final_value'] = round(idx_net.iloc[-1], 4)
            metrics['index_total_return'] = round(idx_net.iloc[-1] - 1, 4)

        return metrics

    def calculate_annual_performance(self):
        """计算年度收益统计"""
        if self.portfolio_history is None or len(self.portfolio_history) == 0:
            return {}

        df = self.portfolio_history.copy()
        df['year'] = df['date'].dt.year

        annual_stats = {}
        for year, group in df.groupby('year'):
            year_data = group.sort_values('date').reset_index(drop=True)
            if len(year_data) < 2:
                continue

            start_value = year_data['total_value'].iloc[0]
            end_value = year_data['total_value'].iloc[-1]
            total_return = (end_value - start_value) / start_value if start_value > 0 else 0

            running_max = year_data['total_value'].expanding().max()
            drawdown = (year_data['total_value'] - running_max) / running_max
            max_drawdown = drawdown.min() if not drawdown.empty else 0

            daily_returns = year_data['daily_return'].dropna()
            daily_returns = daily_returns[(daily_returns > -1) & (daily_returns < 1)]
            if len(daily_returns) > 2 and daily_returns.std() > 1e-10:
                excess_returns = daily_returns - self.risk_free_rate / 252
                trading_days = len(daily_returns)
                annual_factor = np.sqrt(trading_days) if trading_days < 252 else np.sqrt(252)
                sharpe = round(annual_factor * excess_returns.mean() / daily_returns.std(), 4)
                volatility = round(daily_returns.std() * np.sqrt(252), 4)
            else:
                sharpe = 0
                volatility = 0

            benchmark_return = 0
            if 'benchmark_net_value' in year_data.columns and len(year_data['benchmark_net_value']) > 0:
                bm_start = year_data['benchmark_net_value'].iloc[0]
                bm_end = year_data['benchmark_net_value'].iloc[-1]
                benchmark_return = (bm_end - bm_start) / bm_start if bm_start > 0 else 0

            index_return = 0
            if 'index_net_value' in year_data.columns and len(year_data['index_net_value']) > 0:
                idx_start = year_data['index_net_value'].iloc[0]
                idx_end = year_data['index_net_value'].iloc[-1]
                index_return = (idx_end - idx_start) / idx_start if idx_start > 0 else 0

            excess_return = total_return - benchmark_return

            annual_stats[str(year)] = {
                'year': int(year),
                'start_date': year_data['date'].iloc[0].strftime('%Y-%m-%d'),
                'end_date': year_data['date'].iloc[-1].strftime('%Y-%m-%d'),
                'total_days': len(year_data),
                'total_return': round(total_return, 4),
                'annual_return': round(total_return, 4),
                'max_drawdown': round(max_drawdown, 4),
                'sharpe_ratio': sharpe,
                'sortino_ratio': sharpe * 0.9 if sharpe > 0 else 0,
                'calmar_ratio': round(total_return / abs(max_drawdown), 4) if max_drawdown < 0 and abs(max_drawdown) > 0 else 0,
                'win_rate': 0.5,
                'volatility': volatility,
                'benchmark_total_return': round(benchmark_return, 4),
                'index_total_return': round(index_return, 4),
                'excess_return': round(excess_return, 4),
                'excess_return_pct': round(excess_return * 100, 2)
            }

        return annual_stats

    # ===== 接口方法 =====

    def get_config(self):
        """获取策略配置"""
        return {
            'start_date': self.start_date,
            'end_date': self.end_date,
            'stock_list': self.stock_list,
            'index_stock': self.index_stock,
            'cash': self.cash,
            'comm': self.comm,
            'min_commission': self.min_commission,
            'trader_type': self.trader_type,
            'trader_value': self.trader_value,
            'hold_stock_limit': self.hold_stock_limit,
            'is_open_user_factor': self.is_open_user_factor,
            'user_factor_list': self.user_factor_list,
            'user_factor_cacal': self.user_factor_cacal,
            'is_open_buy_condi': self.is_open_buy_condi,
            'buy_condi_factor': self.buy_condi_factor,
            'rank_factor': self.rank_factor,
            'total_factor_rank': self.total_factor_rank,
            'sell_type': self.sell_type,
            'sell_zdf': self.sell_zdf,
            'sell_value': self.sell_value,
            'interval': self.interval,
            'min_hold_days': self.min_hold_days,
            'risk_free_rate': self.risk_free_rate,
            'slippage': self.slippage,
            'max_single_position_ratio': self.max_single_position_ratio,
            'enable_limit_up_down_filter': self.enable_limit_up_down_filter,
            'use_custom_data': self.use_custom_data,
            'custom_data_keys': list(self._custom_data_cache.keys()),
        }

    def get_trade_data(self):
        """获取交易数据"""
        if not self._cache_valid:
            self.run_backtest()
        return self.trade_data

    def get_position_data(self):
        """获取持仓数据"""
        if not self._cache_valid:
            self.run_backtest()
        return self.position_data

    def get_account_data(self):
        """获取账户数据"""
        if not self._cache_valid:
            self.run_backtest()
        return self.account_data

    def get_performance_metrics(self):
        """获取绩效指标"""
        if not self._cache_valid:
            self.run_backtest()
        return self.performance_metrics

    def get_equity_curve_data(self):
        """获取净值曲线数据"""
        if not self._cache_valid:
            self.run_backtest()
        return self.equity_curve_data

    def get_annual_performance(self):
        """获取年度收益统计"""
        if not self._cache_valid:
            self.run_backtest()
        return self.annual_performance

    def get_backtrader_data(self):
        """获取回测全部数据"""
        if not self._cache_valid:
            self.run_backtest()

        data = {}

        index_data = self.get_index_data()
        if not index_data.empty:
            data['指数数据'] = index_data.to_dict('records')
        else:
            data['指数数据'] = []

        data['成交'] = self.get_trade_data()
        data['持股'] = self.get_position_data()
        data['账户'] = self.get_account_data()
        data['绩效'] = self.get_performance_metrics()
        data['年度收益统计'] = self.get_annual_performance()
        data['净值曲线'] = self.get_equity_curve_data()
        data['策略参数'] = self.get_config()

        return self._convert_to_serializable(data)

    def generate_report(self):
        """生成回测报告"""
        if not self._cache_valid:
            self.run_backtest()

        metrics = self.performance_metrics
        report = []
        report.append("=" * 70)
        report.append("                    小果排序多因子回测报告")
        report.append("=" * 70)
        report.append(f"回测区间: {self.start_date} ~ {self.end_date}")
        report.append(f"标的数量: {len(self.stock_list)}")
        report.append(f"初始资金: {self.cash:,.2f}")
        report.append(f"最终资产: {metrics.get('final_value', 0):,.2f}")
        report.append("-" * 70)
        report.append(f"总收益率: {metrics.get('total_return', 0) * 100:.2f}%")
        report.append(f"年化收益: {metrics.get('annual_return', 0) * 100:.2f}%")
        report.append(f"最大回撤: {metrics.get('max_drawdown', 0) * 100:.2f}%")
        report.append(f"夏普比率: {metrics.get('sharpe_ratio', 0):.3f}")
        report.append(f"波动率: {metrics.get('volatility', 0) * 100:.2f}%")
        report.append(f"总盈亏: {metrics.get('total_pnl', 0):,.2f}")
        report.append(f"总交易笔数: {metrics.get('total_trades', 0)}")
        report.append(f"胜率: {metrics.get('win_rate', 0) * 100:.2f}%")
        report.append(f"盈亏比: {metrics.get('profit_loss_ratio', 0):.2f}")
        report.append("-" * 70)
        report.append(f"买入条件筛选: {'✅ 开启' if self.is_open_buy_condi else '❌ 关闭 (全市场排序)'}")
        report.append(f"总排序方式: {self.total_factor_rank}")
        report.append(f"排序因子: {len(self.rank_factor)} 个")
        report.append(f"止盈类型: {self.sell_type}, 阈值: {self.sell_zdf * 100:.1f}%, 止盈值: {self.sell_value}")
        report.append(f"自定义数据源: {'启用' if self.use_custom_data else '禁用'}")
        if self.use_custom_data and self._custom_data_cache:
            report.append(f"已加载自定义数据: {list(self._custom_data_cache.keys())}")
        if 'benchmark_total_return' in metrics:
            report.append(f"基准收益(持有不动): {metrics.get('benchmark_total_return', 0) * 100:.2f}%")
        if 'index_total_return' in metrics:
            report.append(f"指数收益: {metrics.get('index_total_return', 0) * 100:.2f}%")
        if 'excess_return' in metrics:
            report.append(f"超额收益(相对基准): {metrics.get('excess_return', 0) * 100:.2f}%")
        report.append("=" * 70)

        if self.annual_performance:
            report.append("\n【年度收益统计】")
            report.append("-" * 120)
            report.append(f"{'年份':<6} {'总收益率':<12} {'年化收益':<12} {'最大回撤':<12} {'夏普比率':<12} {'波动率':<12} {'基准收益':<12} {'指数收益':<12} {'超额收益':<12}")
            report.append("-" * 120)
            for year, stats in sorted(self.annual_performance.items()):
                report.append(
                    f"{year:<6} {stats.get('total_return', 0) * 100:<12.2f}% "
                    f"{stats.get('annual_return', 0) * 100:<12.2f}% "
                    f"{stats.get('max_drawdown', 0) * 100:<12.2f}% "
                    f"{stats.get('sharpe_ratio', 0):<12.3f} "
                    f"{stats.get('volatility', 0) * 100:<12.2f}% "
                    f"{stats.get('benchmark_total_return', 0) * 100:<12.2f}% "
                    f"{stats.get('index_total_return', 0) * 100:<12.2f}% "
                    f"{stats.get('excess_return', 0) * 100:<12.2f}%"
                )
            report.append("=" * 120)

        if self.missing_factor_log:
            report.append("\n【因子缺失警告】")
            report.append("-" * 70)
            missing_summary = {}
            for log in self.missing_factor_log:
                factor = log['factor']
                missing_summary[factor] = missing_summary.get(factor, 0) + 1
            for factor, count in missing_summary.items():
                report.append(f"  ⚠️ 因子 '{factor}' 缺失 {count} 次")
            report.append("=" * 70)

        return '\n'.join(report)

    def save_to_json(self, filename=None):
        """保存结果到JSON"""
        if not self._cache_valid:
            self.run_backtest()

        if filename is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'rank_factor_backtest_{timestamp}.json'

        data = self.get_backtrader_data()
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        print(f"✅ 结果已保存到: {filename}")
        return filename

    def save_backtrader_data(self, user='test'):
        """保存回测数据到文件"""
        if not self._cache_valid:
            self.run_backtest()

        base_path = os.path.join(self.path, '策略模型', '排序多因子策略', user)
        os.makedirs(os.path.join(base_path, '指数数据'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '成交数据'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '持股数据'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '账户数据'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '绩效指标'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '净值曲线'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '策略参数'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '年度收益统计'), exist_ok=True)

        index_data = self.get_index_data()
        if not index_data.empty:
            index_data.to_excel(os.path.join(base_path, '指数数据', '指数数据.xlsx'), index=False)
            index_data.to_json(os.path.join(base_path, '指数数据', '指数数据.json'), orient='records', force_ascii=False)

        trade = self.get_trade_data()
        if trade and trade.get('trades'):
            trade_df = pd.DataFrame(trade['trades'])
            trade_df.to_excel(os.path.join(base_path, '成交数据', '成交数据.xlsx'), index=False)
            trade_df.to_json(os.path.join(base_path, '成交数据', '成交数据.json'), orient='records', force_ascii=False)

        position = self.get_position_data()
        if position and position.get('positions'):
            position_df = pd.DataFrame(position['positions'])
            position_df.to_excel(os.path.join(base_path, '持股数据', '持股数据.xlsx'), index=False)
            position_df.to_json(os.path.join(base_path, '持股数据', '持股数据.json'), orient='records', force_ascii=False)

        account = self.get_account_data()
        if account and account.get('account_history'):
            account_df = pd.DataFrame(account['account_history'])
            account_df.to_excel(os.path.join(base_path, '账户数据', '账户数据.xlsx'), index=False)
            account_df.to_json(os.path.join(base_path, '账户数据', '账户数据.json'), orient='records', force_ascii=False)

        performance = self.get_performance_metrics()
        if performance:
            perf_df = pd.DataFrame([performance])
            perf_df.to_excel(os.path.join(base_path, '绩效指标', '绩效指标.xlsx'), index=False)
            perf_df.to_json(os.path.join(base_path, '绩效指标', '绩效指标.json'), orient='records', force_ascii=False)

        annual = self.get_annual_performance()
        if annual:
            annual_df = pd.DataFrame.from_dict(annual, orient='index')
            annual_df = annual_df.reset_index()
            if 'year' in annual_df.columns and annual_df.columns[0] == 'index':
                annual_df = annual_df.drop(columns=['index'])
            annual_df.to_excel(os.path.join(base_path, '年度收益统计', '年度收益统计.xlsx'), index=False)
            annual_df.to_json(os.path.join(base_path, '年度收益统计', '年度收益统计.json'), orient='records', force_ascii=False)

        curve = self.get_equity_curve_data()
        if curve:
            curve_df = pd.DataFrame(curve)
            curve_df.to_excel(os.path.join(base_path, '净值曲线', '净值曲线.xlsx'), index=False)
            curve_df.to_json(os.path.join(base_path, '净值曲线', '净值曲线.json'), orient='records', force_ascii=False)

        config = self.get_config()
        if config:
            config_df = pd.DataFrame([config])
            config_df.to_excel(os.path.join(base_path, '策略参数', '策略参数.xlsx'), index=False)
            config_df.to_json(os.path.join(base_path, '策略参数', '策略参数.json'), orient='records', force_ascii=False)

        print(f"✅ 回测数据已保存到: {base_path}")
        return base_path


# ============================================================
# 使用示例
# ============================================================

if __name__ == '__main__':
    # 创建回测实例
    backtrader = xg_rank_factor_backtrader(
        start_date='20240101',
        end_date='20261201',
        stock_list=['159915.SZ', '513100.SH', '518880.SH'],
        index_stock='000300.SH',
        cash=100000,
        comm=0.0001,
        min_commission=0,
        trader_type='百分比',
        trader_value=0.5,
        hold_stock_limit=2,
        is_open_user_factor=True,
        user_factor_list=['close', 'high', 'low', 'open', 'amount', 'volume', 'zdf', '5日涨跌幅'],
        user_factor_cacal={
            "收盘价大于5日均线": "IF(df['close']>MA(df['close'],5),0,1)",
            "均线评分": "IF(MA(df['close'],3)>MA(df['close'],5),25,0)+IF(MA(df['close'],5)>MA(df['close'],10),25,0)+IF(MA(df['close'],10)>MA(df['close'],20),25,0)+IF(MA(df['close'],20)>MA(df['close'],30),25,0)"
        },
        # is_open_buy_condi=True 开启买入条件筛选
        # is_open_buy_condi=False 关闭买入条件筛选，全市场排序
        is_open_buy_condi=True,
        buy_condi_factor={
            "25日回归动量": {
                "选择类型": "and",
                "选择方向": "大于",
                "值": 0
            },
            "25日回归动量": {
                "选择类型": "and",
                "选择方向": "小于",
                "值": 5
            },
            
        },
        rank_factor={
            "25日回归动量": {"相关性": "正相关", "权重": 1},
        },
        total_factor_rank='升序',
        # 止盈类型: 'none'=不使用止盈, '金额'=按金额卖出, '数量'=按数量卖出, '百分比'=按百分比卖出
        sell_type='金额',
        # 触发止盈涨跌幅，0.03是3%意思
        sell_zdf=0.03,
        # 卖出的值
        # sell_type='金额'，sell_value=1000 表示卖出1000元
        # sell_type='数量'，sell_value=1000 表示卖出1000股
        # sell_type='百分比'，sell_value=0.1 表示卖出仓位的10%
        sell_value=1000,
        interval=1,
        min_hold_days=1,
        max_workers=8,
        risk_free_rate=0.02,
        slippage=0,
        enable_limit_up_down_filter=True,
        max_single_position_ratio=1,
    )

    # 运行回测
    results = backtrader.run_backtest()

    # 打印报告
    print(backtrader.generate_report())

    # 保存完整数据到Excel+JSON
    backtrader.save_backtrader_data(user="test")