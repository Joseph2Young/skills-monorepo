import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta
import json
import math
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
import io
warnings.filterwarnings('ignore')
'''
数据必须包含的字段
字段名	说明	是否必须
date	日期	✅ 必须
close	收盘价	✅ 必须
open	开盘价	✅ 必须
high	最高价	✅ 必须
low	最低价	✅ 必须
volume	成交量	✅ 必须
####################################
推荐包含的字段（用于复权计算和涨跌停过滤）
字段名	说明	是否必须
preClose	前收盘价	⚠️ 推荐（用于复权和涨跌停过滤）
zdf	涨跌幅	⚠️ 推荐（如不存在会自动计算）
amount	成交金额	⚠️ 可选
证券代码	股票代码	⚠️ 可选（会自动添加）
证券名称	股票名称	⚠️ 可选
'''
class xg_zcph_backtrader:
    '''
    资产配置平衡策略，按固定的市值比率，计算个股的偏离买卖
    支持自定义百分比、金额2种配置方式
    包含完整的绩效分析、基准对比、数据导出功能
    做T规则：涨幅超过sell_zdf时卖出，跌幅超过buy_zdf时买入
    
    手续费处理规则：
    1. 买入：先扣除手续费，再用剩余金额买入（按100股整数倍）
       例如：下单100万，手续费1万，实际买入金额99万
    2. 卖出：手续费从卖出金额中直接扣除
       例如：卖出100万，手续费1万，实际收到99万
    3. 卖出时检查持仓数量，卖出数量不能超过持仓数量
    '''
    def __init__(
        self,
        start_date: str = '20260101',
        end_date: str = '20500101',
        stock_list: list = ['159915.SZ', '513100.SH', '518880.SH'],
        dt_type: str = '百分比',
        weight_list: list = [0.35, 0.35, 0.3],
        deviation_list: list = [0.1, 0.1, 0.05],
        interval: int = 20,
        index_stock: str = '000300.SH',
        cash: float = 100000,
        sell_zdf: float = 0.03,
        buy_zdf: float = -0.03,
        trade_value: float = 1000,
        comm: float = 0.0001,
        max_workers: int = 4,
        # ===== 新增：数据源模式开关 =====
        use_custom_data: bool = False,  # 是否使用自定义数据
    ):
        '''
        资产配置平衡策略，按固定的市值比率，计算个股的偏离买卖
        
        参数说明:
            start_date: 回测开始日期
            end_date: 回测结束日期
            stock_list: 标的列表
            dt_type: 配置类型 - '百分比'/'金额'
                - '百分比': weight_list为权重比例，如[0.35,0.35,0.3]表示35%,35%,30%
                - '金额': weight_list为固定金额，如[30000,30000,30000]表示每个标的30000元
            weight_list: 权重/金额列表，与stock_list一一对应
            deviation_list: 偏离度列表，与stock_list一一对应
                当标的市值偏离目标值超过 deviation_list[i] 时触发再平衡
            interval: 再平衡检查间隔（交易日）
            index_stock: 基准指数
            cash: 初始资金
            sell_zdf: 止盈阈值（涨幅超过此值卖出，如0.03表示3%）
            buy_zdf: 止损阈值（跌幅超过此值买入，如-0.03表示-3%）
            trade_value: 做T每次交易金额
            comm: 手续费率（默认万1）
            max_workers: 多线程加载数据时的线程数
            use_custom_data: 是否使用自定义数据源
        '''
        # 基础参数
        self.start_date = start_date
        self.end_date = end_date
        self.stock_list = stock_list if stock_list is not None else ['159915.SZ', '513100.SH', '518880.SH']
        self.index_stock = index_stock
        self.cash = cash
        
        # 复权方式
        self.adj_type = 'none'
        
        # 配置类型：百分比/金额
        self.dt_type = dt_type
        
        # 权重/金额列表
        self.weight_list = weight_list if weight_list is not None else [1.0/len(self.stock_list)] * len(self.stock_list)
        
        # 偏离度列表
        self.deviation_list = deviation_list if deviation_list is not None else [0.05] * len(self.stock_list)
        
        # 验证列表长度一致
        if len(self.weight_list) != len(self.stock_list):
            raise ValueError(f"weight_list长度({len(self.weight_list)})与stock_list长度({len(self.stock_list)})不一致")
        if len(self.deviation_list) != len(self.stock_list):
            raise ValueError(f"deviation_list长度({len(self.deviation_list)})与stock_list长度({len(self.stock_list)})不一致")
        
        # 如果是百分比模式，归一化权重
        if self.dt_type == '百分比':
            total_weight = sum(self.weight_list)
            if total_weight > 0 and total_weight != 1.0:
                self.weight_list = [w / total_weight for w in self.weight_list]
                print(f"权重已归一化: {dict(zip(self.stock_list, self.weight_list))}")
        elif self.dt_type == '金额':
            total_target = sum(self.weight_list)
            self._display_weights = [w / total_target for w in self.weight_list] if total_target > 0 else self.weight_list
            print(f"金额配置: {dict(zip(self.stock_list, self.weight_list))}")
        
        # 再平衡间隔
        self.interval = interval
        
        # 做T规则
        self.sell_zdf = sell_zdf
        self.buy_zdf = buy_zdf
        self.trade_value = trade_value

        # ETF交易规则
        self.min_shares = 100
        self.share_multiple = 100
        self.comm = comm
        
        # 多线程参数
        self.max_workers = max_workers
        
        self.path = os.path.dirname(os.path.abspath(__file__))
        
        # ===== 新增：自定义数据存储 =====
        self.use_custom_data = use_custom_data
        self._custom_data_cache = {}  # 存储自定义数据 {stock_code: DataFrame}
        
        # 回测结果存储
        self.daily_positions = None
        self.trade_log = None
        self.portfolio_history = None
        self.performance_metrics = None
        self.equity_curve_data = None
        self.annual_performance = None
        
        # 核心数据
        self.trade_data = None
        self.position_data = None
        self.account_data = None
        
        # 多标的独立数据存储
        self.stock_data_dict = {}
        self.stock_results = {}
        
    def _convert_to_serializable(self, obj):
        '''递归转换不可序列化的对象为JSON可序列化格式'''
        if isinstance(obj, dict):
            return {k: self._convert_to_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_to_serializable(item) for item in obj]
        elif isinstance(obj, pd.Timestamp):
            return obj.strftime('%Y-%m-%d')
        elif isinstance(obj, datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, (np.integer, np.int64)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.float64)):
            return float(obj) if not np.isnan(obj) else None
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, pd.DataFrame):
            return obj.to_dict('records')
        elif isinstance(obj, pd.Series):
            return obj.tolist()
        elif isinstance(obj, (np.bool_, bool)):
            return bool(obj)
        elif pd.isna(obj):
            return None
        else:
            return obj

    # ============================================================
    # 新增：数据添加接口（可直接调用）
    # ============================================================

    def add_stock_data_from_dataframe(self, stock_code: str, df: pd.DataFrame) -> bool:
        """
        从DataFrame添加股票数据
        
        Args:
            stock_code: 股票代码
            df: pandas DataFrame，必须包含'date'列
        
        Returns:
            bool: 是否添加成功
        """
        try:
            normalized_df = self._normalize_dataframe(df, stock_code)
            if normalized_df is not None and not normalized_df.empty:
                self._custom_data_cache[stock_code] = normalized_df
                self.use_custom_data = True
                print(f"  ✅ 添加DataFrame数据: {stock_code} ({len(normalized_df)} 行)")
                return True
            return False
        except Exception as e:
            print(f"  ❌ 添加DataFrame数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_excel(self, stock_code: str, file_path: str, sheet_name: int = 0, **kwargs) -> bool:
        """
        从Excel文件添加股票数据
        
        Args:
            stock_code: 股票代码
            file_path: Excel文件路径
            sheet_name: 工作表名称或索引
            **kwargs: 传递给pd.read_excel的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not os.path.exists(file_path):
                print(f"  ❌ Excel文件不存在: {file_path}")
                return False
            
            df = pd.read_excel(file_path, sheet_name=sheet_name, **kwargs)
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            print(f"  ❌ 添加Excel数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_csv(self, stock_code: str, file_path: str, **kwargs) -> bool:
        """
        从CSV文件添加股票数据
        
        Args:
            stock_code: 股票代码
            file_path: CSV文件路径
            **kwargs: 传递给pd.read_csv的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not os.path.exists(file_path):
                print(f"  ❌ CSV文件不存在: {file_path}")
                return False
            
            # 尝试不同编码
            encodings = ['utf-8', 'gbk', 'gb2312', 'utf-8-sig', 'latin-1']
            df = None
            for encoding in encodings:
                try:
                    df = pd.read_csv(file_path, encoding=encoding, **kwargs)
                    break
                except UnicodeDecodeError:
                    continue
            
            if df is None:
                print(f"  ❌ 无法读取CSV文件: {file_path}")
                return False
            
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            print(f"  ❌ 添加CSV数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_json(self, stock_code: str, file_path: str, orient: str = 'records', **kwargs) -> bool:
        """
        从JSON文件添加股票数据
        
        Args:
            stock_code: 股票代码
            file_path: JSON文件路径
            orient: JSON格式方向
            **kwargs: 传递给pd.read_json的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not os.path.exists(file_path):
                print(f"  ❌ JSON文件不存在: {file_path}")
                return False
            
            df = pd.read_json(file_path, orient=orient, **kwargs)
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            print(f"  ❌ 添加JSON数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_dict(self, stock_code: str, data: dict) -> bool:
        """
        从字典添加股票数据
        
        Args:
            stock_code: 股票代码
            data: 字典数据，格式为 {'date': [...], 'close': [...], ...}
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not data:
                return False
            df = pd.DataFrame(data)
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            print(f"  ❌ 添加Dict数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_parquet(self, stock_code: str, file_path: str, columns: list = None, **kwargs) -> bool:
        """
        从Parquet文件添加股票数据
        
        Args:
            stock_code: 股票代码
            file_path: Parquet文件路径
            columns: 需要读取的列列表
            **kwargs: 传递给pd.read_parquet的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not os.path.exists(file_path):
                print(f"  ❌ Parquet文件不存在: {file_path}")
                return False
            
            df = pd.read_parquet(file_path, **kwargs)
            if columns:
                existing_cols = [col for col in columns if col in df.columns]
                if existing_cols:
                    df = df[existing_cols]
            
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            print(f"  ❌ 添加Parquet数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_bytes(self, stock_code: str, file_bytes: bytes, file_type: str = 'csv', **kwargs) -> bool:
        """
        从字节数据添加股票数据（适用于上传文件等场景）
        
        Args:
            stock_code: 股票代码
            file_bytes: 文件字节数据
            file_type: 文件类型 ('csv', 'excel', 'json')
            **kwargs: 传递给相应读取函数的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if file_type.lower() == 'csv':
                encodings = ['utf-8', 'gbk', 'gb2312', 'utf-8-sig', 'latin-1']
                df = None
                for encoding in encodings:
                    try:
                        df = pd.read_csv(io.BytesIO(file_bytes), encoding=encoding, **kwargs)
                        break
                    except UnicodeDecodeError:
                        continue
                if df is None:
                    print(f"  ❌ 无法解码CSV字节数据")
                    return False
            
            elif file_type.lower() in ['excel', 'xlsx', 'xls']:
                df = pd.read_excel(io.BytesIO(file_bytes), **kwargs)
            
            elif file_type.lower() == 'json':
                df = pd.read_json(io.BytesIO(file_bytes), **kwargs)
            
            else:
                print(f"  ❌ 不支持的文件类型: {file_type}")
                return False
            
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            print(f"  ❌ 添加字节数据失败 {stock_code}: {e}")
            return False

    def clear_custom_data(self):
        """清空所有自定义数据"""
        self._custom_data_cache.clear()
        self.use_custom_data = False
        print("  ✅ 已清空所有自定义数据")

    def remove_stock_data(self, stock_code: str) -> bool:
        """
        移除指定股票的自定义数据
        
        Args:
            stock_code: 股票代码
        
        Returns:
            bool: 是否移除成功
        """
        if stock_code in self._custom_data_cache:
            del self._custom_data_cache[stock_code]
            if not self._custom_data_cache:
                self.use_custom_data = False
            print(f"  ✅ 已移除股票数据: {stock_code}")
            return True
        return False

    def get_custom_data_keys(self) -> list:
        """获取所有已加载的自定义数据股票代码列表"""
        return list(self._custom_data_cache.keys())

    def has_custom_data(self, stock_code: str) -> bool:
        """检查是否有指定股票的自定义数据"""
        return stock_code in self._custom_data_cache

    # ============================================================
    # 内部数据标准化方法
    # ============================================================

    def _normalize_dataframe(self, df: pd.DataFrame, stock_code: str = None) -> pd.DataFrame:
        """
        标准化DataFrame数据
        
        Args:
            df: pandas DataFrame
            stock_code: 股票代码
        
        Returns:
            DataFrame: 标准化后的数据
        """
        if df is None or df.empty:
            return pd.DataFrame()
        
        df = df.copy()
        
        # 标准化日期列
        if 'date' not in df.columns:
            # 尝试查找日期列
            date_cols = [col for col in df.columns if 'date' in col.lower() or '日期' in col]
            if date_cols:
                df = df.rename(columns={date_cols[0]: 'date'})
            else:
                # 尝试使用索引作为日期
                if isinstance(df.index, pd.DatetimeIndex):
                    df = df.reset_index()
                    df = df.rename(columns={df.columns[0]: 'date'})
                else:
                    raise ValueError("DataFrame必须包含'date'列或日期索引")
        
        # 确保日期列是datetime类型
        df['date'] = pd.to_datetime(df['date'])
        df = df.sort_values('date').reset_index(drop=True)
        
        # 确保必要的列存在
        required_cols = ['close', 'high', 'low', 'open', 'volume']
        for col in required_cols:
            if col not in df.columns:
                # 尝试查找对应的列名
                for existing_col in df.columns:
                    if col in existing_col.lower():
                        df = df.rename(columns={existing_col: col})
                        break
                else:
                    # 如果列不存在，创建空列
                    df[col] = np.nan
        
        # 添加证券代码
        if stock_code:
            df['证券代码'] = stock_code
        elif '证券代码' not in df.columns and 'code' not in df.columns:
            df['证券代码'] = 'CUSTOM'
        
        # 计算涨跌幅（如果不存在）
        if 'zdf' not in df.columns and 'close' in df.columns:
            df['zdf'] = df['close'].pct_change().fillna(0)
        
        # 计算复权因子（如果不存在）
        if 'preClose' in df.columns and 'adj_factor' not in df.columns:
            df['return'] = df['close'] / df['preClose']
            df['return'] = df['return'].fillna(1.0)
            df['return'] = df['return'].replace([np.inf, -np.inf], 1.0)
            df['adj_factor'] = df['return'].cumprod()
            if len(df) > 0:
                df.loc[df.index[0], 'adj_factor'] = 1.0
        
        return df

    # ============================================================
    # 修改后的数据加载方法（支持自定义数据源）
    # ============================================================

    def get_stock_data(self, stock_code):
        '''读取单个股票历史数据，支持自定义数据源'''
        try:
            # ===== 第一步：尝试从自定义数据源读取 =====
            if self.use_custom_data and stock_code in self._custom_data_cache:
                df = self._custom_data_cache[stock_code].copy()
                
                if 'date' not in df.columns:
                    return pd.DataFrame()
                
                df['date'] = pd.to_datetime(df['date'])
                start_dt = pd.to_datetime(self.start_date, format='%Y%m%d')
                end_dt = pd.to_datetime(self.end_date, format='%Y%m%d')
                df = df[(df['date'] >= start_dt) & (df['date'] <= end_dt)]
                df = df.sort_values('date').reset_index(drop=True)
                df = df[df['close'] > 0]
                df = df[df['open'] > 0]
                df = self.adjust_price(df)
                df['zdf'] = df['close'].pct_change().fillna(0)
                return df

            # ===== 第二步：从本地文件读取 =====
            df = pd.read_parquet(r'{}/data/历史数据/{}.parquet'.format(self.path, stock_code),
                engine='pyarrow',use_threads=True)
            df['date'] = pd.to_datetime(df['date'].astype(str), format='%Y%m%d')
            df = df[(df['date'] >= pd.to_datetime(self.start_date)) & 
                    (df['date'] <= pd.to_datetime(self.end_date))]
            df = df.sort_values('date').reset_index(drop=True)
            df = df[df['close'] > 0]
            df = df[df['open'] > 0]
            df = self.adjust_price(df)
            df['zdf'] = df['close'].pct_change().fillna(0)
            return df
        except Exception as e:
            print(f"加载股票数据出错 {stock_code}: {e}")
            return pd.DataFrame()
    
    def _load_single_stock(self, stock):
        '''单个股票加载函数（用于多线程）'''
        try:
            df = self.get_stock_data(stock)
            if not df.empty:
                return (stock, df, True, f"数据加载成功: {len(df)} 行")
            else:
                return (stock, None, False, "数据加载失败")
        except Exception as e:
            return (stock, None, False, f"加载异常: {e}")
    
    def get_all_stock_data(self):
        '''多线程读取所有股票历史数据'''
        all_data = {}
        print(f"\n开始多线程加载股票数据 (线程数: {self.max_workers})...")
        if self.use_custom_data:
            print(f"使用自定义数据源: {list(self._custom_data_cache.keys())}")
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_stock = {
                executor.submit(self._load_single_stock, stock): stock 
                for stock in self.stock_list
            }
            
            for future in as_completed(future_to_stock):
                stock = future_to_stock[future]
                try:
                    stock_code, df, success, message = future.result()
                    if success and df is not None and not df.empty:
                        all_data[stock_code] = df
                        print(f"  ✅ {stock_code}: {message}")
                        print(f"     数据范围: {df['date'].min()} 至 {df['date'].max()}")
                        print(f"     价格范围: {df['close'].min():.4f} 至 {df['close'].max():.4f}")
                    else:
                        print(f"  ❌ {stock_code}: {message}")
                except Exception as e:
                    print(f"  ❌ {stock}: 线程执行异常: {e}")
        
        print(f"\n多线程加载完成，成功加载 {len(all_data)}/{len(self.stock_list)} 只标的")
        return all_data

    # ============================================================
    # 以下所有原有函数保持不变
    # ============================================================

    def adjust_price(self, df):
        '''根据复权方式调整价格'''
        if self.adj_type == 'none':
            return df
        if 'preClose' in df.columns:
            try:
                df['adj_factor'] = 1.0
                for i in range(1, len(df)):
                    if df.loc[i, 'preClose'] > 0:
                        actual_return = df.loc[i, 'close'] / df.loc[i, 'preClose']
                        df.loc[i, 'adj_factor'] = df.loc[i-1, 'adj_factor'] * actual_return
                    else:
                        df.loc[i, 'adj_factor'] = df.loc[i-1, 'adj_factor']
                if self.adj_type in ['front', 'front_ratio']:
                    last_factor = df['adj_factor'].iloc[-1]
                    df['adj_factor'] = df['adj_factor'] / last_factor
                price_cols = ['open', 'high', 'low', 'close']
                for col in price_cols:
                    if col in df.columns:
                        df[col] = df[col] * df['adj_factor']
                df = df.drop(columns=['adj_factor'])
            except Exception as e:
                print(f"  复权计算出错: {e}")
        return df
    
    def get_index_data(self):
        '''读取指数历史数据'''
        try:
            file_path = r'{}/data/指数数据/{}.parquet'.format(self.path, self.index_stock)
            if not os.path.exists(file_path):
                print(f"指数文件不存在: {file_path}")
                return pd.DataFrame()
            df = pd.read_parquet(file_path,engine='pyarrow',use_threads=True)
            df['date'] = pd.to_datetime(df['date'].astype(str), format='%Y%m%d')
            df = df[(df['date'] >= pd.to_datetime(self.start_date)) & 
                    (df['date'] <= pd.to_datetime(self.end_date))]
            df = df.sort_values('date').reset_index(drop=True)
            df = df[df['close'] > 0]
            df = df[df['open'] > 0]
            print(f"指数数据加载成功: {len(df)} 行")
            return df
        except Exception as e:
            print(f"加载指数数据出错: {e}")
            return pd.DataFrame()
    
    def calculate_annual_performance(self, portfolio_df):
        '''计算年度收益统计指标'''
        if portfolio_df is None or len(portfolio_df) == 0:
            return {}
        
        portfolio_df['year'] = portfolio_df['date'].dt.year
        annual_stats = {}
        
        for year, group in portfolio_df.groupby('year'):
            year_data = group.sort_values('date').reset_index(drop=True)
            
            if len(year_data) < 2:
                continue
            
            start_value = year_data['total_value'].iloc[0]
            end_value = year_data['total_value'].iloc[-1]
            total_return = (end_value - start_value) / start_value if start_value > 0 else 0
            
            cumulative = year_data['total_value']
            running_max = cumulative.expanding().max()
            drawdown = (cumulative - running_max) / running_max
            max_drawdown = drawdown.min() if not drawdown.empty else 0
            max_drawdown_date = year_data['date'][drawdown.idxmin()].strftime('%Y-%m-%d') if not drawdown.empty and not drawdown.isna().all() else None
            
            daily_returns = year_data['daily_return'].dropna()
            daily_returns = daily_returns[(daily_returns > -1) & (daily_returns < 1)]
            daily_returns = daily_returns[daily_returns != 0]
            
            risk_free_rate = 0.02
            if len(daily_returns) > 2 and daily_returns.std() > 1e-10:
                excess_returns = daily_returns - risk_free_rate / 252
                sharpe_ratio = np.sqrt(252) * excess_returns.mean() / daily_returns.std()
            else:
                sharpe_ratio = 0
            
            downside_returns = daily_returns[daily_returns < 0]
            if len(downside_returns) > 2 and downside_returns.std() > 1e-10:
                sortino_ratio = np.sqrt(252) * daily_returns.mean() / downside_returns.std()
            else:
                sortino_ratio = 0
            
            win_rate = (daily_returns > 0).sum() / len(daily_returns) if len(daily_returns) > 0 else 0
            volatility = daily_returns.std() * np.sqrt(252) if len(daily_returns) > 0 and daily_returns.std() > 0 else 0
            calmar_ratio = total_return / abs(max_drawdown) if max_drawdown != 0 and abs(max_drawdown) > 1e-10 else 0
            total_pnl = end_value - start_value
            
            if self.trade_log is not None and len(self.trade_log) > 0:
                year_trades = self.trade_log[self.trade_log['date'].dt.year == year]
                t_trades = len(year_trades)
                year_commission = year_trades['commission'].sum() if 'commission' in year_trades.columns else 0
            else:
                t_trades = 0
                year_commission = 0
            
            remaining_cash = year_data['cash'].iloc[-1] if 'cash' in year_data.columns else 0
            final_holdings = year_data['holdings'].iloc[-1] if 'holdings' in year_data.columns else 0
            
            if 'benchmark_net_value' in year_data.columns:
                benchmark_start = year_data['benchmark_net_value'].iloc[0]
                benchmark_end = year_data['benchmark_net_value'].iloc[-1]
                benchmark_total_return = (benchmark_end - benchmark_start) / benchmark_start if benchmark_start > 0 else 0
                benchmark_final_value = benchmark_end
                benchmark_start_value = benchmark_start
                bm_net = year_data['benchmark_net_value']
                bm_running_max = bm_net.expanding().max()
                bm_drawdown = (bm_net - bm_running_max) / bm_running_max
                benchmark_max_drawdown = bm_drawdown.min() if not bm_drawdown.empty else 0
            else:
                benchmark_total_return = 0
                benchmark_final_value = 1.0
                benchmark_start_value = 1.0
                benchmark_max_drawdown = 0
            
            excess_return = total_return - benchmark_total_return
            excess_return_pct = excess_return * 100
            
            annual_stats[str(year)] = {
                'start_date': year_data['date'].iloc[0].strftime('%Y-%m-%d'),
                'end_date': year_data['date'].iloc[-1].strftime('%Y-%m-%d'),
                'total_days': len(year_data),
                'total_cash': self.cash,
                'final_value': round(end_value, 2),
                'total_return': round(total_return, 4),
                'total_pnl': round(total_pnl, 2),
                'total_invested': 0,
                't_trades': t_trades,
                'total_commission': round(year_commission, 2),
                'remaining_cash': round(remaining_cash, 2),
                'final_holdings': round(final_holdings, 2),
                'annual_return': round(total_return, 4),
                'max_drawdown': round(max_drawdown, 4),
                'max_drawdown_date': max_drawdown_date,
                'sharpe_ratio': round(sharpe_ratio, 4),
                'sortino_ratio': round(sortino_ratio, 4),
                'calmar_ratio': round(calmar_ratio, 4),
                'win_rate': round(win_rate, 4),
                'volatility': round(volatility, 4),
                'benchmark_final_value': round(benchmark_final_value, 4),
                'benchmark_total_return': round(benchmark_total_return, 4),
                'benchmark_start_value': round(benchmark_start_value, 4),
                'benchmark_max_drawdown': round(benchmark_max_drawdown, 4),
                'excess_return': round(excess_return, 4),
                'excess_return_pct': round(excess_return_pct, 2)
            }
        
        return annual_stats
    
    def get_annual_performance(self):
        if self.annual_performance is None:
            self.run_backtest()
        return self.annual_performance
    
    def get_annual_performance_df(self):
        annual_data = self.get_annual_performance()
        if not annual_data:
            return pd.DataFrame()
        
        df = pd.DataFrame.from_dict(annual_data, orient='index')
        df.index.name = 'year'
        df = df.reset_index()
        
        # 确保没有重复列名
        df = df.loc[:, ~df.columns.duplicated()]
        
        column_mapping = {
            'start_date': 'start_date',
            'end_date': 'end_date',
            'total_days': 'total_days',
            'total_cash': 'total_cash',
            'final_value': 'final_value',
            'total_return': 'total_return',
            'total_pnl': 'total_pnl',
            'total_invested': 'total_invested',
            't_trades': 't_trades',
            'total_commission': 'total_commission',
            'remaining_cash': 'remaining_cash',
            'final_holdings': 'final_holdings',
            'annual_return': 'annual_return',
            'max_drawdown': 'max_drawdown',
            'max_drawdown_date': 'max_drawdown_date',
            'sharpe_ratio': 'sharpe_ratio',
            'sortino_ratio': 'sortino_ratio',
            'calmar_ratio': 'calmar_ratio',
            'win_rate': 'win_rate',
            'volatility': 'volatility',
            'benchmark_final_value': 'benchmark_final_value',
            'benchmark_total_return': 'benchmark_total_return',
            'benchmark_start_value': 'benchmark_start_value',
            'benchmark_max_drawdown': 'benchmark_max_drawdown',
            'excess_return': 'excess_return',
            'excess_return_pct': 'excess_return_pct'
        }
        
        existing_cols = [col for col in column_mapping.keys() if col in df.columns]
        df = df[['year'] + existing_cols]
        df.columns = ['year'] + [column_mapping[col] for col in existing_cols]
        
        return df
    
    def calculate_benchmark_curve(self, all_data):
        '''计算基准收益曲线：按配置权重持有组合标的不动'''
        if not all_data:
            return pd.DataFrame()
        
        common_dates = None
        for stock, df in all_data.items():
            dates = set(df['date'].tolist())
            if common_dates is None:
                common_dates = dates
            else:
                common_dates = common_dates.intersection(dates)
        
        if not common_dates:
            print("警告：没有共同交易日，无法计算基准收益曲线")
            return pd.DataFrame()
        
        common_dates = sorted(common_dates)
        
        normalized_prices = {}
        for stock, df in all_data.items():
            df_dict = df.set_index('date')['close'].to_dict()
            prices = []
            for date in common_dates:
                prices.append(df_dict.get(date, np.nan))
            first_price = prices[0] if prices and not np.isnan(prices[0]) else 1.0
            normalized = [p / first_price if not np.isnan(p) else np.nan for p in prices]
            normalized_prices[stock] = normalized
        
        if self.dt_type == '金额':
            total_target = sum(self.weight_list)
            benchmark_weights = [w / total_target for w in self.weight_list] if total_target > 0 else [1.0/len(all_data)] * len(all_data)
        else:
            benchmark_weights = self.weight_list
        
        benchmark_net = []
        for i in range(len(common_dates)):
            weighted_sum = 0
            total_weight = 0
            for idx, stock in enumerate(all_data.keys()):
                val = normalized_prices[stock][i]
                if not np.isnan(val):
                    weighted_sum += val * benchmark_weights[idx]
                    total_weight += benchmark_weights[idx]
            benchmark_net.append(weighted_sum / total_weight if total_weight > 0 else 1.0)
        
        benchmark_df = pd.DataFrame({
            'date': common_dates,
            'benchmark_net_value': benchmark_net
        })
        benchmark_df['benchmark_return'] = benchmark_df['benchmark_net_value'].pct_change().fillna(0)
        
        print(f"\n基准组合（按配置权重持有不动）计算结果:")
        if self.dt_type == '金额':
            print(f"  权重配置(金额比例): {dict(zip(all_data.keys(), benchmark_weights))}")
        else:
            print(f"  权重配置: {dict(zip(all_data.keys(), self.weight_list))}")
        print(f"  起始净值: {benchmark_df['benchmark_net_value'].iloc[0]:.4f}")
        print(f"  最终净值: {benchmark_df['benchmark_net_value'].iloc[-1]:.4f}")
        print(f"  总收益率: {(benchmark_df['benchmark_net_value'].iloc[-1] - 1) * 100:.2f}%")
        
        return benchmark_df
    
    # ============================================================
    # 交易计算函数 - 手续费处理优化
    # ============================================================
    def calculate_buy_shares(self, amount, price):
        """
        计算买入股数
        
        买入规则：
        1. 先扣除手续费，再用剩余金额买入
        2. 按100股的整数倍买入
        3. 确保实际成本（含手续费）不超过可用金额
        
        例如：下单金额100万，手续费1万，实际买入金额99万
        
        Args:
            amount: 可用金额（含手续费）
            price: 当前价格
            
        Returns:
            tuple: (买入股数, 实际成本（含手续费）)
        """
        if price <= 0 or amount <= 0:
            return 0, 0
        
        # 先扣除手续费，计算可用于买入的金额
        # 公式：可用买入金额 = amount / (1 + comm)
        buy_amount = amount / (1 + self.comm)
        
        # 计算最大可买份额（按100股整数倍）
        max_shares = int(buy_amount // price)
        shares = (max_shares // self.share_multiple) * self.share_multiple
        
        if shares < self.min_shares:
            shares = 0
        
        # 计算实际成本（含手续费），确保不超过可用金额
        base_cost = shares * price
        commission = base_cost * self.comm
        actual_cost = base_cost + commission
        
        # 安全检查：如果实际成本超过可用金额，减少一手
        while shares > 0 and actual_cost > amount:
            shares -= self.share_multiple
            base_cost = shares * price
            commission = base_cost * self.comm
            actual_cost = base_cost + commission
        
        if shares < self.min_shares:
            shares = 0
            actual_cost = 0
        
        return shares, actual_cost
    
    def calculate_sell_shares_by_amount(self, shares, price, sell_amount):
        """
        按金额卖出（做T止盈/止损卖出）
        
        卖出规则：
        1. 手续费从卖出金额中直接扣除
        2. 按100股的整数倍卖出
        3. 如果卖出数量大于持仓数量，则全部卖出（取最小值）
        4. 实际收到金额 = 卖出金额 - 手续费
        
        例如：卖出100万，手续费1万，最终收到99万
        
        Args:
            shares: 当前持仓股数
            price: 当前价格
            sell_amount: 希望卖出的金额（用于计算股数）
            
        Returns:
            tuple: (卖出股数, 实际收到金额)
        """
        if price <= 0 or shares <= 0 or sell_amount <= 0:
            return 0, 0
        
        # 计算要卖出的份额（按100股整数倍）
        max_shares = int(sell_amount // price)
        sell_shares = (max_shares // self.share_multiple) * self.share_multiple
        
        # 如果计算出的份额为0但按金额应该至少卖100股，尝试取100股
        if sell_shares == 0 and max_shares >= self.min_shares:
            sell_shares = self.min_shares
        
        # 如果卖出数量大于持仓数量，取最小值（全部卖出）
        if sell_shares > shares:
            sell_shares = shares
        
        if sell_shares <= 0:
            return 0, 0
        
        # 计算实际收到的金额（扣除手续费）
        base_amount = sell_shares * price
        commission = base_amount * self.comm
        actual_amount = base_amount - commission
        
        # 如果实际收到金额为负，不卖出
        if actual_amount <= 0:
            return 0, 0
        
        return sell_shares, actual_amount
    
    def calculate_sell_shares_all(self, shares, price):
        """
        全部卖出（清仓时使用）
        
        卖出规则：
        1. 手续费从卖出金额中直接扣除
        2. 按100股的整数倍卖出
        3. 如果取整后为0但实际有持仓，全部卖出
        4. 实际收到金额 = 卖出金额 - 手续费
        
        Args:
            shares: 当前持仓股数
            price: 当前价格
            
        Returns:
            tuple: (卖出股数, 实际收到金额)
        """
        if price <= 0 or shares <= 0:
            return 0, 0
        
        # 全部卖出，按100股整数倍
        sell_shares = (shares // self.share_multiple) * self.share_multiple
        
        # 如果取整后为0但实际有持仓，按实际持仓卖出
        if sell_shares == 0 and shares > 0:
            sell_shares = shares
        
        # 确保卖出数量不超过持仓
        if sell_shares > shares:
            sell_shares = shares
        
        if sell_shares <= 0:
            return 0, 0
        
        # 计算实际收到的金额（扣除手续费）
        base_amount = sell_shares * price
        commission = base_amount * self.comm
        actual_amount = base_amount - commission
        
        if actual_amount <= 0:
            return 0, 0
        
        return sell_shares, actual_amount
    
    def vectorized_backtest(self):
        '''向量化回测主函数 - 资产配置平衡策略'''
        print("="*60)
        print("开始ETF资产配置平衡回测...")
        print(f"标的列表: {self.stock_list}")
        if self.use_custom_data:
            print(f"使用自定义数据源: {list(self._custom_data_cache.keys())}")
        print(f"配置类型: {self.dt_type}")
        if self.dt_type == '金额':
            print(f"金额配置: {dict(zip(self.stock_list, self.weight_list))}")
        else:
            print(f"权重配置: {dict(zip(self.stock_list, self.weight_list))}")
        print(f"偏离度列表: {dict(zip(self.stock_list, self.deviation_list))}")
        print(f"再平衡间隔: 每 {self.interval} 个交易日检查一次")
        print(f"回测区间: {self.start_date} 至 {self.end_date}")
        print(f"初始总资金: ¥{self.cash:,.2f}")
        print(f"手续费率: {self.comm*100:.2f}%")
        print(f"做T止盈: 涨>{self.sell_zdf*100:.0f}%卖出")
        print(f"做T止损: 跌<{self.buy_zdf*100:.0f}%买入")
        print(f"做T金额: ¥{self.trade_value:,.2f}")
        print(f"多线程加载线程数: {self.max_workers}")
        print("="*60)
        
        all_data = self.get_all_stock_data()
        if not all_data:
            print("没有有效的股票数据，回测终止")
            return None
        
        self.stock_data_dict = all_data
        df_index = self.get_index_data()
        
        benchmark_df = self.calculate_benchmark_curve(all_data)
        benchmark_dict = dict(zip(benchmark_df['date'], benchmark_df['benchmark_net_value'])) if not benchmark_df.empty else {}
        
        all_dates = None
        for stock, df in all_data.items():
            dates = set(df['date'].tolist())
            if all_dates is None:
                all_dates = dates
            else:
                all_dates = all_dates.intersection(dates)
        
        if not all_dates:
            print("没有共同交易日，回测终止")
            return None
        
        all_dates = sorted(all_dates)
        print(f"\n共同交易日: {len(all_dates)} 天")
        
        price_map = {}
        zdf_map = {}
        for code, df in all_data.items():
            price_map[code] = dict(zip(df['date'], df['close']))
            zdf_map[code] = dict(zip(df['date'], df['zdf']))
        
        # ========== 资产配置平衡策略核心 ==========
        account_cash = self.cash
        holdings = {stock: 0 for stock in self.stock_list}
        target_values = {stock: 0 for stock in self.stock_list}
        
        all_trades = []
        merged_records = []
        
        holdings_history = {stock: [0] * len(all_dates) for stock in self.stock_list}
        cash_history = {stock: [0] * len(all_dates) for stock in self.stock_list}
        value_history = {stock: [0] * len(all_dates) for stock in self.stock_list}
        
        # ===== 初始建仓 =====
        print("\n初始建仓...")
        
        if self.dt_type == '金额':
            total_target_amount = sum(self.weight_list)
            print(f"总目标金额: ¥{total_target_amount:,.2f}")
            if total_target_amount > self.cash:
                scale = self.cash / total_target_amount
                self.weight_list = [w * scale for w in self.weight_list]
                print(f"总目标金额超过初始资金，按比例调整后: {dict(zip(self.stock_list, self.weight_list))}")
        
        for idx, stock in enumerate(self.stock_list):
            price = price_map[stock].get(all_dates[0], 0)
            if price <= 0:
                print(f"  警告: {stock} 首日无有效价格，跳过建仓")
                continue
            
            if self.dt_type == '百分比':
                target_amount = account_cash * self.weight_list[idx]
            else:
                target_amount = self.weight_list[idx]
            
            target_amount = min(target_amount, account_cash)
            
            if target_amount > 0:
                # 使用修复后的买入函数（先扣手续费）
                buy_shares, actual_cost = self.calculate_buy_shares(target_amount, price)
                if buy_shares > 0 and actual_cost <= account_cash:
                    account_cash -= actual_cost
                    holdings[stock] = buy_shares
                    target_values[stock] = target_amount
                    commission = buy_shares * price * self.comm
                    
                    # 构建reason字符串（避免f-string嵌套问题）
                    if self.dt_type == '金额':
                        target_str = str(self.weight_list[idx])
                        reason = f'初始建仓，目标金额={target_str}'
                    else:
                        target_str = f"{self.weight_list[idx]*100:.1f}%"
                        reason = f'初始建仓，目标百分比={target_str}'
                    
                    all_trades.append({
                        'date': all_dates[0],
                        'stock': stock,
                        'type': '初始建仓',
                        'price': round(price, 4),
                        'shares': buy_shares,
                        'amount': round(actual_cost, 2),
                        'commission': round(commission, 4),
                        'reason': reason
                    })
                    print(f"  建仓 {stock}: 买入{buy_shares}份 @ {price:.4f}, 目标¥{target_amount:,.2f}, 成本¥{actual_cost:,.2f}")
                else:
                    print(f"  建仓 {stock}: 资金不足或无法买入")
            else:
                print(f"  建仓 {stock}: 配置值为0，跳过")
        
        print(f"建仓完成，剩余现金: ¥{account_cash:,.2f}")
        
        for stock in self.stock_list:
            holdings_history[stock][0] = holdings[stock]
            cash_history[stock][0] = account_cash if stock == self.stock_list[0] else 0
            value_history[stock][0] = holdings[stock] * price_map[stock].get(all_dates[0], 0) if stock == self.stock_list[0] else 0
        
        rebalance_counter = 0
        
        # 主循环
        for idx, trade_date in enumerate(all_dates):
            daily_trades = []
            today_price = {s: price_map[s].get(trade_date, np.nan) for s in self.stock_list}
            today_zdf = {s: zdf_map[s].get(trade_date, 0) for s in self.stock_list}
            
            market_value = sum([holdings[s] * today_price[s] for s in self.stock_list if not np.isnan(today_price[s])])
            total_asset = account_cash + market_value
            
            # ========== 再平衡逻辑 ==========
            rebalance_counter += 1
            should_rebalance = (rebalance_counter >= self.interval)
            
            if should_rebalance:
                rebalance_counter = 0
                
                if self.dt_type == '百分比':
                    for i, stock in enumerate(self.stock_list):
                        target_values[stock] = total_asset * self.weight_list[i]
                else:
                    for i, stock in enumerate(self.stock_list):
                        if target_values[stock] > total_asset * 0.95:
                            target_values[stock] = total_asset * self.weight_list[i] if total_asset > 0 else 0
                
                for i, stock in enumerate(self.stock_list):
                    current_value = holdings[stock] * today_price[stock] if not np.isnan(today_price[stock]) else 0
                    target_value = target_values[stock]
                    deviation = self.deviation_list[i]
                    
                    diff = current_value - target_value
                    deviation_threshold = target_value * deviation
                    
                    if abs(diff) > deviation_threshold and target_value > 0:
                        price = today_price[stock]
                        if np.isnan(price) or price <= 0:
                            continue
                        
                        adjust_amount = abs(diff)
                        adjust_shares = int(adjust_amount / price / self.share_multiple) * self.share_multiple
                        
                        if adjust_shares < self.min_shares:
                            continue
                        
                        if diff > 0:
                            # 卖出：使用修复后的卖出函数
                            sell_shares = min(adjust_shares, holdings[stock])
                            if sell_shares > 0:
                                sell_shares = (sell_shares // self.share_multiple) * self.share_multiple
                                if sell_shares >= self.min_shares:
                                    # 使用修复后的卖出函数（手续费从卖出金额中扣除）
                                    sell_shares, actual_amount = self.calculate_sell_shares_all(sell_shares, price)
                                    if sell_shares > 0 and actual_amount > 0:
                                        account_cash += actual_amount
                                        holdings[stock] -= sell_shares
                                        
                                        commission = sell_shares * price * self.comm
                                        daily_trades.append({
                                            'date': trade_date,
                                            'stock': stock,
                                            'type': '再平衡卖出',
                                            'price': round(price, 4),
                                            'shares': sell_shares,
                                            'amount': round(actual_amount, 2),
                                            'commission': round(commission, 4),
                                            'reason': f'超配{deviation*100:.0f}%，卖出调仓 (目标¥{target_value:,.0f}, 当前¥{current_value:,.0f})'
                                        })
                                        print(f"  [{trade_date}] 再平衡卖出 {stock}: {sell_shares}份, 超配{deviation*100:.0f}%, 金额¥{actual_amount:,.2f}")
                        else:
                            # 买入：使用修复后的买入函数
                            buy_shares = adjust_shares
                            if buy_shares >= self.min_shares:
                                buy_shares, actual_cost = self.calculate_buy_shares(buy_shares * price, price)
                                if buy_shares > 0 and actual_cost <= account_cash:
                                    account_cash -= actual_cost
                                    holdings[stock] += buy_shares
                                    
                                    commission = buy_shares * price * self.comm
                                    daily_trades.append({
                                        'date': trade_date,
                                        'stock': stock,
                                        'type': '再平衡买入',
                                        'price': round(price, 4),
                                        'shares': buy_shares,
                                        'amount': round(actual_cost, 2),
                                        'commission': round(commission, 4),
                                        'reason': f'低配{deviation*100:.0f}%，买入调仓 (目标¥{target_value:,.0f}, 当前¥{current_value:,.0f})'
                                    })
                                    print(f"  [{trade_date}] 再平衡买入 {stock}: {buy_shares}份, 低配{deviation*100:.0f}%, 金额¥{actual_cost:,.2f}")
            
            # ========== 做T逻辑 ==========
            for stock in self.stock_list:
                if holdings[stock] <= 0:
                    continue
                current_zdf = today_zdf.get(stock, 0)
                price = today_price[stock]
                if np.isnan(price) or price <= 0:
                    continue
                
                # 止盈卖出
                if current_zdf >= self.sell_zdf:
                    sell_shares, actual_amount = self.calculate_sell_shares_by_amount(
                        holdings[stock], price, self.trade_value
                    )
                    if sell_shares > 0:
                        account_cash += actual_amount
                        holdings[stock] -= sell_shares
                        commission = sell_shares * price * self.comm
                        daily_trades.append({
                            'date': trade_date,
                            'stock': stock,
                            'type': '止盈卖出',
                            'price': round(price, 4),
                            'shares': sell_shares,
                            'amount': round(actual_amount, 2),
                            'commission': round(commission, 4),
                            'reason': f'涨幅{current_zdf*100:.2f}%触发止盈'
                        })
                        if holdings[stock] <= 0:
                            holdings[stock] = 0
                
                # 止损买入
                elif current_zdf <= self.buy_zdf and account_cash >= self.trade_value:
                    buy_shares, actual_cost = self.calculate_buy_shares(self.trade_value, price)
                    if buy_shares > 0 and actual_cost <= account_cash:
                        account_cash -= actual_cost
                        holdings[stock] += buy_shares
                        commission = buy_shares * price * self.comm
                        daily_trades.append({
                            'date': trade_date,
                            'stock': stock,
                            'type': '止损买入',
                            'price': round(price, 4),
                            'shares': buy_shares,
                            'amount': round(actual_cost, 2),
                            'commission': round(commission, 4),
                            'reason': f'跌幅{current_zdf*100:.2f}%触发止损买入'
                        })
                        print(f"  [{trade_date}] 止损买入 {stock}: {buy_shares}份 @ {price:.4f}, 跌幅{current_zdf*100:.2f}%")
            
            all_trades.extend(daily_trades)
            
            for stock in self.stock_list:
                holdings_history[stock][idx] = holdings[stock]
                if stock == self.stock_list[0]:
                    cash_history[stock][idx] = account_cash
                else:
                    cash_history[stock][idx] = 0
                value_history[stock][idx] = holdings[stock] * today_price[stock] if not np.isnan(today_price[stock]) else 0
            
            stock_details = []
            total_holdings = 0
            for s in self.stock_list:
                price = today_price[s]
                zdf = today_zdf[s]
                stk_hold = holdings[s]
                stk_value = stk_hold * price if not np.isnan(price) else 0
                total_holdings += stk_hold
                current_weight = stk_value / total_asset if total_asset > 0 else 0
                
                if self.dt_type == '金额':
                    target_display = f"¥{target_values[s]:,.0f}"
                else:
                    target_display = f"{self.weight_list[self.stock_list.index(s)]*100:.1f}%"
                
                stock_details.append({
                    'stock': s,
                    'price': round(price, 4) if not np.isnan(price) else 0,
                    'zdf': round(zdf, 6) if not np.isnan(zdf) else 0,
                    'holdings': stk_hold,
                    'value': round(stk_value, 2),
                    'cash': 0.0,
                    'weight': round(current_weight, 4),
                    'target': target_display
                })
            
            market_value = sum([holdings[s] * today_price[s] for s in self.stock_list if not np.isnan(today_price[s])])
            total_asset_today = account_cash + market_value
            
            merged_records.append({
                'date': trade_date,
                'cash': round(account_cash, 2),
                'holdings': total_holdings,
                'total_value': round(total_asset_today, 2),
                'cumulative_pnl': round(total_asset_today - self.cash, 2),
                'total_return': (total_asset_today - self.cash) / self.cash if self.cash > 0 else 0,
                'stock_details': stock_details
            })
        
        for i in range(1, len(merged_records)):
            merged_records[i]['daily_pnl'] = merged_records[i]['total_value'] - merged_records[i-1]['total_value']
        for item in merged_records:
            item['daily_pnl'] = item.get('daily_pnl', 0)
        
        self.daily_positions = pd.DataFrame(merged_records)
        
        portfolio_df = pd.DataFrame([{
            'date': r['date'],
            'total_value': r['total_value'],
            'cumulative_pnl': r['cumulative_pnl'],
            'cash': r['cash'],
            'holdings': r['holdings'],
            'total_return': r['total_return']
        } for r in merged_records])
        portfolio_df['daily_return'] = portfolio_df['total_value'].pct_change().fillna(0)
        portfolio_df['daily_return'] = portfolio_df['daily_return'].replace([np.inf, -np.inf], 0)
        
        if benchmark_dict:
            portfolio_df['benchmark_net_value'] = portfolio_df['date'].map(benchmark_dict)
            portfolio_df['benchmark_net_value'] = portfolio_df['benchmark_net_value'].fillna(method='ffill').fillna(1.0)
            portfolio_df['benchmark_return'] = portfolio_df['benchmark_net_value'].pct_change().fillna(0)
        else:
            portfolio_df['benchmark_net_value'] = 1.0
            portfolio_df['benchmark_return'] = 0.0
        
        self.portfolio_history = portfolio_df
        self.trade_log = pd.DataFrame(all_trades) if all_trades else pd.DataFrame()
        
        self.stock_results = {}
        for stock in self.stock_list:
            stock_trades = [t for t in all_trades if t['stock'] == stock]
            self.stock_results[stock] = {
                'cash': cash_history[stock],
                'holdings': holdings_history[stock],
                'total_value': value_history[stock],
                'trades': stock_trades,
                'final_holdings': holdings_history[stock][-1] if holdings_history[stock] else 0,
                'final_cash': cash_history[stock][-1] if cash_history[stock] else 0,
                'final_value': value_history[stock][-1] if value_history[stock] else 0,
                'target_amount': self.weight_list[self.stock_list.index(stock)] if self.dt_type == '金额' else None,
                'target_weight': self.weight_list[self.stock_list.index(stock)] if self.dt_type == '百分比' else None
            }
        
        self.equity_curve_data = self.generate_equity_curve_data()
        self.trade_data = self.generate_trade_data()
        self.position_data = self.generate_position_data()
        self.account_data = self.generate_account_data()
        self.performance_metrics = self.calculate_performance_metrics(portfolio_df, df_index)
        self.annual_performance = self.calculate_annual_performance(portfolio_df)
        
        # ========== 回测结果打印 ==========
        total_commission = self.trade_log['commission'].sum() if 'commission' in self.trade_log.columns else 0
        final_row = merged_records[-1]
        print("\n" + "="*60)
        print("资产配置平衡策略回测结果:")
        print(f"总交易日: {len(merged_records)}")
        print(f"总交易次数: {len(all_trades)}")
        
        rebalance_buy = sum(1 for t in all_trades if t['type'] == '再平衡买入')
        rebalance_sell = sum(1 for t in all_trades if t['type'] == '再平衡卖出')
        stop_profit = sum(1 for t in all_trades if t['type'] == '止盈卖出')
        stop_loss = sum(1 for t in all_trades if t['type'] == '止损买入')
        print(f"  再平衡买入: {rebalance_buy} 次")
        print(f"  再平衡卖出: {rebalance_sell} 次")
        print(f"  止盈卖出: {stop_profit} 次")
        print(f"  止损买入: {stop_loss} 次")
        
        print(f"最终总持仓份额: {final_row['holdings']:.0f} 份")
        print(f"最终总现金: ¥{final_row['cash']:,.2f}")
        print(f"最终总资产: ¥{final_row['total_value']:,.2f}")
        print(f"总盈亏: ¥{final_row['cumulative_pnl']:,.2f}")
        print(f"总收益率: {final_row['total_return']*100:.2f}%")
        print(f"总手续费: ¥{total_commission:.2f}")
        
        print("\n最终持仓明细:")
        final_stk_detail = final_row['stock_details']
        has_pos = False
        for s_info in final_stk_detail:
            if s_info['holdings'] > 0:
                has_pos = True
                print(f"  {s_info['stock']}: 持仓{s_info['holdings']:.0f}份, 市值¥{s_info['value']:,.2f}, 权重{s_info['weight']*100:.1f}%, 目标{s_info['target']}")
        if not has_pos:
            print("  无持仓 (全部现金)")
        
        if benchmark_dict and 'benchmark_net_value' in portfolio_df.columns:
            benchmark_final = portfolio_df['benchmark_net_value'].iloc[-1]
            strategy_final = portfolio_df['total_value'].iloc[-1] / self.cash
            print(f"\n【策略 vs 基准对比】")
            print(f"  策略最终净值: {strategy_final:.4f} (收益率: {(strategy_final-1)*100:.2f}%)")
            print(f"  基准最终净值: {benchmark_final:.4f} (收益率: {(benchmark_final-1)*100:.2f}%)")
            print(f"  超额收益: {(strategy_final - benchmark_final) * 100:.2f}%")
        print("="*60)
        
        return self.portfolio_history
    
    def generate_equity_curve_data(self):
        if self.portfolio_history is None or len(self.portfolio_history) == 0:
            return {}
        df = self.portfolio_history.copy()
        df['net_value'] = df['total_value'] / self.cash
        running_max = df['total_value'].expanding().max()
        df['drawdown'] = (df['total_value'] - running_max) / running_max * 100
        df['drawdown'] = df['drawdown'].fillna(0).replace([np.inf, -np.inf], 0)
        df['position_ratio'] = df['holdings'] / (df['holdings'] + 1) * 100
        df['position_ratio'] = df['position_ratio'].fillna(0).replace([np.inf, -np.inf], 0)
        
        equity_curve = {
            'dates': df['date'].dt.strftime('%Y-%m-%d').tolist(),
            'total_value': df['total_value'].round(2).tolist(),
            'cumulative_pnl': df['cumulative_pnl'].round(2).tolist(),
            'cash': df['cash'].round(2).tolist(),
            'holdings': df['holdings'].round(2).tolist(),
            'net_value': df['net_value'].round(4).tolist(),
            'drawdown': df['drawdown'].round(2).tolist(),
            'position_ratio': df['position_ratio'].round(2).tolist(),
            'total_return': df['total_return'].round(4).tolist(),
            'daily_return': df['daily_return'].round(4).tolist(),
            'benchmark_net_value': df['benchmark_net_value'].round(4).tolist() if 'benchmark_net_value' in df.columns else [],
            'benchmark_return': df['benchmark_return'].round(4).tolist() if 'benchmark_return' in df.columns else [],
        }
        
        if 'benchmark_net_value' in df.columns and len(df['benchmark_net_value']) > 0:
            bm_net = df['benchmark_net_value']
            equity_curve['benchmark_statistics'] = {
                'start_net_value': float(bm_net.iloc[0]),
                'end_net_value': float(bm_net.iloc[-1]),
                'total_return': (float(bm_net.iloc[-1]) - 1) * 100,
                'max_net_value': float(bm_net.max()),
                'min_net_value': float(bm_net.min()),
            }
            bm_running_max = bm_net.expanding().max()
            bm_drawdown = (bm_net - bm_running_max) / bm_running_max * 100
            equity_curve['benchmark_statistics']['max_drawdown'] = float(bm_drawdown.min()) if not bm_drawdown.isna().all() else 0.0
        else:
            equity_curve['benchmark_statistics'] = {}
        
        equity_curve['statistics'] = {
            'start_date': df['date'].iloc[0].strftime('%Y-%m-%d'),
            'end_date': df['date'].iloc[-1].strftime('%Y-%m-%d'),
            'total_days': len(df),
            'initial_cash': self.cash,
            'final_value': df['total_value'].iloc[-1],
            'max_value': df['total_value'].max(),
            'min_value': df['total_value'].min(),
            'total_return': (df['total_value'].iloc[-1] - self.cash) / self.cash * 100,
            'max_drawdown': df['drawdown'].min(),
            'max_drawdown_date': df.loc[df['drawdown'].idxmin(), 'date'].strftime('%Y-%m-%d') if not df['drawdown'].isna().all() else None,
        }
        return equity_curve
    
    def generate_trade_data(self):
        if self.trade_log is None or len(self.trade_log) == 0:
            return {'trades': [], 'statistics': {'total_trades': 0}}
        df = self.trade_log.copy()
        trades = []
        for _, row in df.iterrows():
            trades.append({
                'date': row['date'].strftime('%Y-%m-%d'),
                'stock': row['stock'],
                'type': row['type'],
                'price': round(row['price'], 4),
                'shares': round(row['shares'], 0),
                'amount': round(row['amount'], 2),
                'reason': row['reason'],
                'commission': round(row.get('commission', 0), 2)
            })
        buy_trades = df[df['type'].str.contains('买入') | df['type'].str.contains('建仓')]
        sell_trades = df[df['type'].str.contains('卖出')]
        rebalance_buy = df[df['type'] == '再平衡买入']
        rebalance_sell = df[df['type'] == '再平衡卖出']
        stop_profit = df[df['type'] == '止盈卖出']
        stop_loss = df[df['type'] == '止损买入']
        
        statistics = {
            'total_trades': len(df),
            'buy_trades': len(buy_trades),
            'sell_trades': len(sell_trades),
            'rebalance_buy': len(rebalance_buy),
            'rebalance_sell': len(rebalance_sell),
            'stop_profit': len(stop_profit),
            'stop_loss': len(stop_loss),
            'total_buy_amount': round(buy_trades['amount'].sum(), 2) if len(buy_trades) > 0 else 0,
            'total_sell_amount': round(sell_trades['amount'].sum(), 2) if len(sell_trades) > 0 else 0,
            'total_commission': round(df['commission'].sum(), 2) if 'commission' in df.columns else 0,
            'first_trade_date': df['date'].min().strftime('%Y-%m-%d') if len(df) > 0 else None,
            'last_trade_date': df['date'].max().strftime('%Y-%m-%d') if len(df) > 0 else None,
        }
        return {'trades': trades, 'statistics': statistics}
    
    def generate_position_data(self):
        if self.daily_positions is None or len(self.daily_positions) == 0:
            return {'positions': [], 'statistics': {}}
        df = self.daily_positions.copy()
        positions = []
        for _, row in df.iterrows():
            positions.append({
                'date': row['date'].strftime('%Y-%m-%d'),
                'holdings': round(row['holdings'], 2),
                'cash': round(row['cash'], 2),
                'total_value': round(row['total_value'], 2),
                'daily_pnl': round(row['daily_pnl'], 2),
                'cumulative_pnl': round(row['cumulative_pnl'], 2),
                'total_return': round(row['total_return'] * 100, 2),
                'stock_details': row['stock_details']
            })
        statistics = {
            'total_days': len(df),
            'max_holdings': round(df['holdings'].max(), 2),
            'min_holdings': round(df['holdings'].min(), 2),
            'final_holdings': round(df['holdings'].iloc[-1], 2),
            'avg_holdings': round(df['holdings'].mean(), 2),
            'first_date': df['date'].iloc[0].strftime('%Y-%m-%d'),
            'last_date': df['date'].iloc[-1].strftime('%Y-%m-%d'),
            'final_return': round(df['total_return'].iloc[-1] * 100, 2)
        }
        return {'positions': positions, 'statistics': statistics}
    
    def generate_account_data(self):
        if self.portfolio_history is None or len(self.portfolio_history) == 0:
            return {'account_history': [], 'statistics': {}}
        df = self.portfolio_history.copy()
        df['net_value'] = df['total_value'] / self.cash
        account_history = []
        for _, row in df.iterrows():
            account_history.append({
                'date': row['date'].strftime('%Y-%m-%d'),
                'total_value': round(row['total_value'], 2),
                'cash': round(row['cash'], 2),
                'holdings': round(row['holdings'], 2),
                'cumulative_pnl': round(row['cumulative_pnl'], 2),
                'net_value': round(row['net_value'], 4),
                'total_return': round(row['total_return'] * 100, 2),
                'daily_return': round(row['daily_return'] * 100, 2),
                'benchmark_net_value': round(row['benchmark_net_value'], 4) if 'benchmark_net_value' in row else 1.0
            })
        daily_returns = df['daily_return'].dropna()
        volatility = daily_returns.std() * np.sqrt(252) * 100 if len(daily_returns) > 0 and daily_returns.std() > 0 else 0
        statistics = {
            'start_date': df['date'].iloc[0].strftime('%Y-%m-%d'),
            'end_date': df['date'].iloc[-1].strftime('%Y-%m-%d'),
            'total_days': len(df),
            'initial_cash': self.cash,
            'final_total_value': round(df['total_value'].iloc[-1], 2),
            'final_cash': round(df['cash'].iloc[-1], 2),
            'final_holdings': round(df['holdings'].iloc[-1], 2),
            'total_pnl': round(df['cumulative_pnl'].iloc[-1], 2),
            'total_return': round((df['total_value'].iloc[-1] - self.cash) / self.cash * 100, 2),
            'max_total_value': round(df['total_value'].max(), 2),
            'min_total_value': round(df['total_value'].min(), 2),
            'max_net_value': round(df['net_value'].max(), 4),
            'min_net_value': round(df['net_value'].min(), 4),
            'volatility': round(volatility, 2),
        }
        if 'benchmark_net_value' in df.columns:
            bm = df['benchmark_net_value']
            statistics['benchmark_final_value'] = round(bm.iloc[-1], 4)
            statistics['benchmark_total_return'] = round((bm.iloc[-1] - 1) * 100, 2)
        return {'account_history': account_history, 'statistics': statistics}
    
    def calculate_performance_metrics(self, df, df_index):
        metrics = {}
        if df is None or len(df) == 0:
            return metrics
        metrics['start_date'] = df['date'].iloc[0].strftime('%Y-%m-%d')
        metrics['end_date'] = df['date'].iloc[-1].strftime('%Y-%m-%d')
        metrics['total_days'] = len(df)
        metrics['total_cash'] = self.cash
        metrics['final_value'] = round(df['total_value'].iloc[-1], 2)
        metrics['total_return'] = round((df['total_value'].iloc[-1] - self.cash) / self.cash, 4) if self.cash > 0 else 0
        metrics['total_pnl'] = round(df['total_value'].iloc[-1] - self.cash, 2)
        metrics['total_commission'] = self.trade_log['commission'].sum() if 'commission' in self.trade_log.columns else 0
        metrics['remaining_cash'] = round(df['cash'].iloc[-1], 2)
        metrics['final_holdings'] = round(df['holdings'].iloc[-1], 2)
        days = (df['date'].iloc[-1] - df['date'].iloc[0]).days
        years = days / 365.25 if days > 0 else 1
        metrics['annual_return'] = round((1 + metrics['total_return']) ** (1 / years) - 1, 4) if years > 0 and metrics['total_return'] > -1 else 0
        cumulative = df['total_value']
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        metrics['max_drawdown'] = round(drawdown.min(), 4) if not drawdown.empty else 0
        metrics['max_drawdown_date'] = df['date'][drawdown.idxmin()].strftime('%Y-%m-%d') if not drawdown.empty and not drawdown.isna().all() else None
        risk_free_rate = 0.02
        daily_returns = df['daily_return'].dropna()
        daily_returns = daily_returns[(daily_returns > -1) & (daily_returns < 1)]
        daily_returns = daily_returns[daily_returns != 0]
        if len(daily_returns) > 2 and daily_returns.std() > 1e-10:
            excess_returns = daily_returns - risk_free_rate / 252
            metrics['sharpe_ratio'] = round(np.sqrt(252) * excess_returns.mean() / daily_returns.std(), 4)
        else:
            metrics['sharpe_ratio'] = 0
        downside_returns = daily_returns[daily_returns < 0]
        if len(downside_returns) > 2 and downside_returns.std() > 1e-10:
            metrics['sortino_ratio'] = round(np.sqrt(252) * daily_returns.mean() / downside_returns.std(), 4)
        else:
            metrics['sortino_ratio'] = 0
        metrics['calmar_ratio'] = round(metrics['annual_return'] / abs(metrics['max_drawdown']), 4) if metrics['max_drawdown'] != 0 and abs(metrics['max_drawdown']) > 1e-10 else 0
        metrics['win_rate'] = round((daily_returns > 0).sum() / len(daily_returns), 4) if len(daily_returns) > 0 else 0
        metrics['volatility'] = round(daily_returns.std() * np.sqrt(252), 4) if len(daily_returns) > 0 and daily_returns.std() > 0 else 0
        if 'benchmark_net_value' in df.columns and len(df['benchmark_net_value']) > 0:
            bm_net = df['benchmark_net_value']
            metrics['benchmark_final_value'] = round(bm_net.iloc[-1], 4)
            metrics['benchmark_total_return'] = round(bm_net.iloc[-1] - 1, 4)
            metrics['benchmark_start_value'] = round(bm_net.iloc[0], 4)
            bm_running_max = bm_net.expanding().max()
            bm_drawdown = (bm_net - bm_running_max) / bm_running_max
            metrics['benchmark_max_drawdown'] = round(bm_drawdown.min(), 4) if not bm_drawdown.empty else 0
            strategy_return = metrics['total_return']
            benchmark_return = metrics['benchmark_total_return']
            metrics['excess_return'] = round(strategy_return - benchmark_return, 4)
            metrics['excess_return_pct'] = round((strategy_return - benchmark_return) * 100, 2)
        metrics['interval'] = self.interval
        metrics['deviation_list'] = self.deviation_list
        metrics['dt_type'] = self.dt_type
        metrics['sell_zdf'] = self.sell_zdf
        metrics['buy_zdf'] = self.buy_zdf
        metrics['use_custom_data'] = self.use_custom_data
        return metrics
    
    # ===== 接口 API =====
    def get_config(self):
        return {
            'start_date': self.start_date,
            'end_date': self.end_date,
            'stock_list': self.stock_list,
            'dt_type': self.dt_type,
            'weight_list': self.weight_list,
            'deviation_list': self.deviation_list,
            'interval': self.interval,
            'index_stock': self.index_stock,
            'cash': self.cash,
            'adj_type': self.adj_type,
            'sell_zdf': self.sell_zdf,
            'buy_zdf': self.buy_zdf,
            'trade_value': self.trade_value,
            'min_shares': self.min_shares,
            'share_multiple': self.share_multiple,
            'comm': self.comm,
            'max_workers': self.max_workers,
            'use_custom_data': self.use_custom_data,
            'custom_data_keys': list(self._custom_data_cache.keys())
        }
    
    def get_trade_data(self):
        if self.trade_data is None:
            self.run_backtest()
        return self.trade_data
    
    def get_position_data(self):
        if self.position_data is None:
            self.run_backtest()
        return self.position_data
    
    def get_account_data(self):
        if self.account_data is None:
            self.run_backtest()
        return self.account_data
    
    def get_daily_positions(self):
        if self.daily_positions is None:
            self.run_backtest()
        return self.daily_positions.to_dict('records')
    
    def get_trade_log(self):
        if self.trade_log is None:
            self.run_backtest()
        return self.trade_log.to_dict('records')
    
    def get_portfolio_history(self):
        if self.portfolio_history is None:
            self.run_backtest()
        return self.portfolio_history.to_dict('records')
    
    def get_performance_metrics(self):
        if self.performance_metrics is None:
            self.run_backtest()
        return self.performance_metrics
    
    def get_equity_curve_data(self):
        if self.equity_curve_data is None:
            self.run_backtest()
        return self.equity_curve_data
    
    def get_stock_results(self):
        if not self.stock_results:
            self.run_backtest()
        return self.stock_results
    
    def get_backtest_summary(self):
        if self.performance_metrics is None:
            self.run_backtest()
        return {
            'config': self.get_config(),
            'performance_metrics': self.performance_metrics,
            'annual_performance': self.annual_performance,
            'trade_count': len(self.trade_log) if self.trade_log is not None else 0,
            'daily_positions': self.daily_positions.to_dict('records') if self.daily_positions is not None else [],
            'trade_log': self.trade_log.to_dict('records') if self.trade_log is not None else [],
            'portfolio_history': self.portfolio_history.to_dict('records') if self.portfolio_history is not None else [],
            'equity_curve': self.equity_curve_data,
            'trade_data': self.trade_data,
            'position_data': self.position_data,
            'account_data': self.account_data,
            'stock_results': self.stock_results
        }
    
    def get_all_data(self):
        if self.performance_metrics is None:
            self.run_backtest()
        data = {
            'config': self.get_config(),
            'performance': self.performance_metrics,
            'annual_performance': self.annual_performance,
            'equity_curve': self.equity_curve_data,
            'trade_data': self.trade_data,
            'position_data': self.position_data,
            'account_data': self.account_data,
            'trade_log': self.trade_log.to_dict('records') if self.trade_log is not None else [],
            'daily_positions': self.daily_positions.to_dict('records') if self.daily_positions is not None else [],
            'portfolio_history': self.portfolio_history.to_dict('records') if self.portfolio_history is not None else [],
            'stock_results': self.stock_results
        }
        return self._convert_to_serializable(data)
    
    def get_backtrader_data(self):
        if self.performance_metrics is None:
            self.run_backtest()
        data = {}
        index_data = self.get_index_data()
        if not index_data.empty:
            data['指数数据'] = index_data.to_dict('records')
        else:
            data['指数数据'] = []
        data['成交'] = self.get_trade_data()
        data['持股'] = self.get_position_data()
        data['账户'] = self.get_account_data()
        data['绩效'] = self.get_performance_metrics()
        data['年度收益统计'] = self.get_annual_performance()
        data['净值曲线'] = self.get_equity_curve_data()
        data['策略参数'] = self.get_config()
        return self._convert_to_serializable(data)
    
    def save_backtrader_data(self, user='test'):
        if self.performance_metrics is None:
            self.run_backtest()
        base_path = r'{}/策略模型/资产配置平衡策略/{}'.format(self.path, user)
        os.makedirs(os.path.join(base_path, '指数数据'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '成交数据'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '持股数据'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '账户数据'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '绩效指标'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '净值曲线'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '策略参数'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '年度收益统计'), exist_ok=True)
        
        try:
            index_data = self.get_index_data()
            if not index_data.empty:
                index_data.to_excel(os.path.join(base_path, '指数数据', '指数数据.xlsx'), index=False)
                index_data.to_json(os.path.join(base_path, '指数数据', '指数数据.json'), orient='records', force_ascii=False)
            
            trade = self.get_trade_data()
            if trade and trade.get('trades'):
                pd.DataFrame(trade['trades']).to_excel(os.path.join(base_path, '成交数据', '成交数据.xlsx'), index=False)
                pd.DataFrame(trade['trades']).to_json(os.path.join(base_path, '成交数据', '成交数据.json'), orient='records', force_ascii=False)
            
            position = self.get_position_data()
            if position and position.get('positions'):
                pd.DataFrame(position['positions']).to_excel(os.path.join(base_path, '持股数据', '持股数据.xlsx'), index=False)
                pd.DataFrame(position['positions']).to_json(os.path.join(base_path, '持股数据', '持股数据.json'), orient='records', force_ascii=False)
            
            account = self.get_account_data()
            if account and account.get('account_history'):
                pd.DataFrame(account['account_history']).to_excel(os.path.join(base_path, '账户数据', '账户数据.xlsx'), index=False)
                pd.DataFrame(account['account_history']).to_json(os.path.join(base_path, '账户数据', '账户数据.json'), orient='records', force_ascii=False)
            
            performance = self.get_performance_metrics()
            if performance:
                pd.DataFrame([performance]).to_excel(os.path.join(base_path, '绩效指标', '绩效指标.xlsx'), index=False)
                pd.DataFrame([performance]).to_json(os.path.join(base_path, '绩效指标', '绩效指标.json'), orient='records', force_ascii=False)
            
            annual_df = self.get_annual_performance_df()
            if not annual_df.empty:
                annual_df.to_excel(os.path.join(base_path, '年度收益统计', '年度收益统计.xlsx'), index=False)
                # 使用json.dump保存，避免列名重复问题
                annual_records = annual_df.to_dict(orient='records')
                with open(os.path.join(base_path, '年度收益统计', '年度收益统计.json'), 'w', encoding='utf-8') as f:
                    json.dump(annual_records, f, ensure_ascii=False, indent=2)
                print(f"✅ 年度收益统计已保存，共 {len(annual_df)} 年数据")
            
            curve = self.get_equity_curve_data()
            if curve:
                with open(os.path.join(base_path, '净值曲线', '净值曲线.json'), 'w', encoding='utf-8') as f:
                    json.dump(curve, f, ensure_ascii=False, indent=2)
            
            config = self.get_config()
            if config:
                pd.DataFrame([config]).to_excel(os.path.join(base_path, '策略参数', '策略参数.xlsx'), index=False)
                pd.DataFrame([config]).to_json(os.path.join(base_path, '策略参数', '策略参数.json'), orient='records', force_ascii=False)
            
            print(f"✅ 所有回测数据已保存到: {base_path}")
        except Exception as e:
            print(f"⚠️ 保存数据时出错: {e}")
            import traceback
            traceback.print_exc()
    
    def save_to_json(self, filename=None, include_raw_data=False):
        if filename is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            stock_str = '_'.join(self.stock_list)
            filename = f'asset_rebalance_backtest_{stock_str}_{timestamp}.json'
        if include_raw_data:
            data = self.get_backtrader_data()
        else:
            data = self.get_all_data()
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"✅ 回测结果已保存到: {filename}")
        print(f"📊 文件大小: {os.path.getsize(filename) / 1024:.2f} KB")
        return filename
    
    def run_backtest(self):
        return self.vectorized_backtest()
    
    def generate_report(self):
        if self.performance_metrics is None:
            self.run_backtest()
        metrics = self.performance_metrics
        
        stock_details = ""
        for stock, result in self.stock_results.items():
            if self.dt_type == '金额':
                target_amount = result.get('target_amount', 0)
                profit = result['final_value'] - target_amount if target_amount > 0 else result['final_value']
                profit_rate = profit / target_amount * 100 if target_amount > 0 else 0
                stock_details += f"  {stock}: 目标金额¥{target_amount:,.0f}, 最终资产¥{result['final_value']:,.2f}, 盈亏¥{profit:,.2f}, 收益率{profit_rate:.2f}%\n"
            else:
                target_weight = result.get('target_weight', 0)
                profit = result['final_value'] - self.cash * target_weight
                profit_rate = profit / (self.cash * target_weight) * 100 if self.cash * target_weight > 0 else 0
                stock_details += f"  {stock}: 目标权重{target_weight*100:.1f}%, 最终资产¥{result['final_value']:,.2f}, 盈亏¥{profit:,.2f}, 收益率{profit_rate:.2f}%\n"
        
        annual_report = ""
        if self.annual_performance:
            annual_report += "\n【年度收益统计】\n"
            annual_report += "-" * 120 + "\n"
            annual_report += f"{'年份':<6} {'起始日期':<12} {'结束日期':<12} {'总天数':<8} {'总收益率':<12} {'年化收益':<12} {'最大回撤':<12} {'夏普比率':<12} {'胜率':<10}\n"
            annual_report += "-" * 120 + "\n"
            for year, stats in sorted(self.annual_performance.items()):
                annual_report += (
                    f"{year:<6} "
                    f"{stats.get('start_date', ''):<12} "
                    f"{stats.get('end_date', ''):<12} "
                    f"{stats.get('total_days', 0):<8} "
                    f"{stats.get('total_return', 0)*100:<12.2f}% "
                    f"{stats.get('annual_return', 0)*100:<12.2f}% "
                    f"{stats.get('max_drawdown', 0)*100:<12.2f}% "
                    f"{stats.get('sharpe_ratio', 0):<12.4f} "
                    f"{stats.get('win_rate', 0)*100:<10.2f}%\n"
                )
            annual_report += "-" * 120 + "\n"
        
        benchmark_info = ""
        if 'benchmark_total_return' in metrics:
            benchmark_info += f"\n【基准对比（按配置权重持有不动）】\n"
            benchmark_info += f"  基准起始净值: {metrics.get('benchmark_start_value', 1.0):.4f}\n"
            benchmark_info += f"  基准最终净值: {metrics.get('benchmark_final_value', 1.0):.4f}\n"
            benchmark_info += f"  基准总收益率: {metrics.get('benchmark_total_return', 0) * 100:.2f}%\n"
            benchmark_info += f"  基准最大回撤: {metrics.get('benchmark_max_drawdown', 0) * 100:.2f}%\n"
            benchmark_info += f"  策略超额收益: {metrics.get('excess_return_pct', 0):.2f}%\n"
        
        report = f"""
        ========================================
        资产配置平衡策略回测报告
        ========================================
        
        【策略参数】
        策略名称: 资产配置平衡策略
        配置类型: {self.dt_type}
        标的列表: {self.stock_list}
        配置列表: {dict(zip(self.stock_list, self.weight_list))}
        偏离度列表: {dict(zip(self.stock_list, self.deviation_list))}
        再平衡间隔: 每 {self.interval} 个交易日
        对比指数: {self.index_stock}
        回测区间: {metrics.get('start_date', self.start_date)} 至 {metrics.get('end_date', self.end_date)}
        初始总资金: ¥{self.cash:,.0f}
        手续费率: {self.comm*100:.2f}%
        做T止盈: 涨>{self.sell_zdf*100:.0f}%卖出
        做T止损: 跌<{self.buy_zdf*100:.0f}%买入
        做T金额: ¥{self.trade_value:,.2f}
        多线程线程数: {self.max_workers}
        自定义数据源: {'启用' if self.use_custom_data else '禁用'}
        {f"已加载自定义数据: {list(self._custom_data_cache.keys())}" if self.use_custom_data else ""}
        
        【各标的结果】
{stock_details}
        
        【交易统计】
        总交易次数: {len(self.trade_log) if self.trade_log is not None else 0}
        
        【汇总持仓】
        最终总持仓份额: {metrics.get('final_holdings', 0):.0f} 份
        剩余现金: ¥{metrics.get('remaining_cash', 0):,.2f}
        
        【收益指标】
        最终总资产: ¥{metrics.get('final_value', 0):,.2f}
        总收益: {metrics.get('total_return', 0)*100:.2f}%
        年化收益: {metrics.get('annual_return', 0)*100:.2f}%
        总盈亏: ¥{metrics.get('total_pnl', 0):,.2f}
        波动率: {metrics.get('volatility', 0)*100:.2f}%
        总手续费: ¥{metrics.get('total_commission', 0):,.2f}
{benchmark_info}
        【风险指标】
        最大回撤: {metrics.get('max_drawdown', 0)*100:.2f}%
        最大回撤日期: {metrics.get('max_drawdown_date', 'N/A')}
        夏普比率: {metrics.get('sharpe_ratio', 0):.3f}
        索提诺比率: {metrics.get('sortino_ratio', 0):.3f}
        卡尔玛比率: {metrics.get('calmar_ratio', 0):.3f}
        胜率: {metrics.get('win_rate', 0)*100:.2f}%
{annual_report}
        ========================================
        """
        return report


if __name__ == '__main__':
    # ===== 示例1: 百分比权重配置 =====
    print("="*60)
    print("示例1: 百分比权重配置 - 资产配置平衡策略")
    print("="*60)
    backtester = xg_zcph_backtrader(
        start_date='20250101',
        end_date='20500101',
        stock_list=['159915.SZ', '513100.SH', '518880.SH'],
        dt_type='百分比',
        weight_list=[0.35, 0.35, 0.3],
        deviation_list=[0.1, 0.1, 0.05],
        interval=20,
        index_stock='000300.SH',
        cash=100000,
        sell_zdf=0.03,
        buy_zdf=-0.03,
        trade_value=1000,
        comm=0.0001,
        max_workers=8,
        use_custom_data=False  # 新增参数
    )
    df_result = backtester.run_backtest()
    report_text = backtester.generate_report()
    print(report_text)
    backtester.save_backtrader_data(user="test")
    
    # 获取年度收益统计
    annual_stats = backtester.get_annual_performance()
    print("\n【年度收益统计】")
    for year, stats in annual_stats.items():
        print(f"{year}: 总收益率 {stats['total_return']*100:.2f}%, 最大回撤 {stats['max_drawdown']*100:.2f}%")