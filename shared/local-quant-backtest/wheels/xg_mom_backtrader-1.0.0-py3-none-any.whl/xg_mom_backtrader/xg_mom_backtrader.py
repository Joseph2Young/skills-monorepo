import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta
import json
import math
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
import io
warnings.filterwarnings('ignore')
###############################################
'''
数据必须包含的字段
字段名	说明	是否必须
date	日期	✅ 必须
close	收盘价	✅ 必须
open	开盘价	✅ 必须
high	最高价	✅ 必须
low	最低价	✅ 必须
volume	成交量	✅ 必须
####################################
推荐包含的字段（用于复权计算和涨跌停过滤）
字段名	说明	是否必须
preClose	前收盘价	⚠️ 推荐（用于复权和涨跌停过滤）
zdf	涨跌幅	⚠️ 推荐（如不存在会自动计算）
amount	成交金额	⚠️ 可选
证券代码	股票代码	⚠️ 可选（会自动添加）
证券名称	股票名称	⚠️ 可选
'''
class xg_mom_backtrader:
    '''
    动量回测模型 - 每日动量排名，持有排名前N的标的（N = buy_rank）
    支持金额、百分比两种交易模式
    支持止盈卖出功能
    '''
    def __init__(
        self,
        start_date: str = '20240101',
        end_date: str = '20500101',
        stock_list: list = ['159915.SZ', '513100.SZ', '518880.SH'],
        index_stock: str = '000300.SH',
        cash: float = 100000,
        comm: float = 0.0001,
        mom_type: str = '百分比',
        mom_value: float = 0.1,
        mom_daily: int = 25,
        min_mom: float = 0,
        max_mom: float = 5,
        buy_rank: int = 1,
        sell_zdf: float = 0.03,
        sell_amount: float = 1000,
        max_workers: int = 4,
        # ===== 新增：数据源模式开关 =====
        use_custom_data: bool = False,  # 是否使用自定义数据
    ):
        """
        动量策略回测系统
        
        Args:
            start_date: 回测开始日期，格式YYYYMMDD
            end_date: 回测结束日期，格式YYYYMMDD
            stock_list: 股票/ETF列表
            index_stock: 对比指数代码
            cash: 初始资金
            comm: 手续费率
            mom_type: 动量交易类型，'百分比'或'金额'
            mom_value: 动量交易值，百分比模式下为比例(0.1表示10%)，金额模式下为固定金额
            mom_daily: 动量计算天数
            min_mom: 最小动量分数阈值
            max_mom: 最大动量分数阈值
            buy_rank: 买入排名，持有排名前N的标的
            sell_zdf: 止盈阈值，涨幅超过此值触发止盈卖出
            sell_amount: 止盈卖出金额
            max_workers: 多线程加载数据时的线程数
            use_custom_data: 是否使用自定义数据源
        """
        self.start_date = start_date
        self.end_date = end_date
        self.stock_list = stock_list if stock_list is not None else ['159915.SZ', '513100.SZ', '518880.SH']
        self.index_stock = index_stock
        self.cash = cash
        
        self.adj_type = 'none'
        
        self.mom_type = mom_type
        self.mom_value = mom_value
        self.mom_daily = mom_daily
        self.min_mom = min_mom
        self.max_mom = max_mom
        self.buy_rank = buy_rank
        
        self.sell_zdf = sell_zdf
        self.sell_amount = sell_amount
        self.verbose=True
        # ETF交易规则
        self.min_shares = 100
        self.share_multiple = 100
        self.comm = comm
        
        self.max_workers = max_workers
        self.verbose=False
        self.path = os.path.dirname(os.path.abspath(__file__))
        
        # ===== 新增：自定义数据存储 =====
        self.use_custom_data = use_custom_data
        self._custom_data_cache = {}  # 存储自定义数据 {stock_code: DataFrame}
        
        # 回测结果存储
        self.daily_positions = None
        self.trade_log = None
        self.portfolio_history = None
        self.performance_metrics = None
        self.equity_curve_data = None
        self.annual_performance = None
        self.trade_data = None
        self.position_data = None
        self.account_data = None
        self.stock_data_dict = {}
        self.stock_results = {}
        
        print("\n📊 【动量策略参数配置】")
        print("=" * 60)
        print(f"  标的列表: {self.stock_list}")
        print(f"  对比指数: {self.index_stock}")
        print(f"  回测区间: {self.start_date} 至 {self.end_date}")
        print(f"  初始资金: ¥{self.cash:,.2f}")
        print(f"  手续费率: {self.comm*100:.2f}%")
        print(f"  动量计算天数: {self.mom_daily}")
        print(f"  动量区间: [{self.min_mom}, {self.max_mom}]")
        print(f"  买入排名: 前 {self.buy_rank} 名")
        print(f"  交易模式: {self.mom_type}")
        if self.mom_type == '百分比':
            print(f"  交易比例: {self.mom_value*100:.1f}%")
        else:
            print(f"  交易金额: ¥{self.mom_value:,.2f}")
        print(f"  止盈阈值: {self.sell_zdf*100:.0f}%")
        print(f"  止盈卖出金额: ¥{self.sell_amount:,.2f}")
        print(f"  自定义数据源: {'启用' if self.use_custom_data else '禁用'}")
        print("=" * 60)
        print()
        
    def _convert_to_serializable(self, obj):
        if isinstance(obj, dict):
            return {k: self._convert_to_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_to_serializable(item) for item in obj]
        elif isinstance(obj, pd.Timestamp):
            return obj.strftime('%Y-%m-%d')
        elif isinstance(obj, datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, (np.integer, np.int64)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.float64)):
            return float(obj) if not np.isnan(obj) else None
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, pd.DataFrame):
            return obj.to_dict('records')
        elif isinstance(obj, pd.Series):
            return obj.tolist()
        elif isinstance(obj, (np.bool_, bool)):
            return bool(obj)
        elif pd.isna(obj):
            return None
        else:
            return obj

    # ============================================================
    # 新增：数据添加接口（可直接调用）
    # ============================================================

    def add_stock_data_from_dataframe(self, stock_code: str, df: pd.DataFrame) -> bool:
        """
        从DataFrame添加股票数据
        
        Args:
            stock_code: 股票代码
            df: pandas DataFrame，必须包含'date'列
        
        Returns:
            bool: 是否添加成功
        """
        try:
            normalized_df = self._normalize_dataframe(df, stock_code)
            if normalized_df is not None and not normalized_df.empty:
                self._custom_data_cache[stock_code] = normalized_df
                self.use_custom_data = True
                if self.verbose:
                    print(f"  ✅ 添加DataFrame数据: {stock_code} ({len(normalized_df)} 行)")
                return True
            return False
        except Exception as e:
            print(f"  ❌ 添加DataFrame数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_excel(self, stock_code: str, file_path: str, sheet_name: int = 0, **kwargs) -> bool:
        """
        从Excel文件添加股票数据
        
        Args:
            stock_code: 股票代码
            file_path: Excel文件路径
            sheet_name: 工作表名称或索引
            **kwargs: 传递给pd.read_excel的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not os.path.exists(file_path):
                print(f"  ❌ Excel文件不存在: {file_path}")
                return False
            
            df = pd.read_excel(file_path, sheet_name=sheet_name, **kwargs)
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            print(f"  ❌ 添加Excel数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_csv(self, stock_code: str, file_path: str, **kwargs) -> bool:
        """
        从CSV文件添加股票数据
        
        Args:
            stock_code: 股票代码
            file_path: CSV文件路径
            **kwargs: 传递给pd.read_csv的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not os.path.exists(file_path):
                print(f"  ❌ CSV文件不存在: {file_path}")
                return False
            
            # 尝试不同编码
            encodings = ['utf-8', 'gbk', 'gb2312', 'utf-8-sig', 'latin-1']
            df = None
            for encoding in encodings:
                try:
                    df = pd.read_csv(file_path, encoding=encoding, **kwargs)
                    break
                except UnicodeDecodeError:
                    continue
            
            if df is None:
                print(f"  ❌ 无法读取CSV文件: {file_path}")
                return False
            
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            print(f"  ❌ 添加CSV数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_json(self, stock_code: str, file_path: str, orient: str = 'records', **kwargs) -> bool:
        """
        从JSON文件添加股票数据
        
        Args:
            stock_code: 股票代码
            file_path: JSON文件路径
            orient: JSON格式方向
            **kwargs: 传递给pd.read_json的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not os.path.exists(file_path):
                print(f"  ❌ JSON文件不存在: {file_path}")
                return False
            
            df = pd.read_json(file_path, orient=orient, **kwargs)
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            print(f"  ❌ 添加JSON数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_dict(self, stock_code: str, data: dict) -> bool:
        """
        从字典添加股票数据
        
        Args:
            stock_code: 股票代码
            data: 字典数据，格式为 {'date': [...], 'close': [...], ...}
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not data:
                return False
            df = pd.DataFrame(data)
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            print(f"  ❌ 添加Dict数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_parquet(self, stock_code: str, file_path: str, columns: list = None, **kwargs) -> bool:
        """
        从Parquet文件添加股票数据
        
        Args:
            stock_code: 股票代码
            file_path: Parquet文件路径
            columns: 需要读取的列列表
            **kwargs: 传递给pd.read_parquet的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if not os.path.exists(file_path):
                print(f"  ❌ Parquet文件不存在: {file_path}")
                return False
            
            df = pd.read_parquet(file_path, **kwargs)
            if columns:
                existing_cols = [col for col in columns if col in df.columns]
                if existing_cols:
                    df = df[existing_cols]
            
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            print(f"  ❌ 添加Parquet数据失败 {stock_code}: {e}")
            return False

    def add_stock_data_from_bytes(self, stock_code: str, file_bytes: bytes, file_type: str = 'csv', **kwargs) -> bool:
        """
        从字节数据添加股票数据（适用于上传文件等场景）
        
        Args:
            stock_code: 股票代码
            file_bytes: 文件字节数据
            file_type: 文件类型 ('csv', 'excel', 'json')
            **kwargs: 传递给相应读取函数的其他参数
        
        Returns:
            bool: 是否添加成功
        """
        try:
            if file_type.lower() == 'csv':
                encodings = ['utf-8', 'gbk', 'gb2312', 'utf-8-sig', 'latin-1']
                df = None
                for encoding in encodings:
                    try:
                        df = pd.read_csv(io.BytesIO(file_bytes), encoding=encoding, **kwargs)
                        break
                    except UnicodeDecodeError:
                        continue
                if df is None:
                    print(f"  ❌ 无法解码CSV字节数据")
                    return False
            
            elif file_type.lower() in ['excel', 'xlsx', 'xls']:
                df = pd.read_excel(io.BytesIO(file_bytes), **kwargs)
            
            elif file_type.lower() == 'json':
                df = pd.read_json(io.BytesIO(file_bytes), **kwargs)
            
            else:
                print(f"  ❌ 不支持的文件类型: {file_type}")
                return False
            
            return self.add_stock_data_from_dataframe(stock_code, df)
        except Exception as e:
            print(f"  ❌ 添加字节数据失败 {stock_code}: {e}")
            return False

    def clear_custom_data(self):
        """清空所有自定义数据"""
        self._custom_data_cache.clear()
        self.use_custom_data = False
        print("  ✅ 已清空所有自定义数据")

    def remove_stock_data(self, stock_code: str) -> bool:
        """
        移除指定股票的自定义数据
        
        Args:
            stock_code: 股票代码
        
        Returns:
            bool: 是否移除成功
        """
        if stock_code in self._custom_data_cache:
            del self._custom_data_cache[stock_code]
            if not self._custom_data_cache:
                self.use_custom_data = False
            print(f"  ✅ 已移除股票数据: {stock_code}")
            return True
        return False

    def get_custom_data_keys(self) -> list:
        """获取所有已加载的自定义数据股票代码列表"""
        return list(self._custom_data_cache.keys())

    def has_custom_data(self, stock_code: str) -> bool:
        """检查是否有指定股票的自定义数据"""
        return stock_code in self._custom_data_cache

    # ============================================================
    # 内部数据标准化方法
    # ============================================================

    def _normalize_dataframe(self, df: pd.DataFrame, stock_code: str = None) -> pd.DataFrame:
        """
        标准化DataFrame数据
        
        Args:
            df: pandas DataFrame
            stock_code: 股票代码
        
        Returns:
            DataFrame: 标准化后的数据
        """
        if df is None or df.empty:
            return pd.DataFrame()
        
        df = df.copy()
        
        # 标准化日期列
        if 'date' not in df.columns:
            # 尝试查找日期列
            date_cols = [col for col in df.columns if 'date' in col.lower() or '日期' in col]
            if date_cols:
                df = df.rename(columns={date_cols[0]: 'date'})
            else:
                # 尝试使用索引作为日期
                if isinstance(df.index, pd.DatetimeIndex):
                    df = df.reset_index()
                    df = df.rename(columns={df.columns[0]: 'date'})
                else:
                    raise ValueError("DataFrame必须包含'date'列或日期索引")
        
        # 确保日期列是datetime类型
        df['date'] = pd.to_datetime(df['date'])
        df = df.sort_values('date').reset_index(drop=True)
        
        # 确保必要的列存在
        required_cols = ['close', 'high', 'low', 'open', 'volume']
        for col in required_cols:
            if col not in df.columns:
                # 尝试查找对应的列名
                for existing_col in df.columns:
                    if col in existing_col.lower():
                        df = df.rename(columns={existing_col: col})
                        break
                else:
                    # 如果列不存在，创建空列
                    df[col] = np.nan
        
        # 添加证券代码
        if stock_code:
            df['证券代码'] = stock_code
        elif '证券代码' not in df.columns and 'code' not in df.columns:
            df['证券代码'] = 'CUSTOM'
        
        # 计算涨跌幅（如果不存在）
        if 'zdf' not in df.columns and 'close' in df.columns:
            df['zdf'] = df['close'].pct_change().fillna(0)
        
        # 计算复权因子（如果不存在）
        if 'preClose' in df.columns and 'adj_factor' not in df.columns:
            df['return'] = df['close'] / df['preClose']
            df['return'] = df['return'].fillna(1.0)
            df['return'] = df['return'].replace([np.inf, -np.inf], 1.0)
            df['adj_factor'] = df['return'].cumprod()
            if len(df) > 0:
                df.loc[df.index[0], 'adj_factor'] = 1.0
        
        return df

    # ============================================================
    # 修改后的数据加载方法（支持自定义数据源）
    # ============================================================

    def get_stock_data(self, stock_code):
        """
        加载单个股票数据，支持自定义数据源
        """
        try:
            # ===== 第一步：尝试从自定义数据源读取 =====
            if self.use_custom_data and stock_code in self._custom_data_cache:
                df = self._custom_data_cache[stock_code].copy()
                
                if 'date' not in df.columns:
                    return pd.DataFrame()
                
                df['date'] = pd.to_datetime(df['date'])
                start_dt = pd.to_datetime(self.start_date, format='%Y%m%d')
                end_dt = pd.to_datetime(self.end_date, format='%Y%m%d')
                df = df[(df['date'] >= start_dt) & (df['date'] <= end_dt)]
                df = df.sort_values('date').reset_index(drop=True)
                df = df[df['close'] > 0]
                df = df[df['open'] > 0]
                df = self.adjust_price(df)
                df['zdf'] = df['close'].pct_change()
                return df

            # ===== 第二步：从本地文件读取 =====
            df = pd.read_parquet(
                r'{}/data/历史数据/{}.parquet'.format(self.path, stock_code),
                engine='pyarrow', 
                use_threads=True
            )
            df['date'] = pd.to_datetime(df['date'].astype(str), format='%Y%m%d')
            df = df[(df['date'] >= pd.to_datetime(self.start_date)) &
                    (df['date'] <= pd.to_datetime(self.end_date))]
            df = df.sort_values('date').reset_index(drop=True)
            df = df[df['close'] > 0]
            df = df[df['open'] > 0]
            df = self.adjust_price(df)
            df['zdf'] = df['close'].pct_change()
            return df
        except Exception as e:
            print(f"加载股票数据出错 {stock_code}: {e}")
            return pd.DataFrame()

    # ============================================================
    # 以下所有原有函数保持不变
    # ============================================================

    def _load_single_stock(self, stock):
        """
        单个股票数据加载包装函数，用于多线程
        """
        try:
            df = self.get_stock_data(stock)
            if not df.empty:
                return (stock, df, True, f"数据加载成功: {len(df)} 行")
            else:
                return (stock, None, False, "数据加载失败")
        except Exception as e:
            return (stock, None, False, f"加载异常: {e}")

    def adjust_price(self, df):
        """
        价格复权处理
        """
        if self.adj_type == 'none':
            return df
        if 'preClose' in df.columns:
            try:
                df['adj_factor'] = 1.0
                for i in range(1, len(df)):
                    if df.loc[i, 'preClose'] > 0:
                        actual_return = df.loc[i, 'close'] / df.loc[i, 'preClose']
                        df.loc[i, 'adj_factor'] = df.loc[i-1, 'adj_factor'] * actual_return
                    else:
                        df.loc[i, 'adj_factor'] = df.loc[i-1, 'adj_factor']
                if self.adj_type in ['front', 'front_ratio']:
                    last_factor = df['adj_factor'].iloc[-1]
                    df['adj_factor'] = df['adj_factor'] / last_factor
                price_cols = ['open', 'high', 'low', 'close']
                for col in price_cols:
                    if col in df.columns:
                        df[col] = df[col] * df['adj_factor']
                df = df.drop(columns=['adj_factor'])
            except Exception as e:
                print(f"  复权计算出错: {e}")
        return df

    def get_all_stock_data(self):
        """
        多线程加载所有股票数据
        """
        all_data = {}
        print(f"\n开始多线程加载股票数据 (线程数: {self.max_workers})...")
        if self.use_custom_data:
            print(f"使用自定义数据源: {list(self._custom_data_cache.keys())}")
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_stock = {
                executor.submit(self._load_single_stock, stock): stock 
                for stock in self.stock_list
            }
            
            for future in as_completed(future_to_stock):
                stock = future_to_stock[future]
                try:
                    stock_code, df, success, message = future.result()
                    if success and df is not None and not df.empty:
                        all_data[stock_code] = df
                        print(f"  ✅ {stock_code}: {message}")
                        print(f"     数据范围: {df['date'].min()} 至 {df['date'].max()}")
                        print(f"     价格范围: {df['close'].min():.4f} 至 {df['close'].max():.4f}")
                    else:
                        print(f"  ❌ {stock_code}: {message}")
                except Exception as e:
                    print(f"  ❌ {stock}: 线程执行异常: {e}")
        
        print(f"\n多线程加载完成，成功加载 {len(all_data)}/{len(self.stock_list)} 只标的")
        return all_data

    def get_index_data(self):
        """
        加载指数数据
        """
        try:
            file_path = r'{}/data/指数数据/{}.parquet'.format(self.path, self.index_stock)
            if not os.path.exists(file_path):
                print(f"指数文件不存在: {file_path}")
                return pd.DataFrame()
            df = pd.read_parquet(file_path, engine='pyarrow', use_threads=True)
            df['date'] = pd.to_datetime(df['date'].astype(str), format='%Y%m%d')
            df = df[(df['date'] >= pd.to_datetime(self.start_date)) &
                    (df['date'] <= pd.to_datetime(self.end_date))]
            df = df.sort_values('date').reset_index(drop=True)
            df = df[df['close'] > 0]
            df = df[df['open'] > 0]
            print(f"指数数据加载成功: {len(df)} 行")
            return df
        except Exception as e:
            print(f"加载指数数据出错: {e}")
            return pd.DataFrame()

    def calculate_momentum_score(self, df):
        """
        计算动量分数
        使用加权线性回归计算对数收益率的斜率，并结合R²加权
        """
        if len(df) < self.mom_daily:
            return 0
        df_sub = df.tail(self.mom_daily).copy()
        if len(df_sub) < 10:
            return 0
        y = np.log(df_sub['close'].values)
        n = len(y)
        weights = np.linspace(1, 2, n)
        x = np.arange(n)
        slope, intercept = np.polyfit(x, y, 1, w=weights)
        annualized_returns = math.pow(math.exp(slope), 250) - 1
        residuals = y - (slope * x + intercept)
        weighted_residuals = weights * residuals**2
        y_mean = np.mean(y)
        r_squared = 1 - (np.sum(weighted_residuals) / np.sum(weights * (y - y_mean)**2))
        score = annualized_returns * r_squared
        return score

    def calculate_benchmark_curve(self, all_data):
        """
        计算基准收益曲线（等权重持有不动）
        """
        if not all_data:
            return pd.DataFrame()
        common_dates = None
        for stock, df in all_data.items():
            dates = set(df['date'].tolist())
            if common_dates is None:
                common_dates = dates
            else:
                common_dates = common_dates.intersection(dates)
        if not common_dates:
            print("警告：没有共同交易日，无法计算基准收益曲线")
            return pd.DataFrame()
        common_dates = sorted(common_dates)
        normalized_prices = {}
        for stock, df in all_data.items():
            df_dict = df.set_index('date')['close'].to_dict()
            prices = []
            for date in common_dates:
                prices.append(df_dict.get(date, np.nan))
            first_price = prices[0] if prices and not np.isnan(prices[0]) else 1.0
            normalized = [p / first_price if not np.isnan(p) else np.nan for p in prices]
            normalized_prices[stock] = normalized
        benchmark_net = []
        for i in range(len(common_dates)):
            valid_vals = []
            for stock in all_data.keys():
                val = normalized_prices[stock][i]
                if not np.isnan(val):
                    valid_vals.append(val)
            benchmark_net.append(np.mean(valid_vals) if valid_vals else 1.0)
        benchmark_df = pd.DataFrame({'date': common_dates, 'benchmark_net_value': benchmark_net})
        benchmark_df['benchmark_return'] = benchmark_df['benchmark_net_value'].pct_change().fillna(0)
        print(f"\n基准组合（等权重持有不动）计算结果:")
        print(f"  标的数量: {len(all_data)}")
        print(f"  标的列表: {list(all_data.keys())}")
        print(f"  起始净值: {benchmark_df['benchmark_net_value'].iloc[0]:.4f}")
        print(f"  最终净值: {benchmark_df['benchmark_net_value'].iloc[-1]:.4f}")
        print(f"  总收益率: {(benchmark_df['benchmark_net_value'].iloc[-1] - 1) * 100:.2f}%")
        return benchmark_df

    def calculate_buy_shares(self, amount, price):
        """
        计算买入股数
        
        买入规则：
        1. 先扣除手续费，再用剩余金额买入
        2. 按100股的整数倍买入
        3. 确保实际成本（含手续费）不超过可用金额
        
        Args:
            amount: 可用金额（含手续费）
            price: 当前价格
            
        Returns:
            tuple: (买入股数, 实际成本)
        """
        if price <= 0 or amount <= 0:
            return 0, 0
        
        # 先扣除手续费，计算可用于买入的金额
        # 公式：实际成本 = 买入金额 + 买入金额 * comm = amount
        # 所以：买入金额 = amount / (1 + comm)
        buy_amount = amount / (1 + self.comm)
        
        # 计算最大可买份额（按100股整数倍）
        max_shares = int(buy_amount // price)
        shares = (max_shares // self.share_multiple) * self.share_multiple
        
        if shares < self.min_shares:
            shares = 0
        
        # 计算实际成本（含手续费），确保不超过可用金额
        base_cost = shares * price
        commission = base_cost * self.comm
        actual_cost = base_cost + commission
        
        # 安全检查：如果实际成本超过可用金额，减少一手
        while shares > 0 and actual_cost > amount:
            shares -= self.share_multiple
            base_cost = shares * price
            commission = base_cost * self.comm
            actual_cost = base_cost + commission
        
        if shares < self.min_shares:
            shares = 0
            actual_cost = 0
        
        return shares, actual_cost

    def calculate_sell_shares_by_amount(self, shares, price, sell_amount):
        """
        按金额卖出（止盈卖出）
        
        卖出规则：
        1. 根据卖出金额计算股数
        2. 按100股的整数倍卖出
        3. 如果卖出数量大于持仓数量，则全部卖出
        4. 实际收到金额 = 卖出金额 - 手续费
        
        Args:
            shares: 当前持仓股数
            price: 当前价格
            sell_amount: 希望卖出的金额
            
        Returns:
            tuple: (卖出股数, 实际收到金额)
        """
        if price <= 0 or shares <= 0 or sell_amount <= 0:
            return 0, 0
        
        # 计算要卖出的份额
        max_shares = int(sell_amount // price)
        sell_shares = (max_shares // self.share_multiple) * self.share_multiple
        
        if sell_shares == 0 and max_shares >= self.min_shares:
            sell_shares = self.min_shares
        
        # 如果卖出数量大于持仓数量，全部卖出
        if sell_shares > shares:
            sell_shares = shares
        
        if sell_shares == 0:
            return 0, 0
        
        # 计算实际收到的金额（扣除手续费）
        base_amount = sell_shares * price
        commission = base_amount * self.comm
        actual_amount = base_amount - commission
        
        if actual_amount <= 0:
            return 0, 0
        
        return sell_shares, actual_amount

    def calculate_sell_shares_all(self, shares, price):
        """
        全部卖出（调仓时使用）
        
        卖出规则：
        1. 全部卖出持仓
        2. 按100股的整数倍卖出
        3. 如果取整后为0但实际有持仓，全部卖出
        4. 实际收到金额 = 卖出金额 - 手续费
        
        Args:
            shares: 当前持仓股数
            price: 当前价格
            
        Returns:
            tuple: (卖出股数, 实际收到金额)
        """
        if price <= 0 or shares <= 0:
            return 0, 0
        
        # 全部卖出，按100股整数倍
        sell_shares = (shares // self.share_multiple) * self.share_multiple
        
        # 如果取整后为0但实际有持仓，按实际持仓卖出
        if sell_shares == 0 and shares > 0:
            sell_shares = shares
        
        # 确保卖出数量不超过持仓
        if sell_shares > shares:
            sell_shares = shares
        
        if sell_shares == 0:
            return 0, 0
        
        # 计算实际收到的金额（扣除手续费）
        base_amount = sell_shares * price
        commission = base_amount * self.comm
        actual_amount = base_amount - commission
        
        if actual_amount <= 0:
            return 0, 0
        
        return sell_shares, actual_amount

    def vectorized_backtest(self):
        """
        向量化回测主函数
        """
        print("="*60)
        print("开始动量策略回测...")
        print(f"标的列表: {self.stock_list}")
        if self.use_custom_data:
            print(f"使用自定义数据源: {list(self._custom_data_cache.keys())}")
        print(f"动量计算天数: {self.mom_daily}")
        print(f"动量区间: [{self.min_mom}, {self.max_mom}]")
        print(f"买入排名: 前 {self.buy_rank} 名")
        print(f"交易模式: {self.mom_type}")
        if self.mom_type == '百分比':
            print(f"交易值: {self.mom_value*100:.1f}%")
        print(f"止盈阈值: {self.sell_zdf*100:.0f}%")
        print(f"止盈卖出金额: ¥{self.sell_amount:,.2f}")
        print(f"初始总资金: ¥{self.cash:,.2f}")
        print(f"手续费率: {self.comm*100:.2f}%")
        print(f"多线程加载线程数: {self.max_workers}")
        print("="*60)

        all_data = self.get_all_stock_data()
        if not all_data:
            print("没有有效的股票数据，回测终止")
            return None
        self.stock_data_dict = all_data
        df_index = self.get_index_data()
        benchmark_df = self.calculate_benchmark_curve(all_data)
        benchmark_dict = dict(zip(benchmark_df['date'], benchmark_df['benchmark_net_value'])) if not benchmark_df.empty else {}

        # 获取所有共同交易日
        all_dates = None
        for stock, df in all_data.items():
            dates = set(df['date'].tolist())
            all_dates = dates if all_dates is None else all_dates.intersection(dates)
        if not all_dates:
            print("没有共同交易日，回测终止")
            return None
        all_dates = sorted(all_dates)
        print(f"\n共同交易日: {len(all_dates)} 天")

        # 构建价格和涨跌幅映射
        price_map = {}
        zdf_map = {}
        for code, df in all_data.items():
            price_map[code] = dict(zip(df['date'], df['close']))
            zdf_map[code] = dict(zip(df['date'], df['zdf']))

        # 初始化账户状态
        account_cash = self.cash
        hold_positions = {}  # {stock: shares}
        
        all_trades = []
        merged_records = []

        # 历史记录
        holdings_history = {stock: [0] * len(all_dates) for stock in self.stock_list}
        cash_history = {stock: [0] * len(all_dates) for stock in self.stock_list}
        value_history = {stock: [0] * len(all_dates) for stock in self.stock_list}
        
        cash_history[self.stock_list[0]][0] = self.cash
        value_history[self.stock_list[0]][0] = self.cash

        for idx, trade_date in enumerate(all_dates):
            daily_trades = []
            today_price = {s: price_map[s].get(trade_date, np.nan) for s in self.stock_list}
            today_zdf = {s: zdf_map[s].get(trade_date, 0) for s in self.stock_list}

            # 计算动量排名
            score_dict = {}
            for stock in self.stock_list:
                df_full = all_data[stock]
                df_until_today = df_full[df_full['date'] <= trade_date].copy()
                score_dict[stock] = self.calculate_momentum_score(df_until_today)
            
            sorted_stocks = sorted(score_dict.items(), key=lambda x: x[1], reverse=True)
            filter_stocks = [s for s, sc in sorted_stocks if self.min_mom <= sc <= self.max_mom]
            
            if len(filter_stocks) == 0 and len(sorted_stocks) > 0:
                filter_stocks = [s for s, sc in sorted_stocks[:self.buy_rank]]
            
            target_codes = filter_stocks[:self.buy_rank] if len(filter_stocks) >= self.buy_rank else filter_stocks
            current_holdings = list(hold_positions.keys())
            
            # ========== 步骤1：先卖出（不在目标持仓中的标的） ==========
            stocks_to_sell = [s for s in current_holdings if s not in target_codes]
            for stock in stocks_to_sell:
                shares = hold_positions[stock]
                price = today_price[stock]
                if not np.isnan(price) and price > 0 and shares > 0:
                    sell_shares, receive_cash = self.calculate_sell_shares_all(shares, price)
                    if sell_shares > 0:
                        comm = sell_shares * price * self.comm
                        account_cash += receive_cash
                        if sell_shares >= shares:
                            del hold_positions[stock]
                        else:
                            hold_positions[stock] -= sell_shares
                        
                        daily_trades.append({
                            'date': trade_date,
                            'stock': stock,
                            'type': '动量卖出',
                            'price': round(price, 4),
                            'shares': sell_shares,
                            'amount': round(receive_cash, 2),
                            'commission': round(comm, 4),
                            'reason': f'排名跌出前{self.buy_rank}，卖出{stock}'
                        })
            
            # ========== 步骤2：卖出后计算总资产 ==========
            total_asset = account_cash
            for stock, shares in hold_positions.items():
                if stock in today_price and not np.isnan(today_price[stock]):
                    total_asset += shares * today_price[stock]
            
            # ========== 步骤3：再买入（目标持仓中但当前未持有的标的） ==========
            stocks_to_buy = [s for s in target_codes if s not in hold_positions]
            
            for stock in stocks_to_buy:
                target_p = today_price[stock]
                if np.isnan(target_p) or target_p <= 0:
                    continue
                
                if self.mom_type == '金额':
                    total_buy_cap = self.mom_value
                elif self.mom_type == '百分比':
                    total_buy_cap = total_asset * self.mom_value
                else:
                    total_buy_cap = self.mom_value * target_p
                
                num_targets = len(target_codes)
                if num_targets > 0:
                    buy_cap = total_buy_cap / num_targets
                else:
                    buy_cap = 0
                
                # 限制买入金额不超过可用现金
                buy_cap = min(buy_cap, account_cash)
                
                if buy_cap > 0 and account_cash > 0:
                    buy_shares, cost = self.calculate_buy_shares(buy_cap, target_p)
                    if buy_shares > 0 and cost <= account_cash:
                        comm = buy_shares * target_p * self.comm
                        account_cash -= cost
                        hold_positions[stock] = buy_shares
                        
                        daily_trades.append({
                            'date': trade_date,
                            'stock': stock,
                            'type': '动量买入',
                            'price': round(target_p, 4),
                            'shares': buy_shares,
                            'amount': round(cost, 2),
                            'commission': round(comm, 4),
                            'reason': f'排名前{self.buy_rank}，买入{stock}'
                        })
            
            # ========== 步骤4：止盈卖出 ==========
            if self.sell_zdf > 0:
                for stock in list(hold_positions.keys()):
                    shares = hold_positions[stock]
                    if shares <= 0:
                        continue
                    current_zdf = today_zdf.get(stock, 0)
                    if current_zdf >= self.sell_zdf:
                        p = today_price[stock]
                        if not np.isnan(p) and p > 0:
                            sell_shares, receive_cash = self.calculate_sell_shares_by_amount(shares, p, self.sell_amount)
                            if sell_shares > 0:
                                comm = sell_shares * p * self.comm
                                account_cash += receive_cash
                                if sell_shares >= shares:
                                    del hold_positions[stock]
                                else:
                                    hold_positions[stock] -= sell_shares
                                
                                daily_trades.append({
                                    'date': trade_date,
                                    'stock': stock,
                                    'type': '止盈卖出',
                                    'price': round(p, 4),
                                    'shares': sell_shares,
                                    'amount': round(receive_cash, 2),
                                    'commission': round(comm, 4),
                                    'reason': f'涨幅{current_zdf*100:.2f}%触发止盈'
                                })

            all_trades.extend(daily_trades)

            # ========== 更新历史记录 ==========
            for stock in self.stock_list:
                if stock in hold_positions and hold_positions[stock] > 0:
                    holdings_history[stock][idx] = hold_positions[stock]
                    if stock == self.stock_list[0]:
                        cash_history[stock][idx] = account_cash
                    else:
                        cash_history[stock][idx] = 0
                    value_history[stock][idx] = account_cash + sum([hold_positions[s] * today_price[s] for s in hold_positions if s == stock])
                else:
                    holdings_history[stock][idx] = 0
                    cash_history[stock][idx] = account_cash if stock == self.stock_list[0] else 0
                    value_history[stock][idx] = account_cash if stock == self.stock_list[0] else 0

            # 生成个股明细
            stock_details = []
            total_holdings = 0
            for s in self.stock_list:
                price = today_price[s]
                zdf = today_zdf[s]
                if s in hold_positions and hold_positions[s] > 0:
                    stk_hold = hold_positions[s]
                    stk_value = stk_hold * price if not np.isnan(price) else 0
                    total_holdings += stk_hold
                else:
                    stk_hold = 0.0
                    stk_value = 0.0
                stock_details.append({
                    'stock': s,
                    'price': round(price, 4) if not np.isnan(price) else 0,
                    'zdf': round(zdf, 6) if not np.isnan(zdf) else 0,
                    'holdings': stk_hold,
                    'value': round(stk_value, 2),
                    'cash': 0.0
                })

            market_value = 0
            for s, shares in hold_positions.items():
                if s in today_price and not np.isnan(today_price[s]):
                    market_value += shares * today_price[s]
            total_asset_today = account_cash + market_value

            merged_records.append({
                'date': trade_date,
                'cash': round(account_cash, 2),
                'holdings': total_holdings,
                'total_value': round(total_asset_today, 2),
                'cumulative_pnl': round(total_asset_today - self.cash, 2),
                'total_return': (total_asset_today - self.cash) / self.cash if self.cash > 0 else 0,
                'stock_details': stock_details
            })

        # 填充每日盈亏
        for i in range(1, len(merged_records)):
            merged_records[i]['daily_pnl'] = merged_records[i]['total_value'] - merged_records[i-1]['total_value']
        for item in merged_records:
            item['daily_pnl'] = item.get('daily_pnl', 0)

        self.daily_positions = pd.DataFrame(merged_records)
        
        portfolio_df = pd.DataFrame([{
            'date': r['date'],
            'total_value': r['total_value'],
            'cumulative_pnl': r['cumulative_pnl'],
            'cash': r['cash'],
            'holdings': r['holdings'],
            'total_return': r['total_return']
        } for r in merged_records])
        portfolio_df['daily_return'] = portfolio_df['total_value'].pct_change().fillna(0)
        portfolio_df['daily_return'] = portfolio_df['daily_return'].replace([np.inf, -np.inf], 0)

        if benchmark_dict:
            portfolio_df['benchmark_net_value'] = portfolio_df['date'].map(benchmark_dict)
            portfolio_df['benchmark_net_value'] = portfolio_df['benchmark_net_value'].fillna(method='ffill').fillna(1.0)
            portfolio_df['benchmark_return'] = portfolio_df['benchmark_net_value'].pct_change().fillna(0)
        else:
            portfolio_df['benchmark_net_value'] = 1.0
            portfolio_df['benchmark_return'] = 0.0
        self.portfolio_history = portfolio_df

        self.trade_log = pd.DataFrame(all_trades) if all_trades else pd.DataFrame()
        
        self.stock_results = {}
        for stock in self.stock_list:
            stock_trades = [t for t in all_trades if t['stock'] == stock]
            trade_commission = sum([t.get('commission', 0) for t in stock_trades])
            self.stock_results[stock] = {
                'cash': cash_history[stock],
                'holdings': holdings_history[stock],
                'total_value': value_history[stock],
                'trades': stock_trades,
                'total_commission': trade_commission,
                'final_holdings': holdings_history[stock][-1] if holdings_history[stock] else 0,
                'final_cash': cash_history[stock][-1] if cash_history[stock] else 0,
                'final_value': value_history[stock][-1] if value_history[stock] else 0
            }

        self.equity_curve_data = self.generate_equity_curve_data()
        self.trade_data = self.generate_trade_data()
        self.position_data = self.generate_position_data()
        self.account_data = self.generate_account_data()
        self.performance_metrics = self.calculate_performance_metrics(portfolio_df, df_index)
        self.annual_performance = self.calculate_annual_performance(portfolio_df)

        # 打印结果
        total_commission = self.trade_log['commission'].sum() if 'commission' in self.trade_log.columns else 0
        final_row = merged_records[-1]
        print("\n" + "="*60)
        print("动量策略回测结果:")
        print(f"总交易日: {len(merged_records)}")
        print(f"总交易次数: {len(all_trades)}")
        print(f"最终总持仓份额: {final_row['holdings']:.0f} 份")
        print(f"最终总现金: ¥{final_row['cash']:,.2f}")
        print(f"最终总资产: ¥{final_row['total_value']:,.2f}")
        print(f"总盈亏: ¥{final_row['cumulative_pnl']:,.2f}")
        print(f"总收益率: {final_row['total_return']*100:.2f}%")
        print(f"总手续费: ¥{total_commission:.2f}")

        print("\n最终持仓明细:")
        final_stk_detail = final_row['stock_details']
        has_pos = False
        for s_info in final_stk_detail:
            if s_info['holdings'] > 0:
                has_pos = True
                print(f"  {s_info['stock']}: 持仓{s_info['holdings']:.0f}份, 市值¥{s_info['value']:,.2f}")
        if not has_pos:
            print("  无持仓 (全部现金)")

        if benchmark_dict and 'benchmark_net_value' in portfolio_df.columns:
            benchmark_final = portfolio_df['benchmark_net_value'].iloc[-1]
            strategy_final = portfolio_df['total_value'].iloc[-1] / self.cash
            print(f"\n【策略 vs 基准对比】")
            print(f"  策略最终净值: {strategy_final:.4f} (收益率: {(strategy_final-1)*100:.2f}%)")
            print(f"  基准最终净值: {benchmark_final:.4f} (收益率: {(benchmark_final-1)*100:.2f}%)")
            print(f"  超额收益: {(strategy_final - benchmark_final) * 100:.2f}%")
        print("="*60)
        return self.portfolio_history

    def calculate_annual_performance(self, portfolio_df):
        """
        计算年度收益统计
        """
        if portfolio_df is None or len(portfolio_df) == 0:
            return {}
        
        portfolio_df['year'] = portfolio_df['date'].dt.year
        annual_stats = {}
        
        for year, group in portfolio_df.groupby('year'):
            year_data = group.sort_values('date').reset_index(drop=True)
            
            if len(year_data) < 2:
                continue
            
            start_value = year_data['total_value'].iloc[0]
            end_value = year_data['total_value'].iloc[-1]
            total_return = (end_value - start_value) / start_value if start_value > 0 else 0
            
            cumulative = year_data['total_value']
            running_max = cumulative.expanding().max()
            drawdown = (cumulative - running_max) / running_max
            max_drawdown = drawdown.min() if not drawdown.empty else 0
            max_drawdown_date = year_data['date'][drawdown.idxmin()].strftime('%Y-%m-%d') if not drawdown.empty and not drawdown.isna().all() else None
            
            daily_returns = year_data['daily_return'].dropna()
            daily_returns = daily_returns[(daily_returns > -1) & (daily_returns < 1)]
            daily_returns = daily_returns[daily_returns != 0]
            
            risk_free_rate = 0.02
            if len(daily_returns) > 2 and daily_returns.std() > 1e-10:
                excess_returns = daily_returns - risk_free_rate / 252
                sharpe_ratio = np.sqrt(252) * excess_returns.mean() / daily_returns.std()
            else:
                sharpe_ratio = 0
            
            downside_returns = daily_returns[daily_returns < 0]
            if len(downside_returns) > 2 and downside_returns.std() > 1e-10:
                sortino_ratio = np.sqrt(252) * daily_returns.mean() / downside_returns.std()
            else:
                sortino_ratio = 0
            
            win_rate = (daily_returns > 0).sum() / len(daily_returns) if len(daily_returns) > 0 else 0
            volatility = daily_returns.std() * np.sqrt(252) if len(daily_returns) > 0 and daily_returns.std() > 0 else 0
            calmar_ratio = total_return / abs(max_drawdown) if max_drawdown != 0 and abs(max_drawdown) > 1e-10 else 0
            total_pnl = end_value - start_value
            
            if self.trade_log is not None and len(self.trade_log) > 0:
                year_trades = self.trade_log[self.trade_log['date'].dt.year == year]
                t_trades = len(year_trades)
            else:
                t_trades = 0
            
            if self.trade_log is not None and len(self.trade_log) > 0 and 'commission' in self.trade_log.columns:
                year_commission = self.trade_log[self.trade_log['date'].dt.year == year]['commission'].sum()
            else:
                year_commission = 0
            
            remaining_cash = year_data['cash'].iloc[-1] if 'cash' in year_data.columns else 0
            final_holdings = year_data['holdings'].iloc[-1] if 'holdings' in year_data.columns else 0
            
            if 'benchmark_net_value' in year_data.columns:
                benchmark_start = year_data['benchmark_net_value'].iloc[0]
                benchmark_end = year_data['benchmark_net_value'].iloc[-1]
                benchmark_total_return = (benchmark_end - benchmark_start) / benchmark_start if benchmark_start > 0 else 0
                benchmark_final_value = benchmark_end
                benchmark_start_value = benchmark_start
                
                bm_net = year_data['benchmark_net_value']
                bm_running_max = bm_net.expanding().max()
                bm_drawdown = (bm_net - bm_running_max) / bm_running_max
                benchmark_max_drawdown = bm_drawdown.min() if not bm_drawdown.empty else 0
            else:
                benchmark_total_return = 0
                benchmark_final_value = 1.0
                benchmark_start_value = 1.0
                benchmark_max_drawdown = 0
            
            excess_return = total_return - benchmark_total_return
            excess_return_pct = excess_return * 100
            
            annual_stats[str(year)] = {
                'start_date': year_data['date'].iloc[0].strftime('%Y-%m-%d'),
                'end_date': year_data['date'].iloc[-1].strftime('%Y-%m-%d'),
                'total_days': len(year_data),
                'total_cash': self.cash,
                'final_value': round(end_value, 2),
                'total_return': round(total_return, 4),
                'total_pnl': round(total_pnl, 2),
                'total_invested': 0,
                't_trades': t_trades,
                'total_commission': round(year_commission, 2),
                'remaining_cash': round(remaining_cash, 2),
                'final_holdings': round(final_holdings, 2),
                'annual_return': round(total_return, 4),
                'max_drawdown': round(max_drawdown, 4),
                'max_drawdown_date': max_drawdown_date,
                'sharpe_ratio': round(sharpe_ratio, 4),
                'sortino_ratio': round(sortino_ratio, 4),
                'calmar_ratio': round(calmar_ratio, 4),
                'win_rate': round(win_rate, 4),
                'volatility': round(volatility, 4),
                'benchmark_final_value': round(benchmark_final_value, 4),
                'benchmark_total_return': round(benchmark_total_return, 4),
                'benchmark_start_value': round(benchmark_start_value, 4),
                'benchmark_max_drawdown': round(benchmark_max_drawdown, 4),
                'excess_return': round(excess_return, 4),
                'excess_return_pct': round(excess_return_pct, 2)
            }
        
        return annual_stats

    def get_annual_performance(self):
        """
        获取年度收益统计
        """
        if self.annual_performance is None:
            self.run_backtest()
        return self.annual_performance

    def get_annual_performance_df(self):
        """
        获取年度收益统计DataFrame
        """
        annual_data = self.get_annual_performance()
        if not annual_data:
            return pd.DataFrame()
        
        df = pd.DataFrame.from_dict(annual_data, orient='index')
        df.index.name = 'year'
        df = df.reset_index()
        
        # 确保没有重复列名
        df = df.loc[:, ~df.columns.duplicated()]
        
        column_mapping = {
            'start_date': 'start_date',
            'end_date': 'end_date',
            'total_days': 'total_days',
            'total_cash': 'total_cash',
            'final_value': 'final_value',
            'total_return': 'total_return',
            'total_pnl': 'total_pnl',
            'total_invested': 'total_invested',
            't_trades': 't_trades',
            'total_commission': 'total_commission',
            'remaining_cash': 'remaining_cash',
            'final_holdings': 'final_holdings',
            'annual_return': 'annual_return',
            'max_drawdown': 'max_drawdown',
            'max_drawdown_date': 'max_drawdown_date',
            'sharpe_ratio': 'sharpe_ratio',
            'sortino_ratio': 'sortino_ratio',
            'calmar_ratio': 'calmar_ratio',
            'win_rate': 'win_rate',
            'volatility': 'volatility',
            'benchmark_final_value': 'benchmark_final_value',
            'benchmark_total_return': 'benchmark_total_return',
            'benchmark_start_value': 'benchmark_start_value',
            'benchmark_max_drawdown': 'benchmark_max_drawdown',
            'excess_return': 'excess_return',
            'excess_return_pct': 'excess_return_pct'
        }
        
        existing_cols = [col for col in column_mapping.keys() if col in df.columns]
        df = df[['year'] + existing_cols]
        df.columns = ['year'] + [column_mapping[col] for col in existing_cols]
        
        return df

    def generate_equity_curve_data(self):
        """
        生成净值曲线数据
        """
        if self.portfolio_history is None or len(self.portfolio_history) == 0:
            return {}
        df = self.portfolio_history.copy()
        df['net_value'] = df['total_value'] / self.cash
        running_max = df['total_value'].expanding().max()
        df['drawdown'] = (df['total_value'] - running_max) / running_max * 100
        df['drawdown'] = df['drawdown'].fillna(0).replace([np.inf, -np.inf], 0)
        
        equity_curve = {
            'dates': df['date'].dt.strftime('%Y-%m-%d').tolist(),
            'total_value': df['total_value'].round(2).tolist(),
            'cumulative_pnl': df['cumulative_pnl'].round(2).tolist(),
            'cash': df['cash'].round(2).tolist(),
            'holdings': df['holdings'].round(2).tolist(),
            'net_value': df['net_value'].round(4).tolist(),
            'drawdown': df['drawdown'].round(2).tolist(),
            'total_return': df['total_return'].round(4).tolist(),
            'daily_return': df['daily_return'].round(4).tolist(),
            'benchmark_net_value': df['benchmark_net_value'].round(4).tolist() if 'benchmark_net_value' in df.columns else [],
            'benchmark_return': df['benchmark_return'].round(4).tolist() if 'benchmark_return' in df.columns else [],
        }
        
        if 'benchmark_net_value' in df.columns and len(df['benchmark_net_value']) > 0:
            bm_net = df['benchmark_net_value']
            equity_curve['benchmark_statistics'] = {
                'start_net_value': float(bm_net.iloc[0]),
                'end_net_value': float(bm_net.iloc[-1]),
                'total_return': (float(bm_net.iloc[-1]) - 1) * 100,
                'max_net_value': float(bm_net.max()),
                'min_net_value': float(bm_net.min()),
            }
            bm_running_max = bm_net.expanding().max()
            bm_drawdown = (bm_net - bm_running_max) / bm_running_max * 100
            equity_curve['benchmark_statistics']['max_drawdown'] = float(bm_drawdown.min()) if not bm_drawdown.isna().all() else 0.0
        else:
            equity_curve['benchmark_statistics'] = {}
        
        equity_curve['statistics'] = {
            'start_date': df['date'].iloc[0].strftime('%Y-%m-%d'),
            'end_date': df['date'].iloc[-1].strftime('%Y-%m-%d'),
            'total_days': len(df),
            'initial_cash': self.cash,
            'final_value': df['total_value'].iloc[-1],
            'max_value': df['total_value'].max(),
            'min_value': df['total_value'].min(),
            'total_return': (df['total_value'].iloc[-1] - self.cash) / self.cash * 100,
            'max_drawdown': df['drawdown'].min(),
            'max_drawdown_date': df.loc[df['drawdown'].idxmin(), 'date'].strftime('%Y-%m-%d') if not df['drawdown'].isna().all() else None,
        }
        return equity_curve

    def generate_trade_data(self):
        """
        生成交易数据
        """
        if self.trade_log is None or len(self.trade_log) == 0:
            return {'trades': [], 'statistics': {'total_trades': 0}}
        df = self.trade_log.copy()
        trades = []
        for _, row in df.iterrows():
            trades.append({
                'date': row['date'].strftime('%Y-%m-%d'),
                'stock': row['stock'],
                'type': row['type'],
                'price': round(row['price'], 4),
                'shares': round(row['shares'], 0),
                'amount': round(row['amount'], 2),
                'reason': row.get('reason', ''),
                'commission': round(row.get('commission', 0), 2)
            })
        buy_trades = df[df['type'].str.contains('买入')]
        sell_trades = df[df['type'].str.contains('卖出')]
        statistics = {
            'total_trades': len(df),
            'buy_trades': len(buy_trades),
            'sell_trades': len(sell_trades),
            'total_buy_amount': round(buy_trades['amount'].sum(), 2) if len(buy_trades) > 0 else 0,
            'total_sell_amount': round(sell_trades['amount'].sum(), 2) if len(sell_trades) > 0 else 0,
            'total_commission': round(df['commission'].sum(), 2) if 'commission' in df.columns else 0,
            'first_trade_date': df['date'].min().strftime('%Y-%m-%d') if len(df) > 0 else None,
            'last_trade_date': df['date'].max().strftime('%Y-%m-%d') if len(df) > 0 else None,
        }
        return {'trades': trades, 'statistics': statistics}

    def generate_position_data(self):
        """
        生成持仓数据
        """
        if self.daily_positions is None or len(self.daily_positions) == 0:
            return {'positions': [], 'statistics': {}}
        df = self.daily_positions.copy()
        positions = []
        for _, row in df.iterrows():
            positions.append({
                'date': row['date'].strftime('%Y-%m-%d'),
                'holdings': round(row['holdings'], 2),
                'cash': round(row['cash'], 2),
                'total_value': round(row['total_value'], 2),
                'daily_pnl': round(row['daily_pnl'], 2),
                'cumulative_pnl': round(row['cumulative_pnl'], 2),
                'total_return': round(row['total_return'] * 100, 2),
                'stock_details': row['stock_details']
            })
        statistics = {
            'total_days': len(df),
            'max_holdings': round(df['holdings'].max(), 2),
            'min_holdings': round(df['holdings'].min(), 2),
            'final_holdings': round(df['holdings'].iloc[-1], 2),
            'avg_holdings': round(df['holdings'].mean(), 2),
            'first_date': df['date'].iloc[0].strftime('%Y-%m-%d'),
            'last_date': df['date'].iloc[-1].strftime('%Y-%m-%d'),
            'final_return': round(df['total_return'].iloc[-1] * 100, 2)
        }
        return {'positions': positions, 'statistics': statistics}

    def generate_account_data(self):
        """
        生成账户数据
        """
        if self.portfolio_history is None or len(self.portfolio_history) == 0:
            return {'account_history': [], 'statistics': {}}
        df = self.portfolio_history.copy()
        df['net_value'] = df['total_value'] / self.cash
        account_history = []
        for _, row in df.iterrows():
            account_history.append({
                'date': row['date'].strftime('%Y-%m-%d'),
                'total_value': round(row['total_value'], 2),
                'cash': round(row['cash'], 2),
                'holdings': round(row['holdings'], 2),
                'cumulative_pnl': round(row['cumulative_pnl'], 2),
                'net_value': round(row['net_value'], 4),
                'total_return': round(row['total_return'] * 100, 2),
                'daily_return': round(row['daily_return'] * 100, 2),
                'benchmark_net_value': round(row['benchmark_net_value'], 4) if 'benchmark_net_value' in row else 1.0
            })
        daily_returns = df['daily_return'].dropna()
        volatility = daily_returns.std() * np.sqrt(252) * 100 if len(daily_returns) > 0 and daily_returns.std() > 0 else 0
        statistics = {
            'start_date': df['date'].iloc[0].strftime('%Y-%m-%d'),
            'end_date': df['date'].iloc[-1].strftime('%Y-%m-%d'),
            'total_days': len(df),
            'initial_cash': self.cash,
            'final_total_value': round(df['total_value'].iloc[-1], 2),
            'final_cash': round(df['cash'].iloc[-1], 2),
            'final_holdings': round(df['holdings'].iloc[-1], 2),
            'total_pnl': round(df['cumulative_pnl'].iloc[-1], 2),
            'total_return': round((df['total_value'].iloc[-1] - self.cash) / self.cash * 100, 2),
            'max_total_value': round(df['total_value'].max(), 2),
            'min_total_value': round(df['total_value'].min(), 2),
            'max_net_value': round(df['net_value'].max(), 4),
            'min_net_value': round(df['net_value'].min(), 4),
            'volatility': round(volatility, 2),
        }
        if 'benchmark_net_value' in df.columns:
            bm = df['benchmark_net_value']
            statistics['benchmark_final_value'] = round(bm.iloc[-1], 4)
            statistics['benchmark_total_return'] = round((bm.iloc[-1] - 1) * 100, 2)
        return {'account_history': account_history, 'statistics': statistics}

    def calculate_performance_metrics(self, df, df_index):
        """
        计算绩效指标
        """
        metrics = {}
        if df is None or len(df) == 0:
            return metrics
        metrics['start_date'] = df['date'].iloc[0].strftime('%Y-%m-%d')
        metrics['end_date'] = df['date'].iloc[-1].strftime('%Y-%m-%d')
        metrics['total_days'] = len(df)
        metrics['total_cash'] = self.cash
        metrics['final_value'] = round(df['total_value'].iloc[-1], 2)
        metrics['total_return'] = round((df['total_value'].iloc[-1] - self.cash) / self.cash, 4) if self.cash > 0 else 0
        metrics['total_pnl'] = round(df['total_value'].iloc[-1] - self.cash, 2)
        metrics['total_commission'] = self.trade_log['commission'].sum() if 'commission' in self.trade_log.columns else 0
        metrics['remaining_cash'] = round(df['cash'].iloc[-1], 2)
        metrics['final_holdings'] = round(df['holdings'].iloc[-1], 2)
        days = (df['date'].iloc[-1] - df['date'].iloc[0]).days
        years = days / 365.25 if days > 0 else 1
        metrics['annual_return'] = round((1 + metrics['total_return']) ** (1 / years) - 1, 4) if years > 0 and metrics['total_return'] > -1 else 0
        cumulative = df['total_value']
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        metrics['max_drawdown'] = round(drawdown.min(), 4) if not drawdown.empty else 0
        metrics['max_drawdown_date'] = df['date'][drawdown.idxmin()].strftime('%Y-%m-%d') if not drawdown.empty and not drawdown.isna().all() else None
        risk_free_rate = 0.02
        daily_returns = df['daily_return'].dropna()
        daily_returns = daily_returns[(daily_returns > -1) & (daily_returns < 1)]
        daily_returns = daily_returns[daily_returns != 0]
        if len(daily_returns) > 2 and daily_returns.std() > 1e-10:
            excess_returns = daily_returns - risk_free_rate / 252
            metrics['sharpe_ratio'] = round(np.sqrt(252) * excess_returns.mean() / daily_returns.std(), 4)
        else:
            metrics['sharpe_ratio'] = 0
        downside_returns = daily_returns[daily_returns < 0]
        if len(downside_returns) > 2 and downside_returns.std() > 1e-10:
            metrics['sortino_ratio'] = round(np.sqrt(252) * daily_returns.mean() / downside_returns.std(), 4)
        else:
            metrics['sortino_ratio'] = 0
        metrics['calmar_ratio'] = round(metrics['annual_return'] / abs(metrics['max_drawdown']), 4) if metrics['max_drawdown'] != 0 and abs(metrics['max_drawdown']) > 1e-10 else 0
        metrics['win_rate'] = round((daily_returns > 0).sum() / len(daily_returns), 4) if len(daily_returns) > 0 else 0
        metrics['volatility'] = round(daily_returns.std() * np.sqrt(252), 4) if len(daily_returns) > 0 and daily_returns.std() > 0 else 0
        if 'benchmark_net_value' in df.columns and len(df['benchmark_net_value']) > 0:
            bm_net = df['benchmark_net_value']
            metrics['benchmark_final_value'] = round(bm_net.iloc[-1], 4)
            metrics['benchmark_total_return'] = round(bm_net.iloc[-1] - 1, 4)
            metrics['benchmark_start_value'] = round(bm_net.iloc[0], 4)
            bm_running_max = bm_net.expanding().max()
            bm_drawdown = (bm_net - bm_running_max) / bm_running_max
            metrics['benchmark_max_drawdown'] = round(bm_drawdown.min(), 4) if not bm_drawdown.empty else 0
            strategy_return = metrics['total_return']
            benchmark_return = metrics['benchmark_total_return']
            metrics['excess_return'] = round(strategy_return - benchmark_return, 4)
            metrics['excess_return_pct'] = round((strategy_return - benchmark_return) * 100, 2)
        metrics['mom_daily'] = self.mom_daily
        metrics['min_mom'] = self.min_mom
        metrics['max_mom'] = self.max_mom
        metrics['buy_rank'] = self.buy_rank
        metrics['mom_type'] = self.mom_type
        metrics['mom_value'] = self.mom_value
        metrics['sell_zdf'] = self.sell_zdf
        metrics['sell_amount'] = self.sell_amount
        metrics['use_custom_data'] = self.use_custom_data
        return metrics

    def get_config(self):
        """
        获取策略配置
        """
        return {
            'start_date': self.start_date,
            'end_date': self.end_date,
            'stock_list': self.stock_list,
            'index_stock': self.index_stock,
            'cash': self.cash,
            'adj_type': self.adj_type,
            'mom_type': self.mom_type,
            'mom_value': self.mom_value,
            'mom_daily': self.mom_daily,
            'min_mom': self.min_mom,
            'max_mom': self.max_mom,
            'buy_rank': self.buy_rank,
            'sell_zdf': self.sell_zdf,
            'sell_amount': self.sell_amount,
            'min_shares': self.min_shares,
            'share_multiple': self.share_multiple,
            'comm': self.comm,
            'max_workers': self.max_workers,
            'use_custom_data': self.use_custom_data,
            'custom_data_keys': list(self._custom_data_cache.keys())
        }

    def get_trade_data(self):
        """
        获取交易数据
        """
        if self.trade_data is None:
            self.run_backtest()
        return self.trade_data

    def get_position_data(self):
        """
        获取持仓数据
        """
        if self.position_data is None:
            self.run_backtest()
        return self.position_data

    def get_account_data(self):
        """
        获取账户数据
        """
        if self.account_data is None:
            self.run_backtest()
        return self.account_data

    def get_daily_positions(self):
        """
        获取每日持仓数据
        """
        if self.daily_positions is None:
            self.run_backtest()
        return self.daily_positions.to_dict('records')

    def get_trade_log(self):
        """
        获取交易日志
        """
        if self.trade_log is None:
            self.run_backtest()
        return self.trade_log.to_dict('records')

    def get_portfolio_history(self):
        """
        获取组合历史
        """
        if self.portfolio_history is None:
            self.run_backtest()
        return self.portfolio_history.to_dict('records')

    def get_performance_metrics(self):
        """
        获取绩效指标
        """
        if self.performance_metrics is None:
            self.run_backtest()
        return self.performance_metrics

    def get_equity_curve_data(self):
        """
        获取净值曲线数据
        """
        if self.equity_curve_data is None:
            self.run_backtest()
        return self.equity_curve_data

    def get_stock_results(self):
        """
        获取各标的回测结果
        """
        if not self.stock_results:
            self.run_backtest()
        return self.stock_results

    def get_backtest_summary(self):
        """
        获取回测摘要
        """
        if self.performance_metrics is None:
            self.run_backtest()
        return {
            'config': self.get_config(),
            'performance_metrics': self.performance_metrics,
            'annual_performance': self.annual_performance,
            'trade_count': len(self.trade_log) if self.trade_log is not None else 0,
            'daily_positions': self.daily_positions.to_dict('records') if self.daily_positions is not None else [],
            'trade_log': self.trade_log.to_dict('records') if self.trade_log is not None else [],
            'portfolio_history': self.portfolio_history.to_dict('records') if self.portfolio_history is not None else [],
            'equity_curve': self.equity_curve_data,
            'trade_data': self.trade_data,
            'position_data': self.position_data,
            'account_data': self.account_data,
            'stock_results': self.stock_results
        }

    def get_all_data(self):
        """
        获取所有数据
        """
        if self.performance_metrics is None:
            self.run_backtest()
        data = {
            'config': self.get_config(),
            'performance': self.performance_metrics,
            'annual_performance': self.annual_performance,
            'equity_curve': self.equity_curve_data,
            'trade_data': self.trade_data,
            'position_data': self.position_data,
            'account_data': self.account_data,
            'trade_log': self.trade_log.to_dict('records') if self.trade_log is not None else [],
            'daily_positions': self.daily_positions.to_dict('records') if self.daily_positions is not None else [],
            'portfolio_history': self.portfolio_history.to_dict('records') if self.portfolio_history is not None else [],
            'stock_results': self.stock_results
        }
        return self._convert_to_serializable(data)

    def get_backtrader_data(self):
        """
        获取回测数据（兼容接口）
        """
        if self.performance_metrics is None:
            self.run_backtest()
        data = {}
        index_data = self.get_index_data()
        if not index_data.empty:
            data['指数数据'] = index_data.to_dict('records')
        else:
            data['指数数据'] = []
        data['成交'] = self.get_trade_data()
        data['持股'] = self.get_position_data()
        data['账户'] = self.get_account_data()
        data['绩效'] = self.get_performance_metrics()
        data['年度收益统计'] = self.get_annual_performance()
        data['净值曲线'] = self.get_equity_curve_data()
        fig = self.get_config()
        data['策略参数'] = fig
        return self._convert_to_serializable(data)

    def save_backtrader_data(self, user='test'):
        """
        保存回测数据到文件
        """
        if self.performance_metrics is None:
            self.run_backtest()
        index_data = self.get_index_data()
        if not index_data.empty:
            index_data = index_data
        else:
            index_data = pd.DataFrame()
        base_path = r'{}/策略模型/动量策略/{}'.format(self.path, user)
        os.makedirs(os.path.join(base_path, '指数数据'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '成交数据'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '持股数据'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '账户数据'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '绩效指标'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '净值曲线'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '策略参数'), exist_ok=True)
        os.makedirs(os.path.join(base_path, '年度收益统计'), exist_ok=True)
        
        if not index_data.empty:
            index_data.to_excel(r'{}/策略模型/动量策略/{}/指数数据/指数数据.xlsx'.format(self.path, user), index=False)
            index_data.to_json(r'{}/策略模型/动量策略/{}/指数数据/指数数据.json'.format(self.path, user), orient='records', force_ascii=False)
        
        trade = self.get_trade_data()
        if trade and 'trades' in trade:
            trade_df = pd.DataFrame(trade['trades'])
            if not trade_df.empty:
                trade_df.to_excel(r'{}/策略模型/动量策略/{}/成交数据/成交数据.xlsx'.format(self.path, user), index=False)
                trade_df.to_json(r'{}/策略模型/动量策略/{}/成交数据/成交数据.json'.format(self.path, user), orient='records', force_ascii=False)
        
        position = self.get_position_data()
        if position and 'positions' in position:
            position_df = pd.DataFrame(position['positions'])
            if not position_df.empty:
                position_df.to_excel(r'{}/策略模型/动量策略/{}/持股数据/持股数据.xlsx'.format(self.path, user), index=False)
                position_df.to_json(r'{}/策略模型/动量策略/{}/持股数据/持股数据.json'.format(self.path, user), orient='records', force_ascii=False)
        
        account = self.get_account_data()
        if account and 'account_history' in account:
            account_df = pd.DataFrame(account['account_history'])
            if not account_df.empty:
                account_df.to_excel(r'{}/策略模型/动量策略/{}/账户数据/账户数据.xlsx'.format(self.path, user), index=False)
                account_df.to_json(r'{}/策略模型/动量策略/{}/账户数据/账户数据.json'.format(self.path, user), orient='records', force_ascii=False)
        
        performance = self.get_performance_metrics()
        if performance:
            df = pd.DataFrame([performance])
            df.to_excel(r'{}/策略模型/动量策略/{}/绩效指标/绩效指标.xlsx'.format(self.path, user), index=False)
            df.to_json(r'{}/策略模型/动量策略/{}/绩效指标/绩效指标.json'.format(self.path, user), orient='records', force_ascii=False)
        
        annual_df = self.get_annual_performance_df()
        if not annual_df.empty:
            annual_df.to_excel(r'{}/策略模型/动量策略/{}/年度收益统计/年度收益统计.xlsx'.format(self.path, user), index=False)
            # 使用json.dump保存，避免列名重复问题
            annual_records = annual_df.to_dict(orient='records')
            with open(r'{}/策略模型/动量策略/{}/年度收益统计/年度收益统计.json'.format(self.path, user), 'w', encoding='utf-8') as f:
                json.dump(annual_records, f, ensure_ascii=False, indent=2)
            print(f"✅ 年度收益统计已保存，共 {len(annual_df)} 年数据")
        
        curve = self.get_equity_curve_data()
        if curve:
            curve_data = {}
            for key, value in curve.items():
                if not isinstance(value, dict):
                    curve_data[key] = value
            
            max_len = 0
            for key, value in curve_data.items():
                if isinstance(value, list):
                    max_len = max(max_len, len(value))
            
            if max_len > 0:
                df_curve = pd.DataFrame()
                for key, value in curve_data.items():
                    if isinstance(value, list):
                        if len(value) < max_len:
                            value = value + [None] * (max_len - len(value))
                        df_curve[key] = value
                
                if 'statistics' in curve:
                    stats = curve['statistics']
                    for sk, sv in stats.items():
                        df_curve[f'stat_{sk}'] = [sv] * max_len
                
                if 'benchmark_statistics' in curve:
                    bm_stats = curve['benchmark_statistics']
                    for sk, sv in bm_stats.items():
                        df_curve[f'bm_{sk}'] = [sv] * max_len
                
                if not df_curve.empty:
                    df_curve.to_excel(r'{}/策略模型/动量策略/{}/净值曲线/净值曲线.xlsx'.format(self.path, user), index=False)
                    df_curve.to_json(r'{}/策略模型/动量策略/{}/净值曲线/净值曲线.json'.format(self.path, user), orient='records', force_ascii=False)
        
        fig = self.get_config()
        df_config = pd.DataFrame([fig])
        df_config.to_excel(r'{}/策略模型/动量策略/{}/策略参数/策略参数.xlsx'.format(self.path, user), index=False)
        df_config.to_json(r'{}/策略模型/动量策略/{}/策略参数/策略参数.json'.format(self.path, user), orient='records', force_ascii=False)
        
        print(f"✅ 所有回测数据已保存到: {base_path}")

    def save_to_json(self, filename=None, include_raw_data=False):
        """
        保存回测结果到JSON文件
        """
        if filename is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            stock_str = '_'.join(self.stock_list)
            filename = f'momentum_backtest_{stock_str}_{timestamp}.json'
        if include_raw_data:
            data = self.get_backtrader_data()
        else:
            data = self.get_all_data()
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"✅ 回测结果已保存到: {filename}")
        print(f"📊 文件大小: {os.path.getsize(filename) / 1024:.2f} KB")
        return filename

    def run_backtest(self):
        """
        运行回测（主入口）
        """
        return self.vectorized_backtest()

    def generate_report(self):
        """
        生成回测报告
        """
        if self.performance_metrics is None:
            self.run_backtest()
        metrics = self.performance_metrics
        
        stock_details = ""
        for stock, result in self.stock_results.items():
            if result['final_holdings'] > 0:
                stock_details += f"  {stock}: 持仓{result['final_holdings']:.0f}份, 市值¥{result['final_value']:,.2f}\n"
        if stock_details == "":
            stock_details = "  无持仓 (全部现金)\n"
        
        annual_report = ""
        if self.annual_performance:
            annual_report += "\n【年度收益统计】\n"
            annual_report += "-" * 120 + "\n"
            annual_report += f"{'年份':<6} {'起始日期':<12} {'结束日期':<12} {'总天数':<8} {'总收益率':<12} {'年化收益':<12} {'最大回撤':<12} {'夏普比率':<12} {'胜率':<10}\n"
            annual_report += "-" * 120 + "\n"
            for year, stats in sorted(self.annual_performance.items()):
                annual_report += (
                    f"{year:<6} "
                    f"{stats.get('start_date', ''):<12} "
                    f"{stats.get('end_date', ''):<12} "
                    f"{stats.get('total_days', 0):<8} "
                    f"{stats.get('total_return', 0)*100:<12.2f}% "
                    f"{stats.get('annual_return', 0)*100:<12.2f}% "
                    f"{stats.get('max_drawdown', 0)*100:<12.2f}% "
                    f"{stats.get('sharpe_ratio', 0):<12.4f} "
                    f"{stats.get('win_rate', 0)*100:<10.2f}%\n"
                )
            annual_report += "-" * 120 + "\n"
        
        benchmark_info = ""
        if 'benchmark_total_return' in metrics:
            benchmark_info += f"\n【基准对比（等权重持有不动）】\n"
            benchmark_info += f"  基准起始净值: {metrics.get('benchmark_start_value', 1.0):.4f}\n"
            benchmark_info += f"  基准最终净值: {metrics.get('benchmark_final_value', 1.0):.4f}\n"
            benchmark_info += f"  基准总收益率: {metrics.get('benchmark_total_return', 0) * 100:.2f}%\n"
            benchmark_info += f"  基准最大回撤: {metrics.get('benchmark_max_drawdown', 0) * 100:.2f}%\n"
            benchmark_info += f"  策略超额收益: {metrics.get('excess_return_pct', 0):.2f}%\n"
        
        report = f"""
        ========================================
        动量策略回测报告
        ========================================
        
        【策略参数】
        标的列表: {self.stock_list}
        对比指数: {self.index_stock}
        回测区间: {metrics.get('start_date', self.start_date)} 至 {metrics.get('end_date', self.end_date)}
        初始总资金: ¥{self.cash:,.0f}
        动量计算天数: {self.mom_daily}
        动量区间: [{self.min_mom}, {self.max_mom}]
        买入排名: 前 {self.buy_rank} 名
        交易模式: {self.mom_type}
        交易值: {self.mom_value*100:.1f}%
        止盈阈值: {self.sell_zdf*100:.0f}%
        止盈卖出金额: ¥{self.sell_amount:,.2f}
        手续费率: {self.comm*100:.2f}%
        多线程线程数: {self.max_workers}
        自定义数据源: {'启用' if self.use_custom_data else '禁用'}
        {f"已加载自定义数据: {list(self._custom_data_cache.keys())}" if self.use_custom_data else ""}
        
        【最终持仓】
{stock_details}
        
        【汇总持仓】
        最终总持仓份额: {metrics.get('final_holdings', 0):.0f} 份
        剩余现金: ¥{metrics.get('remaining_cash', 0):,.2f}
        
        【收益指标】
        最终总资产: ¥{metrics.get('final_value', 0):,.2f}
        总收益: {metrics.get('total_return', 0)*100:.2f}%
        年化收益: {metrics.get('annual_return', 0)*100:.2f}%
        总盈亏: ¥{metrics.get('total_pnl', 0):,.2f}
        波动率: {metrics.get('volatility', 0)*100:.2f}%
        总手续费: ¥{metrics.get('total_commission', 0):,.2f}
{benchmark_info}
        【风险指标】
        最大回撤: {metrics.get('max_drawdown', 0)*100:.2f}%
        最大回撤日期: {metrics.get('max_drawdown_date', 'N/A')}
        夏普比率: {metrics.get('sharpe_ratio', 0):.3f}
        索提诺比率: {metrics.get('sortino_ratio', 0):.3f}
        卡尔玛比率: {metrics.get('calmar_ratio', 0):.3f}
        
        【交易统计】
        总交易次数: {len(self.trade_log) if self.trade_log is not None else 0}
        胜率: {metrics.get('win_rate', 0)*100:.2f}%
{annual_report}
        ========================================
        """
        return report


if __name__ == '__main__':
    # 测试不同 cash 值
    for cash_val in [100000, 10000000]:
        print(f"\n{'='*20} 测试 cash={cash_val} {'='*20}")
        backtester = xg_mom_backtrader(
            start_date='20250101',
            end_date='20500101',
            stock_list=['159915.SZ', '513100.SH', '518880.SH'],
            index_stock='000300.SH',
            cash=cash_val,
            comm=0.0001,
            mom_type='百分比',
            mom_value=1,
            mom_daily=25,
            min_mom=0,
            max_mom=5,
            buy_rank=1,
            sell_zdf=8888,  # 关闭止盈
            sell_amount=1000,
            max_workers=8
        )
        df_result = backtester.run_backtest()
        backtester.get_backtrader_data()
        print(f"✅ cash={cash_val} 回测完成，交易次数: {len(backtester.trade_log) if backtester.trade_log is not None else 0}")